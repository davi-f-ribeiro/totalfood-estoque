const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-validation-final');
main(async()=>{
 const {a,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const {id}=JSON.parse(fs.readFileSync(out+'/inventory-end.json'));
 const d=await pageFor('d'), m=await pageFor('d',390);
 await run('EST-02',d,'Verificar o rótulo de estoque mínimo nulo e a situação das linhas com e sem falta.',async()=>{
   await open(d,'/stock');
   const changed=d.waitForResponse(r=>r.url().endsWith('/api/stock?warehouse_id='+a));
   await d.locator('#warehouse').selectOption(String(a));await changed;
   const list=await get(d,'/api/stock?warehouse_id='+a);
   const row=x=>d.locator('#stockList .stock-card').filter({hasText:x.name}).first();
   const low=list.filter(x=>x.below_minimum);
   assert.ok(low.length>=2);
   for(const x of low.slice(0,2)){
     const status=row(x).locator('.stock-state');
     await status.waitFor();
     assert.match(await status.innerText(),/^Faltam /);
     assert.equal(await status.evaluate(el=>getComputedStyle(el).color),'rgb(180, 35, 24)');
   }
   const noMin=list.find(x=>x.minimum===''), normal=list.find(x=>x.minimum!==''&&!x.below_minimum);
   assert.ok(noMin&&normal);
   assert.equal(await row(noMin).locator('.stock-min').innerText(),'sem mínimo');
   assert.equal(await row(normal).locator('.stock-state').innerText(),'');
   await d.screenshot({path:out+'/capturas/EST-02-variacoes.png'});
   return low.length+' faltas em vermelho. '+noMin.name+' mostra sem mínimo; '+normal.name+' sem texto de situação.';
 });
 let legacy;
 await run('REL-02',d,'Simular um SKU legado sem marca no banco local, receber caixa pela API real e conciliar a posição.',async()=>{
   const name='Hortifruti legado Lab '+stamp;
   const category=(await get(d,'/api/catalog/options')).categories[0].id;
   const item=good(await post(d,'/api/catalog/items',{...op(),name,category_id:category,unit_code:'KG',minimum_stock:'0',active:true}));
   const sql='INSERT INTO product_skus(item_id,brand_id,content_quantity,active) VALUES('+Number(item.id)+',0,1,true) RETURNING id';
   const result=execFileSync('docker',['compose','exec','-T','db','psql','-U','estoque','-d','estoque','-Atq','-v','ON_ERROR_STOP=1','-c',sql],{encoding:'utf8'}).trim();
   const sku=Number(result);
   assert.ok(sku>0,result);
   legacy={item:item.id,sku,name};save('legacy-fixture',legacy);
   good(await post(d,'/api/crates/receive',{...op(),sku_id:sku,warehouse_id:a,unit_cost:'2',document_number:'LAB-REL-SEM-MARCA',weights:['3']}));
   const report=await get(d,'/api/reports/balance?'+new URLSearchParams({before:'2026-11-17T00:00:00-03:00',warehouse_id:String(a)}));
   const stock=await get(d,'/api/stock?warehouse_id='+a);
   for(const x of stock){
     const matching=report.filter(r=>r.item===x.name).reduce((acc,r)=>acc+number(r.quantity),0);
     assert.equal(Math.round(matching*1000),Math.round(number(x.quantity)*1000),x.name);
   }
   const entry=report.find(x=>x.item===name);
   assert.equal(entry.brand,'Sem marca');
   assert.doesNotMatch(JSON.stringify(report),/__LEGACY_UNASSIGNED__/);
   await open(d,'/stock');
   await d.locator('.stock-card').filter({hasText:name}).first().click();
   await d.locator('#stockDetail summary').filter({hasText:'Sem marca'}).first().waitFor();
   await d.screenshot({path:out+'/capturas/REL-02-legado-sem-marca.png'});
   save('report-balance-legacy',{report,entry,stock});
   return 'Posição bate por item. Fixture SQL marca 0 apareceu como “Sem marca” na API de relatório e no detalhe de Estoque.';
 });
 await run('INV-21',d,'Abrir a contagem concluída e tentar aplicar ajuste negativo de lote de caixas pela interface.',async()=>{
   await open(d,'/inventory');
   await d.locator('#inventoryId').fill(String(id));
   await d.locator('#inventoryOpenForm button[type=submit]').click();
   const box=d.locator('[data-sku-id="'+p.crate.sku+'"]');
   await box.getByRole('button',{name:/Ajustar estoque/i}).click();
   const rr=d.waitForResponse(r=>r.url().endsWith('/adjust')&&r.request().method()==='POST');
   await box.getByRole('button',{name:/Confirmar ajuste/i}).click();
   const response=await rr,data=await response.json();
   const text=await d.locator('#inventoryMessage').innerText();
   save('inventory-adjust-ui',{response:response.status(),data,text});
   await d.screenshot({path:out+'/capturas/INV-21-repro.png'});
   assert.ok(response.status()<500,'HTTP '+response.status()+' '+JSON.stringify(data)+'. UI: '+text);
   return response.status()+' '+text;
 });
 await run('INV-13',d,'Verificar registro do ajuste de duas unidades no histórico e o custo unitário da linha ajustada.',async()=>{
   const history=await get(d,'/api/inventory-validations/'+id+'/history');
   const item=history.lines.find(x=>x.sku_id===p.un.sku);
   const mov=item.adjustment_movement_id;
   const q='SELECT row_to_json(t) FROM (SELECT ml.quantity,ml.unit_cost,ml.direction,m.movement_type FROM movement_lines ml JOIN movements m ON m.id=ml.movement_id WHERE m.id='+Number(mov)+') t';
   const result=JSON.parse(execFileSync('docker',['compose','exec','-T','db','psql','-U','estoque','-d','estoque','-Atq','-c',q],{encoding:'utf8'}));
   assert.equal(result.movement_type,'AJUSTE');
   assert.equal(result.direction,'IN');
   assert.equal(number(result.quantity),2);
   assert.equal(number(result.unit_cost),3.2);
   save('inventory-adjust-cost',{mov,result});
   return 'Movimento '+mov+' e histórico. Sobra de 2 un a 3,20 (preço médio).';
 });
 await run('REL-04',d,'Gerar relatório vazio pela interface e consultar intervalo longo.',async()=>{
   await open(d,'/reports');
   await d.locator('[data-period=custom]').click();
   await d.locator('#reportStart').fill('2000-01-01');
   await d.locator('#reportEnd').fill('2000-01-02');
   await d.locator('#reportForm button[type=submit]').click();
   await d.locator('main').getByText(/nenhum|sem movimentaç/i).last().waitFor();
   await d.screenshot({path:out+'/capturas/REL-04-vazio.png'});
   const t=Date.now();
   const all=await get(d,'/api/reports/movements?type=ENTRADA&start=2000-01-01T00:00:00Z&end=2026-11-17T00:00:00Z');
   return 'Tela com estado vazio. Consulta de 26 anos: '+all.length+' linhas em '+(Date.now()-t)+' ms.';
 });
 await run('LAY-10',d,'Navegar por Tab do começo ao fim do ciclo nas 12 telas autenticadas e no login, em ambas as larguras.',async()=>{
   const routes=['/login','/home','/stock','/entry','/exit','/transfer','/crates','/material-requests','/catalog','/products','/inventory','/reports','/admin'];
   const results=[];
   for(const page of [d,m]){
     const width=page.viewportSize().width;
     for(const r of routes){
       const current=r==='/login'?await pageFor(null,width):page;
       await open(current,r);
       await current.waitForLoadState('networkidle');
       await current.evaluate(()=>{
         document.activeElement?.blur();
         let i=0;
         for(const node of document.querySelectorAll('a,button,input,select,summary,textarea,[tabindex]'))node.dataset.labFocus=String(++i);
         window.scrollTo(0,0);
       });
       const grouped=[],seen=new Set();
       let left=false;
       for(let i=0;i<340;i++){
         await current.keyboard.press('Tab');
         const event=await current.evaluate(()=>{
           const el=document.activeElement,s=getComputedStyle(el), rect=el.getBoundingClientRect();
           return {index:el.dataset.labFocus,tag:el.tagName,label:el.getAttribute('aria-label')||el.innerText?.trim().slice(0,65),id:el.id,visible:el.matches(':focus-visible'),outline:s.outline,top:rect.top,width:rect.width,height:rect.height};
         });
         if(event.tag==='BODY'||seen.has(event.index)){left=true;break}
         seen.add(event.index);grouped.push(event);
       }
       results.push({route:r,width,left,grouped});
       if(r==='/login')await current.close();
     }
   }
   save('keyboard-all',results);
   const missing=results.flatMap(x=>x.grouped.filter(y=>!y.visible||y.outline.endsWith('none 0px')).map(y=>({route:x.route,width:x.width,control:y.label||y.id||y.tag})));
   assert.ok(results.every(r=>r.left),'Ciclo de Tab ultrapassou limite em '+results.filter(x=>!x.left).map(x=>x.route+' '+x.width).join(', '));
   assert.deepEqual(missing,[]);
   return 'Ciclos completos de Tab nas 26 aberturas, '+results.reduce((n,x)=>n+x.grouped.length,0)+' focos registrados.';
 });
});
