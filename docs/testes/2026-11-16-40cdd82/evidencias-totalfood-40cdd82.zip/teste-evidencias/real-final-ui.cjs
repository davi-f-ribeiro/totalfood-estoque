const fs=require('node:fs');
const {assert,base,out,op,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-final-ui');
main(async()=>{
 const {a,b,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'), m=await pageFor('d',390), e=await pageFor('e',390);
 await run('EST-02',d,'No VR, validar dois itens abaixo do mínimo, item normal e Água Mineral sem mínimo.',async()=>{
   await open(d,'/stock');
   const r=d.waitForResponse(x=>new URL(x.url()).pathname==='/api/stock'&&new URL(x.url()).searchParams.get('warehouse_id')===String(a));
   await d.locator('#warehouse').selectOption(String(a));await r;
   const list=await get(d,'/api/stock?warehouse_id='+a);
   const low=list.filter(x=>x.below_minimum);
   const exact=x=>d.locator('#stockList .stock-card').filter({hasText:x.name}).first();
   assert.ok(low.length>=2);
   for(const x of low.slice(0,2)){
     const status=exact(x).locator('.stock-state');
     await status.waitFor();
     assert.match(await status.innerText(),/^Faltam /);
     assert.equal(await status.evaluate(el=>getComputedStyle(el).color),'rgb(180, 35, 24)');
   }
   const noMin=list.find(x=>x.minimum===''), normal=list.find(x=>number(x.minimum)>0&&!x.below_minimum);
   assert.ok(noMin&&normal,'Massa com mínimo nulo e item normal indisponível '+JSON.stringify(list));
   assert.equal(await exact(noMin).locator('.stock-min').innerText(),'sem mínimo');
   assert.equal(await exact(normal).locator('.stock-state').innerText(),'');
   await d.screenshot({path:out+'/capturas/EST-02-variacoes.png'});
   return low.length+' faltas em vermelho, '+noMin.name+' com sem mínimo e '+normal.name+' com situação em branco.';
 });
 await run('ADM-08',d,'Abrir lista de permissões de um perfil e procurar identificadores internos.',async()=>{
   await open(d,'/admin');
   await d.locator('#adminProfilesList').getByText('Estoquista',{exact:false}).first().click();
   const names=(await d.locator('#adminPerms').innerText()).split('\n').map(s=>s.trim()).filter(Boolean);
   save('permission-labels',names);
   const raw=names.filter(x=>/^(delivery|dispatch|logistics|material_requests|material_fulfillment|stock_adjustment|movement_entry)$/.test(x));
   assert.deepEqual(raw,[],'Rótulos internos na tela: '+raw.join(', '));
   return 'Rótulos legíveis em português.';
 });
 await run('INV-03',m,'Criar contagem cega, abrir as linhas no celular e guardar as estruturas de rede.',async()=>{
   const created=good(await post(d,'/api/inventory-validations/blind',op()));
   const path='/api/inventory-validations/'+created.id;
   try{
     await open(m,'/inventory');
     await m.locator('#inventoryId').fill(String(created.id));
     await m.locator('#inventoryOpenForm button[type=submit]').click();
     const lines=m.locator('#inventoryLines');
     await lines.locator('.inventory-line').first().waitFor();
     const body=await lines.innerText(), r=await get(m,path+'/counting'), header=await get(m,path);
     save('blind-network',{created,view:r,header,body});
     assert.doesNotMatch(JSON.stringify({created,r,header}),/system_quantity|reference_quantity|snapshot_quantity|current_stock/);
     assert.doesNotMatch(body,/Quantidade no sistema|Estoque do sistema|Saldo do sistema/i);
     await m.screenshot({path:out+'/capturas/INV-03-cega-390.png'});
     return 'Não revelou saldo na tela nem nas respostas de criação, contagem e metadados.';
   } finally {await post(d,path+'/cancel',{cancellation_reason:'Fim do cenário de contagem cega'})}
 });
 await run('MOV-08',e,'Abortar antes da gravação, usar Conferir e Enviar de novo, preservando a identificação.',async()=>{
   const warehouse=a, path='/api/movements/exit/batch';
   const qty=async()=>number((await get(d,'/api/stock?warehouse_id='+warehouse)).find(x=>x.item_id===p.un.item)?.quantity);
   const before=await qty();
   await open(e,'/exit');
   await e.locator('#batchWarehouse').selectOption(String(warehouse));
   await e.locator('#batchSearch').fill(p.un.barcode);
   await e.locator('#batchSearch').press('Enter');
   await e.locator('.batch-row').first().waitFor();
   let firstId, replayId, requests=0;
   await e.route('**'+path,async route=>{
     const body=route.request().postDataJSON();
     if(++requests===1){firstId=body.operation_id;return route.abort('failed')}
     replayId=body.operation_id;return route.continue();
   });
   await e.locator('#batchSubmit').click();
   await e.locator('#batchPending').waitFor();
   assert.equal(await qty(),before);
   assert.ok(await e.locator('#batchScan').isDisabled());
   await e.locator('#batchCheck').click();
   await e.locator('#batchRetry').waitFor();
   const reply=e.waitForResponse(r=>r.url().endsWith(path)&&r.request().method()==='POST');
   await e.locator('#batchRetry').click();
   const response=await reply;
   assert.equal(response.status(),200,await response.text());
   await e.locator('#batchPending').waitFor({state:'hidden'});
   assert.equal(replayId,firstId);
   assert.equal(await qty(),before-1);
   await e.unroute('**'+path);
   return 'Envio que não chegou ao servidor: conferência encontrou ausência, reenvio com mesmo ID e uma baixa. Resposta perdida após gravação coberta no roteiro anterior.';
 });
 const layout=JSON.parse(fs.readFileSync(out+'/layout-detail.json'));
 await run('LAY-06',d,'Inspecionar bordas externas dos painéis visíveis nas capturas.',async()=>{
   const decorated=layout.flatMap(x=>x.panels.filter(y=>y.border.split(' ').every(v=>parseFloat(v)>0)||y.background!=='rgba(0, 0, 0, 0)'&&y.background!=='rgb(255, 255, 255)').map(p=>({route:x.route,width:x.width,p})));
   save('layout-panels-found',decorated);
   assert.deepEqual(decorated,[]);
   return 'Painéis de página sem contorno fechado ou fundo colorido nas capturas.';
 });
 await run('LAY-07',d,'Conferir estados e avisos visíveis de telas com registros.',async()=>{
   const files=['req-end','inventory-end'].map(n=>JSON.parse(fs.readFileSync(out+'/'+n+'.json')));
   const requests=files[0], inv=files[1];
   const details=[];
   for(const page of [d,m]){
     await open(page,'/material-requests');
     await page.locator('#materialList button').filter({hasText:new RegExp('^#'+requests.big+' ·')}).first().click();
     await page.locator('.material-delivery').first().waitFor();
     await page.screenshot({path:out+'/capturas/layout-preenchida-req-'+page.viewportSize().width+'.png'});
     details.push(await page.evaluate(()=>[...document.querySelectorAll('.material-tag,.operation-feedback')].filter(e=>e.getClientRects().length).map(e=>({text:e.textContent,radius:getComputedStyle(e).borderRadius,bg:getComputedStyle(e).backgroundColor}))));
     await open(page,'/inventory');
     await page.locator('#inventoryId').fill(String(inv.id));
     await page.locator('#inventoryOpenForm button[type=submit]').click();
     await page.locator('#inventoryLines .inventory-line').first().waitFor();
     await page.screenshot({path:out+'/capturas/layout-preenchida-inv-'+page.viewportSize().width+'.png'});
   }
   save('layout-data-status',details);
   assert.ok(details.flat().every(x=>!parseFloat(x.radius)&&x.bg==='rgba(0, 0, 0, 0)'));
   return 'Situações em texto no detalhe de Requisições e Contagem, com registros e capturas nas duas larguras.';
 });
 await run('LAY-10',d,'Analisar a ordem inicial do Tab e a indicação de foco da captura de cada tela.',async()=>{
   const invisible=layout.flatMap(x=>x.focus.filter(y=>y.tag!=='BODY'&&y.focusVisible&&y.outline.endsWith('none 0px')).map(y=>({route:x.route,width:x.width,...y})));
   save('layout-focus-candidates',invisible);
   assert.deepEqual(invisible,[]);
   return 'Primeiros 18 Tabs por tela registraram foco nativo ou CSS; ordem por tela no layout-detail.json.';
 });
 await run('TRV-05',d,'Inspecionar mensagens no log HTTP e o 500 ao ajustar item controlado por caixa.',async()=>{
   const r=JSON.parse(fs.readFileSync(out+'/crate-adjust-result.json'));
   assert.doesNotMatch(JSON.stringify(r.body),/Erro interno|Operação registrada/i,'Ajuste de caixa devolve “Erro interno.”, sem dizer que a baixa precisa ocorrer pela caixa.');
   return 'Mensagens avaliadas com ação identificada.';
 });
});
