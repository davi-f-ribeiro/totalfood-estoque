const {fs}=require('node:fs');
const h=require('./real-common.cjs');
const {assert,base,out,pageFor,open,api,bad,rows,main,save,skip}=h;
const run=rows('real-roles-layout');
const routes=['/home','/stock','/entry','/exit','/transfer','/crates','/material-requests','/catalog','/products','/inventory','/reports','/admin'];
const roles=['d','g','e','c'];
const rbac=[];
const layouts=[];
const forbidden=[
 ['Entrada','/api/movements/entry/batch'],['Saída','/api/movements/exit/batch'],
 ['Transferência','/api/movements/transfer/batch'],['Caixas','/api/crates/receive'],
 ['Catálogo','/api/catalog/items'],['Separação','/api/material-requests/1/reserve'],
 ['Entrega','/api/material-requests/1/deliver'],['Ajuste','/api/inventory-validations/1/lines/1/adjust'],
 ['Administração','/api/admin/users']
];
main(async()=>{
 const d=await pageFor('d');
 for(const role of roles){
   const p=role==='d'?d:await pageFor(role);
   const menu=await p.locator('nav a, .mobile-nav a').evaluateAll(ns=>Array.from(new Set(ns.map(n=>n.getAttribute('href')))));
   for(const route of [...routes,'/fiscal']){
     const t=Date.now(), resp=await open(p,route);
     const text=(await p.locator('main').first().innerText().catch(()=>p.locator('body').innerText())).trim().slice(0,240);
     rbac.push({role,route,menu:menu.includes(route),status:resp.status(),url:p.url(),text,ms:Date.now()-t});
   }
   if(role==='c'){
     await run('ACE-04',p,'Cozinha abre /admin pela URL e verifica os links da navegação.',async()=>{
       const row=rbac.find(x=>x.role==='c'&&x.route==='/admin');
       assert.equal(row.status,403);
       assert.equal(row.menu,false);
       assert.doesNotMatch(row.text,/Redefinir senha|Criar usuário/);
       return 'HTTP 403, link ausente e sem formulário administrativo.';
     });
     await open(p,'/material-requests');
     const denied=[];
     for(const [feature,url] of forbidden) {
       const r=await api(p,'POST',url,{});
       denied.push({feature,url,...r});
     }
     save('kitchen-denied',denied);
     await run('PERM-02',p,'POST autenticado como Cozinha, com CSRF válido, em nove rotas de escrita fora do perfil.',async()=>{
       assert.deepEqual(denied.map(x=>x.status),forbidden.map(()=>403));
       return denied.map(x=>x.feature+': '+x.status).join(' | ');
     });
   }
 }
 save('permissions-matrix',rbac);
 await run('PERM-01',d,'Comparar links do menu e resposta das 13 URLs pelos quatro perfis.',async()=>{
   assert.equal(rbac.length,52);
   const anomalies=rbac.filter(r=>r.menu!==(r.status===200));
   assert.deepEqual(anomalies,[]);
   return '52 combinações registradas e menu coerente com HTTP.';
 });
 await run('ACE-08',d,'Com sessão ativa, enviar POST /api/admin/users sem X-CSRF-Token.',async()=>{
   await open(d,'/admin');
   const r=await d.evaluate(async()=>{const r=await fetch('/api/admin/users',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});return {status:r.status,body:await r.json()}});
   save('csrf-missing',r);bad(r,null,403);return r.status+' '+JSON.stringify(r.body);
 });
 for(const width of [390,1366]){
   const p=width===1366?d:await pageFor('d',390);
   for(const route of ['/login',...routes]){
     const page=route==='/login'?await pageFor(null,width):p;
     const network=[], from=Date.now(), record=r=>network.push({url:r.url(),status:r.status(),type:r.request().resourceType()});
     page.on('response',record);
     const http=await open(page,route);
     await page.waitForLoadState('networkidle');
     const data=await page.evaluate(async()=>{
       await document.fonts.ready;
       const visible=e=>e.getClientRects().length&&getComputedStyle(e).visibility==='visible';
       const desc=e=>({tag:e.tagName,id:e.id,cls:typeof e.className==='string'?e.className:'',text:e.innerText?.trim().slice(0,100)||e.getAttribute('aria-label')||''});
       const all=[...document.body.querySelectorAll('*')].filter(visible);
       const shadow=[],radius=[],green=[],tiny=[],touch=[],wording=[];
       for(const e of all){
         const s=getComputedStyle(e), box=e.getBoundingClientRect(), own=[...e.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
         if(s.boxShadow!=='none')shadow.push({...desc(e),value:s.boxShadow});
         if(['borderTopLeftRadius','borderTopRightRadius','borderBottomLeftRadius','borderBottomRightRadius'].some(k=>parseFloat(s[k])>4))radius.push({...desc(e),value:s.borderRadius});
         if(own&&(s.color==='rgb(128, 187, 4)'||s.backgroundColor==='rgb(128, 187, 4)'&&s.color!=='rgb(0, 0, 0)'))green.push({...desc(e),color:s.color,background:s.backgroundColor});
         if(own&&parseFloat(s.fontSize)<14&&!e.closest('.mobile-nav,.bottom-nav,.mobile-bar'))tiny.push({...desc(e),value:s.fontSize});
         if(innerWidth===390&&e.matches('button,a[href],input:not([type=checkbox]):not([type=radio]),select,textarea')&&box.height>0&&box.height<44)touch.push({...desc(e),px:box.height});
         if(own&&/(Saldo|!)/.test(own)&&e.matches('h1,h2,h3,label,p,button,a,span,th,td'))wording.push({...desc(e),value:own.slice(0,120)});
       }
       return {overflow:document.documentElement.scrollWidth-innerWidth, fonts:[...document.fonts].map(f=>[f.family,f.weight,f.status]), shadow,radius,green,tiny,touch,wording,
         current:[...document.querySelectorAll('nav [aria-current=page], [aria-current=page]')].filter(visible).map(e=>({...desc(e),background:getComputedStyle(e).backgroundColor,color:getComputedStyle(e).color})),
         panels:[...document.querySelectorAll('.panel')].filter(visible).map(e=>({...desc(e),border:getComputedStyle(e).borderWidth,background:getComputedStyle(e).backgroundColor})),
         statusShapes:[...document.querySelectorAll('.badge,.material-tag,.operation-feedback,.inventory-review-line')].filter(visible).map(e=>({...desc(e),background:getComputedStyle(e).backgroundColor,radius:getComputedStyle(e).borderRadius}))};
     });
     let axe;
     try{
       const fs=require('node:fs');
       const src=fs.readFileSync('/tmp/tf-axe/node_modules/axe-core/axe.min.js','utf8');
       await page.evaluate(src);
       axe=await page.evaluate(async()=>(await window.axe.run({runOnly:{type:'rule',values:['color-contrast']}})).violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))})));
     }catch(err){axe={error:err.message}}
     const focus=[];
     for(let i=0;i<18;i++){
       await page.keyboard.press('Tab');
       focus.push(await page.evaluate(()=>{const e=document.activeElement,s=getComputedStyle(e);return {id:e.id,tag:e.tagName,text:e.innerText?.trim().slice(0,75),outline:s.outline,focusVisible:e.matches(':focus-visible')}}));
     }
     page.removeListener('response',record);
     const name=route.slice(1);
     await page.screenshot({path:out+'/capturas/layout-'+width+'-'+name+'.png'});
     layouts.push({route,width,http:http.status(),page:page.url(),ms:Date.now()-from,network,axe,focus,...data});
     save('layout-detail',layouts);
     if(route==='/login')await page.close();
   }
   if(width===390)await p.close();
 }
 const relevant=layouts.filter(x=>x.route!=='/login');
 const check=async(id,prop,label)=>{
   await run(id,d,label,async()=>{
     const hits=layouts.filter(x=>x[prop].length).map(x=>({route:x.route,width:x.width,n:x[prop].length,sample:x[prop][0]}));
     assert.deepEqual(hits,[]);return '26 capturas e inspeção de estilo computado.';
   });
 };
 await run('LAY-01',d,'Ler FontFaceSet e respostas de fontes nas 26 aberturas.',async()=>{
   assert.ok(layouts.every(x=>[400,600].every(w=>x.fonts.some(([name,weight])=>name.includes('Barlow')&&Number(weight)===w))));
   const fonts=layouts.flatMap(x=>x.network.filter(n=>n.type==='font'));
   assert.ok(fonts.length&&fonts.every(n=>n.url.startsWith(base+'/static/fonts/')));
   return 'Pesos 400/600 registrados; recursos somente em /static/fonts/.';
 });
 await check('LAY-02','shadow','Verificar sombra CSS dos elementos visíveis.');
 await check('LAY-03','radius','Verificar raios computados visíveis acima de 4 px.');
 await check('LAY-04','green','Verificar uso da cor verde no texto e contraste do fundo.');
 await check('LAY-05','tiny','Verificar tamanho de texto em elementos visíveis.');
 await run('LAY-08',d,'Comparar cor do item atual visível no menu.',async()=>{
   const invalid=relevant.filter(x=>!x.current.some(c=>c.background==='rgb(128, 187, 4)'&&c.color==='rgb(0, 0, 0)')).map(x=>x.route+' '+x.width);
   assert.deepEqual(invalid,[]);
   return 'Item corrente visível com fundo verde e texto preto.';
 });
 await run('LAY-09',d,'Rodar a regra de contraste do axe-core nas visões documentadas.',async()=>{
   if(layouts.some(x=>x.axe?.error))skip('axe-core não foi executado em todas as telas; veja layout-detail.json.');
   const invalid=layouts.filter(x=>x.axe.length).map(x=>x.route+' '+x.width);
   assert.deepEqual(invalid,[]);
   return 'Axe-core sem violações na regra color-contrast para as capturas.';
 });
 await run('LAY-11',d,'Medir largura rolável e altura de controles visíveis a 390 px.',async()=>{
   const hits=layouts.filter(x=>x.width===390&&(x.overflow>0||x.touch.length)).map(x=>({route:x.route,overflow:x.overflow,smallControls:x.touch.length,sample:x.touch[0]}));
   assert.deepEqual(hits,[]);
   return 'Sem overflow nem controles abaixo de 44 px.';
 });
 await run('LAY-12',d,'Procurar pontuação proibida visível na tela de entrada.',async()=>{
   const hits=layouts[0].wording.filter(x=>x.value.includes('!'));
   assert.deepEqual(hits,[]);
   return 'Nenhuma exclamação na tela de login.';
 });
});
