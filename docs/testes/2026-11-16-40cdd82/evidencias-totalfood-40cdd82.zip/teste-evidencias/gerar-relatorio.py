from collections import Counter
from pathlib import Path
import json
import re

root = Path('teste-evidencias')
def read(name, default=None):
    path = root / (name + '.json')
    return json.loads(path.read_text()) if path.is_file() else default

def text(name):
    path = root / name
    return path.read_text().strip() if path.is_file() else ''

def row(id, estado, obs, evidence=None, steps=None):
    o = dict(id=id, estado=estado, obs=obs)
    if evidence:
        o['evidence'] = evidence
    if steps:
        o['steps'] = steps
    return o

sources = [
    'real-access','real-mov-catalog','real-roles-layout','real-admin','real-mov-retry',
    'real-crates','real-requests','real-inventory-retry','real-stock-retry','real-esp',
    'real-mov-access-retry','real-inventory-catalog-extra','real-requests-ui','real-cross',
    'real-print-retry','real-session-proof','real-mov-entry-final','real-replay','real-final-ui',
    'real-validation-final','real-integrity-final','real-full-axe'
]
cases = {}
for source in sources:
    for case in read(source, []):
        cases[case['id']] = {**case, 'source':source}

def brief(id, obs, estado=None, evidence=None):
    c=cases[id]
    c['obs']=obs
    if estado:
        c['estado']=estado
    if evidence:
        c['evidence']=evidence

def correct():
    brief('ADM-08','A tela mostrou identificadores internos delivery e dispatch na lista de permissões.','falhou')
    brief('EST-06','Ao trocar VR por Câmara Fria, os controles mantiveram busca e filtro, mas voltaram a aparecer Melão e Pote.','falhou')
    brief('EST-07','Atalhos e quantidade de falta presentes. A coluna “Falta” mostra apenas o número, em divergência com “Faltam X” em Estoque.','falhou')
    brief('LAY-05','Barra inferior a 11 px frente à exceção de 12 px. Textos de listas de Catálogo, Produtos e Administração no desktop a 13,33 px.','falhou')
    brief('LAY-08','Catálogo, Produtos, Contagem, Relatórios e Administração não indicaram a página atual na barra inferior fechada de 390 px.','falhou')
    brief('LAY-11','Sem rolagem lateral nas aberturas medidas. Em Caixas, link de Administração com 17 px de altura, abaixo dos 44 px.','falhou')
    brief('LAY-12','O slogan de login “Qualidade todo dia!” contém ponto de exclamação.','falhou')
    brief('TRV-01','20 rotas exercitadas. Encerramento de requisição respondeu 200 com o mesmo operation_id e observação alterada. Os demais replays exercitados mantiveram o resultado.','falhou')
    brief('ACE-04','Cozinha foi redirecionada a /no-access, sem menu administrativo ou dados da tela. HTTP 200 pertence à tela de destino.', 'passou')
    brief('ACE-06','Servidor devolveu HTTP 401 “Entre para continuar.” Produtos fechou o formulário e exibiu “Cadastro sem confirmação” com “Enviar de novo”.', 'falhou')
    brief('ACE-07','Voltar abriu /home com conteúdo e navegação em cache. /api/me retornou 401 e recarregar redirecionou a /login.', 'falhou', 'capturas/ACE-07-historico-antes-reload.png')
    brief('ADM-02','Senha redefinida aceita. O novo login entrou diretamente em /home, sem obrigar a troca.', 'falhou')
    brief('ADM-04','A remoção da permissão revogou a sessão. A próxima consulta foi recusada com HTTP 401 “Entre para continuar.”','passou')
    brief('ADM-07','HTTP 201 no primeiro cadastro. O token apareceu uma vez e desapareceu ao recarregar. O nome já usado retornou HTTP 409 na rodada seguinte.','passou')
    brief('CAT-04','Criar SKU de Melão com brand_id=0 via API retorna HTTP 400 e exige marca. O restante do teste de caixas usou um SKU com marca fictícia.','falhou')
    brief('CAT-06','Botão “+ Novo produto” apareceu para usuário somente com leitura. O backend recusou a escrita com HTTP 403.','falhou')
    brief('PERM-01','A grade abaixo preserva os quatro perfis antes de qualquer concessão. Gerente e Estoquista só abriram Requisições dentre as 13 rotas.','falhou')
    if cases.get('REQ-02',{}).get('source') == 'real-requests-ui' and 'Separando 102,9' in cases['REQ-02']['obs']:
        brief('REQ-02','Separação confirmou HTTP 201 na tela. No fluxo básico, o pedido ficou EM_SEPARACAO, o estoque físico não mudou e uma saída acima do livre recebeu HTTP 409.','passou')
    brief('REQ-13','200 kg entregues e 180 kg conferidos com motivo. API mostrou RECEBIDA_COM_DIVERGENCIA e 20 kg pendentes. O mesmo componente exibiu a falta em texto no fluxo móvel de 102,9 kg.','passou')
    brief('REQ-17','A posição de estoque permaneceu idêntica e a entrega conservou seu movimento durante a conferência e as duas conciliações.','passou')
    brief('REQ-21','Não permitiu 110 un para pedido de 106 un. A recusa de UN menciona 20% para KG, desnecessário nesse contexto.','passou')
    brief('INV-11','Após recontar cada divergência, a conclusão sem observação retornou 400. Com observação, ficou COMPLETED.','passou')
    brief('INV-21','Conta o peso por SKU. Ao ajustar redução de 10 kg do lote de duas caixas, HTTP 500 “Erro interno.”, saldo e pesos preservados. Na tela, “O ajuste ficou sem confirmação”.','falhou','capturas/INV-21-repro.png')
    if cases.get('REL-02', {}).get('source') != 'real-validation-final':
        brief('REL-02','A posição de estoque bateu por item. A conferência do rótulo para dados legados ficou sem evidência integral.','não executado')
    brief('REL-05','Pesagem e entrega REQ-n apareceram. O ajuste entrou na posição de estoque e ficou fora do relatório de movimentações. API com tipo AJUSTE retornou HTTP 400.','falhou')
    brief('TRV-04','Dois HTTP 500 no mesmo ajuste de lote controlado por caixa, primeiro via API e depois na interface. Nenhum outro 5xx na trilha registrada.','falhou')
    brief('TRV-10','Entradas, caixas, requisição, recebimento parcial, encerramento, pesagem, contagem e ajuste concluídos. Ledger bateu linha a linha. Relatórios omitiram o ajuste.','falhou')
    if read('esp-verified-artifact'):
        brief('ESP-03','FW_VERSION 1.7.0. O workflow publicou totalfood-esp32-s3-n16r8-v1.7.0 no run 43848227831. Arquivos de firmware e workflow idênticos aos do SHA testado.','passou')
correct()

ids=[]
for prefix,count in [
    ('ACE',9),('ADM',8),('CAT',6),('MOV',10),('EST',8),('CX',14),
    ('REQ',36),('INV',23),('REL',5)
]:
    ids.extend(f'{prefix}-{n:02d}' for n in range(1,count+1))
ids.extend(['PERM-01','PERM-02'])
for prefix,count in [('LAY',12),('ESP',4),('TRV',10)]:
    ids.extend(f'{prefix}-{n:02d}' for n in range(1,count+1))
for case_id in ids:
    if case_id not in cases:
        cases[case_id]=row(case_id,'não executado','Sem evidência suficiente para fechar o cenário.')
summary=Counter(cases[id]['estado'] for id in ids)

def cell(s, n=390):
    s=re.sub(r'\x1b\[[0-9;]*m','',str(s))
    s=' '.join(s.split())
    if len(s)>n:
        s=s[:n-1].rstrip()+'…'
    return s.replace('|','\\|').replace('<','&lt;')

def ref(name):
    path=root/name
    return f'[{name}]({path.as_posix()})' if path.is_file() else f'`{name}`'

def case_links(c):
    links=[]
    if c.get('evidence') and (root/c['evidence']).is_file():
        links.append(ref(c['evidence']))
    if c.get('source'):
        links.append(ref(c['source']+'.json'))
    return ', '.join(links)

timings={}
for x in text('auto-timed.tsv').splitlines():
    columns=x.split('\t')
    if len(columns)==3:
        timings[columns[0]]=columns[1:]

automatic=[
    ('go vet ./...', 'vet'),
    ('go test -count=1 ./... (com PostgreSQL, modo verboso)', 'go-db-verbose'),
    ('go test -race -count=1 -timeout 30m ./... (com PostgreSQL, modo verboso)', 'race-db'),
    ('go build ./...', 'build-time'),
    ('node --check (todos os *.js em cmd/server/static)', 'js-time'),
    ('python3 -m unittest discover -s firmware/tests -p test_*.py -v', 'firmware-time'),
    ('docker build -t totalfood-estoque:teste .', 'docker-build-time'),
    ('npm install playwright@1.56.1', 'npm-time'),
    ('node scripts/crates-playwright-e2e.cjs', 'crates-pw-time'),
    ('node scripts/exit-batch-mobile-playwright-e2e.cjs', 'exit-pw-time'),
    ('node scripts/material-requests-playwright-e2e.cjs', 'requests-pw-time'),
    ('go test -count=3 ./cmd/server (com PostgreSQL, timeout padrão de 10 min)', 'repeats-db-early'),
    ('go test -count=3 -timeout 35m ./cmd/server (com PostgreSQL, modo verboso)', 'repeats-db-35m'),
]
out=[]
def add(s=''):
    out.append(s)
commit = text('commit.txt') or '40cdd82'
add('# Relatório de teste — TotalFood Estoque')
add()
add('## 1. Resumo')
add()
add(f'Execução de 16/11/2026 (Fortaleza), branch `main`, commit `{commit}`. Teste no Docker local em `127.0.0.1:5656`. Seção 5.10 excluída. A rota `/fiscal` entrou apenas na matriz de navegação da seção 5.11, sem leitura de QR, confirmação ou requisição fiscal externa. Os módulos da segunda etapa ficaram fora dos roteiros. A suíte existente foi executada como fornecida.')
add()
add(f'**{len(ids)} casos no escopo · {summary["passou"]} passaram · {summary["falhou"]} falharam · {summary["não executado"]} não executados integralmente.** `PERM-01` e `PERM-02` são os dois controles da seção 5.11. Os casos NF-01 a NF-03 ficam fora desses números.')
add()
add('As movimentações, as duas etapas de recebimento parcial, a entrega com cinco caixas, a contagem e o ajuste de produto comum funcionaram na base real. Os principais achados são os perfis de origem sem acesso ao estoque, a tela restaurada pelo histórico após sair, o erro 500 em ajuste de caixa e a ausência de ajustes no relatório exigido pelo plano.')
add()
add('Os testes usaram Playwright 1.56.1 com Chrome local em 390×844 e 1366×900. Casos de tela e chamadas à API de verdade estão diferenciados nos passos. A câmera foi simulada no navegador, com busca e persistência reais. A impressora foi simulada via curl. Segue o ambiente registrado.')
add()
add('```text\n'+text('environment.txt')+'\n```')
add()
fixture=read('fixture',{})
add('### Preparação')
add()
add('O banco do Compose foi iniciado com volume novo. /health respondeu 200 após inicialização. O primeiro curl foi cedo demais e recebeu conexão encerrada. A tabela schema_migrations registrou os 43 arquivos, e a recriação do app com bootstrap desativado preservou versões e horários. O bootstrap foi desligado depois da criação das contas antes das operações de estoque. O reset de senha a cada partida com bootstrap ligado está no código, mas não atrapalhou depois de desligado.')
add()
add('O Diretor entrou pela tela do Playwright e cadastrou quatro contas pela Administração. A configuração inicial dos perfis foi capturada antes da intervenção. Para prosseguir na instância de teste, foram acrescentadas permissões de leitura de estoque/catálogo, entrada, saída e transferência ao Estoquista e de estoque, catálogo, relatórios, contagem e ajuste ao Gerente. A Cozinha conservou as permissões iniciais.')
add()
add(f'Na preparação por API autenticada, {fixture.get("setupWrites","—")} gravações bem-sucedidas levaram aproximadamente {fixture.get("fixtureMs","—")} ms de ponta a ponta no ambiente local, além da tentativa de SKU sem marca recusada. Foram feitas uma ativação de depósito e entradas posteriores. O tempo mede a automação e não a operação manual. Para continuar os fluxos de caixa após CAT-04, foi usada marca fictícia. A busca de mínimo nulo usou o item legado Água Mineral. REL-02 acrescentou uma fixture de SKU legado diretamente no banco local com brand_id=0, usando o mesmo padrão de TestActiveCratesListAndUnbrandedLabel. O recebimento e as consultas foram feitos pela aplicação. Evidências em {ref("fixture.json")}, {ref("setup.json")}, {ref("profiles-before.txt")} e {ref("profile-grants.json")}.')
add()
add('## 2. Suíte automática')
add()
add('| Comando | Resultado | Tempo de parede | Evidência |')
add('|---|---|---:|---|')
for cmd,key in automatic:
    t=timings.get(key)
    status='passou' if t and t[0]=='0' else ('falhou' if t else 'sem resultado final')
    if key=='repeats-db-early' and t and t[0]!='0':
        status='interrompido pelo timeout padrão'
    add(f'| `{cmd}` | {status} | {t[1] if t else "—"} | {ref(key+".log")} |')
add('| `TestWarehouseNameIsUniqueForTracking` com banco | passou | 1,765 s em Go | '+ref('warehouse-unique.log')+' |')
add()
add('Os três roteiros JavaScript da seção 4 avaliam a interface com API simulada. Os casos da seção 5 usam outra execução, com login real. Tempos de parede estão arredondados ao segundo. 0 s representa duração abaixo da resolução da medição.')
add()
for label,key in [('Go com banco','go-db-verbose'),('Go race com banco','race-db'),('Três repetições com banco','repeats-db-35m')]:
    data=text(key+'.log')
    skips=len(re.findall(r'^\s*--- SKIP:',data,re.M))
    fail=len(re.findall(r'^\s*--- FAIL:',data,re.M))
    passes=len(re.findall(r'^\s*--- PASS:',data,re.M))
    finished=key in timings
    add(f'- {label} — {passes} resultados PASS, {fail} FAIL e {skips} SKIP no log {"final" if finished else "até a última leitura"}. {ref(key+".log")}')
add()
if 'repeats-db-35m' in timings:
    data=text('repeats-db-35m.log')
    top=re.findall(r'^--- (PASS|FAIL|SKIP): (\S+)',data,re.M)
    seen={}
    for state,name in top:
        seen.setdefault(name,[]).append(state)
    flaky=[k for k,v in seen.items() if len(set(v))>1]
    add('- Instabilidade entre as três rodadas — '+(', '.join(flaky) if flaky else 'nenhuma detectada')+'.')
    add('- A primeira execução com limite padrão atingiu 10 min. A execução confirmatória usou limite de 35 min, preservando os testes, o banco isolado e o commit.')
add('- `TestWarehouseMigration019IncrementalAndIdempotent` falhou na suíte de repetição em banco reutilizado com `permission=1 index=2 triggers=10`. O teste consulta pg_indexes e pg_trigger sem restringir o schema. A execução interrompida aos 10 min deixou um schema residual, que aparece na inspeção junto ao schema da execução ativa. Em outro banco vazio, o mesmo teste passou nas três chamadas. Evidência em '+ref('warehouse-m019-scopes.txt')+', '+ref('warehouse-m019-fresh.log')+' e '+ref('repeats-db-35m.log')+'. O TRV-09 verificou idempotência das migrações no banco da aplicação.')
add('- O teste do nome de depósito passou no PostgreSQL 17 Alpine desta rodada. Também houve recusa HTTP 409 de nome repetido com caixa e espaços alterados na instância do app. O banco de teste usou en_US.utf8. A divergência de locale informada pelo plano não se reproduziu neste ambiente.')
add()
add('## 3. Casos')
add()
add('| ID | Resultado | Observação | Evidência |')
add('|---|---|---|---|')
for id in ids:
    c=cases[id]
    add(f'| {id} | {c["estado"]} | {cell(c.get("obs",""))} | {case_links(c)} |')
add()
add('### Matriz de acesso inicial')
add()
add('Cada célula mostra presença no menu e abertura pela URL. “Bloqueou” indica redirecionamento a /no-access. O HTTP final dessa tela é 200 e não contém dados da tela pedida.')
add()
rbac=read('permissions-matrix',[])
if rbac:
    add('| Rota | Diretor | Gerente | Estoquista | Cozinha |')
    add('|---|---|---|---|---|')
    for route in dict.fromkeys(x['route'] for x in rbac):
        values=[]
        for who in ['d','g','e','c']:
            x=next(x for x in rbac if x['role']==who and x['route']==route)
            values.append(('Sim' if x['menu'] else 'Não')+' / '+('abriu' if x['url'].endswith(route) else 'bloqueou'))
        add('| `'+route+'` | '+' | '.join(values)+' |')
    add()
    add('Cozinha recebeu 403 em todas as nove tentativas de gravação (entrada, saída, transferência, caixas, catálogo, separação, entrega, ajuste e administração). '+ref('kitchen-denied.json'))
    if read('permissions-390-configured'):
        add(' A coleta adicional a 390 px após as concessões está em '+ref('permissions-390-configured.json')+'.')
add()
checks=read('axe-summary',{})
if checks:
    add('### Achados adicionais do axe-core')
    add()
    add('| Regra | Ocorrências nas aberturas |')
    add('|---|---:|')
    for name,count in sorted(checks.items()):
        add(f'| `{name}` | {count} |')
    add()
    add('Em Início, o axe encontrou linhas sem o contexto de tabela esperado. Nas telas de lote vazias, encontrou tabelas sem os elementos filhos exigidos. Seletores e mensagens por tela e largura em '+ref('axe-full.json')+'.')
    add()
add('## 4. Defeitos')
add()
defect_groups=[
('PERM-01','bloqueia operação','Criar Gerente e Estoquista com os perfis do banco novo. Entrar e abrir Estoque, Entrada e Relatórios.','Gerente acessa as telas de gestão pertinentes e Estoquista pode receber, retirar, transferir e operar caixas.','Ambos têm somente Requisições entre as 13 rotas testadas. Estoquista também recebe 403 nas APIs de movimentação.','permissions-matrix.json','profiles-before.txt','real-mov-catalog.log','capturas/PERM-01-real-roles-layout.png'),
('ACE-07','dado errado','Entrar como Diretor, abrir Início, clicar em Sair e voltar no navegador. Em seguida chamar /api/me e recarregar.','A sessão encerrada impede visualizar a página anterior.','Início foi exibida com o menu e conteúdo, mesmo com /api/me em 401. Recarregar voltou para login.','logout-history.json','capturas/ACE-07-historico-antes-reload.png'),
('INV-21 / TRV-04 / TRV-05','bloqueia operação','Receber caixas de 3 e 7 kg. Abrir contagem, contar zero, recontar zero, concluir com observação e aplicar ajuste da redução.','Preservar rastreabilidade e orientar a baixa pela caixa quando o ajuste agregado não for permitido.','Resposta 500 com Erro interno. O log diz stock is tracked by individual crates. Pesos e saldo continuam em 10 kg.','crate-adjust-result.json','server-errors.json','app.log','capturas/INV-21-repro.png'),
('REL-05 / TRV-10','dado errado','Concluir o fluxo do dia com ajuste de uma unidade, consultar Entradas e Saídas no depósito e tentar type=AJUSTE.','O relatório exigido neste plano explica todas as quantidades finais linha a linha.','O ledger e a posição fecham. A API de movimentações aceita apenas ENTRADA e SAIDA e rejeita AJUSTE com 400.','day-flow.json','day-flow-reports.json','capturas/REL-05-real-cross.png'),
('CAT-04','bloqueia operação','Criar item Melão, cadastrar embalagem e código de barras com brand_id=0.','Criar produto sem marca e mostrá-lo como Sem marca.','Cadastro recusou com HTTP 400 e exigiu marca. Estoque de caixas prosseguiu com marca fictícia.','real-mov-catalog.json','http.jsonl','capturas/CAT-04-real-mov-catalog.png'),
('ADM-02','uso ruim','Redefinir a senha de usuário temporário em Administração. Abrir contexto novo e autenticar com a nova senha.','Solicitar nova troca antes de entrar.','Entrou em /home. A redefinição altera o hash e revoga sessões, mas não marca must_change_password.','real-admin.json','capturas/ADM-02-real-admin.png'),
('ACE-06','uso ruim','Abrir formulário novo de Produtos em uma aba. Sair pela outra. Submeter o formulário aberto.','Pedir novo login e preservar o contexto.','HTTP 401 com Entre para continuar. A tela fechou o formulário e ofereceu Enviar de novo como se o resultado fosse incerto.','two-tab-logged-out.json','logout-form-visibility.json','capturas/ACE-06-real-session-proof.png'),
('EST-06','dado errado','Em Estoque, marcar Só abaixo do mínimo, buscar Pote e trocar VR por Câmara Fria.','A nova lista continua restrita ao Pote abaixo do mínimo.','O checkbox e a busca mantêm os valores, mas aparecem Pote e Melão. Alterar o campo de busca reaplica o filtro.','stock-filter-change.json','capturas/EST-06-real-stock-retry.png'),
('CX-05 / CX-11','uso ruim','Zerar caixa com etiqueta pendente. Depois pedir dois trabalhos e devolver fail e uncertain com motivo.','Mostrar a causa Caixa vazia e os motivos de falha/incerteza na fila.','Cancelamento e estados persistem. A fila chama o cancelado de Substituída e omite last_error nos três casos.','print-empty-diagnostics.json','print-state-diagnostics.json','capturas/CX-11-fila.png'),
('CAT-06','uso ruim','Entrar com perfil de catálogo somente leitura e abrir Produtos.','Ausência da ação de criação.','Botão + Novo produto aparece. Escrita via API continua bloqueada por 403.','real-admin.json','capturas/CAT-06-real-admin.png'),
('TRV-01','uso ruim','Encerrar requisição com operation_id fixo, repetir o corpo e repetir com observação diferente.','Repetição idêntica é segura, corpo diferente com o mesmo ID é recusado.','Os três envios retornaram 200. A regra de conflito de corpo não foi observada no encerramento.','replay-detail.json','capturas/TRV-01-real-replay.png'),
('EST-07','cosmético','Comparar a falta de um produto nas telas Estoque e Início.','Mesma regra visual e textual da situação, com Faltam X.','Início usa coluna Falta e somente quantidade/unidade.','real-stock-retry.json','capturas/EST-07-real-stock-retry.png'),
('ADM-08','uso ruim','Selecionar Estoquista na lista de perfis e ler o agrupamento de permissões.','Rótulos em português.','A tela exibe os identificadores delivery e dispatch.','permission-labels.json','capturas/ADM-08-real-final-ui.png'),
('LAY-05 / LAY-08 / LAY-11 / LAY-12','cosmético','Abrir a navegação e os cadastros em 390 e 1366 px. Medir texto, item ativo e alvos de toque.','Pelo menos 14 px, salvo barra a 12 px. Indicação da página atual. Alvos de 44 px. Texto sem exclamação.','Barra medida a 11 px. Texto de listas a 13,33 px no desktop. Administração em Caixas tem 17 px de altura no celular. Cinco páginas em Mais não indicaram a atual na barra fechada. Login mostra Qualidade todo dia!.','layout-detail.json','capturas/layout-390-crates.png','capturas/layout-1366-products.png','capturas/layout-390-login.png')
]
for id,sev,steps,expected,actual,*links in defect_groups:
    add(f'### {id} · {sev}')
    add()
    add(f'**Passos.** {steps} **Esperado.** {expected} **Obtido.** {actual}')
    add()
    add('Evidência — '+', '.join(ref(x) for x in links if (root/x).is_file())+'.')
    add()
add('## 5. Melhorias por impacto operacional')
add()
add('- **Caixas e fila.** Mostrar a causa de cancelamento e o motivo devolvido pela impressora no próprio trabalho. Vincular impressora a depósito. No formato ZPL, revisar a transliteração de Melão Japonês para MELAO JAPONES com uma Zebra antes de mudar a codificação.')
add('- **Requisições.** Acrescentar leitura por QR para marcar uma caixa da separação, preservando a seleção manual. Mostrar a quantidade e unidade também na recusa de itens em UN, sem citar a regra de 20% de KG. Expor encerramentos com diferença em consulta ou relatório, pois a evidência hoje fica no histórico da requisição.')
add('- **Contagem.** Antes de concluir, indicar quais divergências ainda precisam de recontagem. Ao tentar ajustar lote de caixa, abrir a ação que trata os pesos por identificação. O operador hoje precisa interpretar uma resposta genérica.')
add('- **Sessão e administração.** Informar que é necessário entrar novamente quando a edição de perfil revoga uma sessão. Usar o mesmo fluxo de senha temporária após redefinição administrativa.')
add('- **Estoque e início.** Reaplicar busca e abaixo do mínimo após trocar o depósito. Padronizar a quantidade de falta no Início e em Estoque.')
add('- **Relatórios.** Acrescentar consulta explícita de ajustes se a posição precisar ser explicada diretamente pela lista de movimentações. Os tipos comerciais existentes têm outra abrangência.')
add('- **Catálogo e navegação.** Esconder ação indisponível. Permitir sem marca como opção de negócio, com rótulo explícito. Corrigir os tamanhos e indicação do item corrente no celular.')
add()
add('## 6. Riscos e limitações')
add()
add('- O Chrome usa dimensões emuladas. O scanner foi exercitado com um vídeo simulado, e a contagem de dez linhas foi preenchida no navegador. O teclado virtual, a câmera física, a Zebra, o ESP32, o retorno ~HS, a porta 9100 e OTA exigem validação em equipamento. A ausência de equipamento não impediu testar o protocolo da fila por curl.')
add('- O teste de volume usa massa sintética local. Não mede muitos usuários em rede real, latência ao banco remoto nem impressão física. Os tempos das telas carregadas estão em '+ref('performance.json')+'.')
add('- LAY-10 registra o ciclo completo de Tab das 26 aberturas. A amostra não cobre toda combinação de estados ou subdiálogos. Estilos computados e axe-core avaliaram as telas abertas, e as capturas incluem Contagem e Requisições preenchidas.')
add('- Os grants foram feitos depois da captura dos perfis iniciais. O resultado desses fluxos depende das permissões acrescentadas à instância local e não representa a experiência inicial entregue pelo banco novo.')
add('- Os testes de concorrência e de integridade cobrem os SKUs e depósitos gerados. A trilha de domínio, a matriz e os logs foram preservados com os passos e resultados de cada caso.')
add('- O plano mantém 1.8 e 1.9 abertos. A verificação desta rodada usou o código existente, com handlers e SQL no mesmo pacote e app.js concentrando funções. Status físico antes do ACK e aspectos de rede da impressora ficaram sem ensaio em hardware.')
add()
add('## 7. Divergências com a documentação')
add()
add('- O contrato do relatório já restringe Entradas e Saídas aos respectivos tipos e exclui os ajustes. O sistema segue o documento. REL-05 e TRV-10 pedem uma visão adicional de AJUSTE para explicar o saldo.')
add('- O plano de correção descreve como feito o rótulo Sem marca para dados legados. O catálogo recusa criar um SKU novo com brand_id=0. A expectativa de criar produto sem marca precisa ser distinguida da exibição histórica.')
add('- A regra de 20% do contrato de requisições está implementada para KG em geral. Arroz comum passou com 110 separados de 106 pedidos e 108,7 entregues. UN foi recusado. O contrato também descreve corretamente o encerramento com diferença, que a interface mostra no histórico da requisição.')
add('- O guia de estilo diz que Início e Estoque usam a mesma regra de situação. A renderização de Início usa Falta e mostra apenas a quantidade. A medida da barra inferior ficou abaixo da exceção de 12 px documentada.')
add('- O plano de correção registra a correção de CSRF em duas abas, confirmada com criação de produto HTTP 201. O caso de sessão já encerrada ainda leva ao aviso de cadastro sem confirmação.')
add('- O contrato de caixas prevê cancelamento com a causa Caixa vazia. O banco conserva a causa e a fila expõe só estado. O plano registra a falta de vínculo por depósito confirmada no pareamento e a transliteração observada no ZPL.')
add()
known=read('known-points',{})
if known:
    add('### Pontos conhecidos')
    add()
    add('- A tela de Requisições não oferece scanner para selecionar caixas. As opções de relatório permanecem Entradas, Saídas e Estoque na data. Encerramentos com diferença estão no histórico da requisição.')
    add('- Tentar entregar 3 kg com reserva de 2 kg retornou HTTP 409 “Entrega maior do que a quantidade separada.” A separação do peso real é necessária antes da entrega. '+ref('known-points.json'))
    add('- A fila ainda não associa impressoras a depósitos. O ZPL traz ^CI28 e translitera Melão Japonês para MELAO JAPONES. INV-21 documenta a contagem do peso total por produto e o erro no ajuste.')
    add()
add('## Anexos')
add()
add('Roteiros Playwright `real-*.cjs`, evidências `*.json` e `*.jsonl`, capturas `capturas/`, registro do Compose `app.log` e saídas da suíte em `teste-evidencias/`. Os valores de senha e os tokens foram omitidos das evidências funcionais.')
add()
add('Os arquivos rastreados do repositório foram preservados. Os resultados e os roteiros ficaram em arquivos de teste locais.')
Path('relatorio-teste-totalfood.md').write_text('\n'.join(out)+'\n',encoding='utf-8')
print(json.dumps(dict(total=len(ids),resultados=summary,pendentes=[id for id in ids if cases[id]['estado']=='não executado']),ensure_ascii=False))
