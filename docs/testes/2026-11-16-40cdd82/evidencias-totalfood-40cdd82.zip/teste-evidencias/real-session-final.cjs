const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-session-final');
main(async()=>{
 const {a,brandName,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const session=await pageFor('d');
 async function productForm(page,code){
   await open(page,'/products');
   await page.locator('#productNew').click();
   await page.locator('#productParentSearch').fill(p.un.name);
   await page.locator('#productParentLookup button').filter({hasText:p.un.name}).first().click();
   await page.locator('#productBrandSearch').fill(brandName);
   await page.locator('#productBrandLookup button').filter({hasText:brandName}).first().click();
   await page.locator('#productName').fill('Apresentação teste '+code);
   await page.locator('#productContent').fill('2');
   await page.locator('#productBarcode').fill(code);
 }
 const context=session.context(), second=await context.newPage();
 await run('ACE-05',session,'Preparar produto na aba A; abrir Início na B; voltar à A e salvar.',async()=>{
   await productForm(session,'719'+stamp+'5');
   await open(second,'/home');
   const p=session.waitForResponse(r=>r.url().endsWith('/api/catalog/skus')&&r.request().method()==='POST');
   await session.locator('#productForm button[type=submit]').click();
   const r=await p;
   save('two-tab-create',{status:r.status(),body:await r.json()});
   assert.equal(r.status(),201);
   await session.locator('#productDialog').waitFor({state:'hidden'});
   return 'Produto salvo após abrir outra aba (HTTP 201).';
 });
 await run('ACE-06',session,'Preparar produto em A e sair da conta em B antes de salvar em A.',async()=>{
   await productForm(session,'719'+stamp+'6');
   await open(second,'/home');
   await second.locator('#logout').evaluate(el=>el.click());
   await second.waitForURL('**/login');
   const submit=session.waitForResponse(r=>r.url().endsWith('/api/catalog/skus')&&r.request().method()==='POST');
   await session.locator('#productForm button[type=submit]').click();
   const r=await submit;
   save('two-tab-logged-out',{status:r.status(),body:await r.json()});
   await session.locator('#productFormStatus').waitFor();
   const text=await session.locator('#productFormStatus').innerText();
   assert.match(text,/entre|login|sessão/i);assert.doesNotMatch(text,/permissão/i);
   return r.status()+' '+text;
 });
 await run('ACE-07',second,'Voltar com o histórico após sair em outra aba.',async()=>{
   const res=await second.goBack({waitUntil:'domcontentloaded',timeout:6500}).catch(()=>null);
   const result={url:second.url(),nav:await second.locator('nav').count(),HTTP:res?.status(),visible:(await second.locator('body').innerText()).slice(0,200)};
   save('logout-history',result);
   assert.match(result.url,/login$/,'Voltar exibiu '+JSON.stringify(result));
   assert.equal(result.nav,0);
   return 'Histórico protegido e tela de login.';
 });
});
