const fs=require('node:fs');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,rows,main,save}=require('./real-common.cjs');
const run=rows('real-admin');
main(async()=>{
 const {a}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const director=await pageFor('d');
 await open(director,'/admin');
 const activate=good(await post(director,'/api/admin/warehouses/'+a+'/activate',{}));
 assert.equal(activate.active,true);
 const permissions=await get(director,'/api/admin/permissions');
 const profiles=await get(director,'/api/admin/profiles');
 save('profiles-before-api',profiles);
 const grants=[];
 for(const [role,wanted] of [
   ['Estoquista',['stock:read','movement_entry:write','movement_exit:write','movement_transfer:write','catalog:read']],
   ['Gerente',['stock:read','operations:read','inventory_validation:read','inventory_validation:write','stock_adjustment:write','catalog:read']]
 ]){
   const profile=profiles.find(x=>x.name===role);
   assert.ok(profile);
   const kept=profile.permission_ids||profile.permissions?.map(x=>typeof x==='number'?x:x.id)||[];
   const ids=[...new Set([...kept,...permissions.filter(x=>wanted.includes(x.resource+':'+x.action)||['material_requests:read','material_fulfillment:write'].includes(x.resource+':'+x.action)||(role==='Gerente'&&['material_receipts:write','material_requests:write','costs:read','dispatch:read','logistics:read','planning:read'].includes(x.resource+':'+x.action))).map(x=>x.id)])];
   const result=good(await api(director,'PUT','/api/admin/profiles/'+profile.id+'/permissions',{permission_ids:ids,version:profile.version}));
   grants.push({role,ids,added:wanted,result});
 }
 save('profile-grants',grants);
 console.log('PERFIS PRONTOS');
 await run('ADM-08',director,'Abrir permissões de um perfil e verificar os nomes exibidos.',async()=>{
   await director.locator('#adminProfilesList').getByText('Estoquista',{exact:false}).first().click();
   const page=await director.locator('#adminPerms').innerText();
   assert.ok(page.trim().length);
   assert.doesNotMatch(page,/\bmaterial_requests\b|\bmovement_entry\b/);
   return page.split('\n').map(t=>t.trim()).filter(Boolean).slice(0,15).join(' | ');
 });
 const name='Leitor Lab '+stamp;
 let profile,reader,readerLogin='t-leitor-'+stamp;
 const catalogRead=permissions.find(x=>x.resource==='catalog'&&x.action==='read').id;
 const stockRead=permissions.find(x=>x.resource==='stock'&&x.action==='read').id;
 const temp=process.env.TF_TEST_TEMP;
 async function loginAs(p,name,pw){
   await open(p,'/login');
   await p.locator('[name=login]').fill(name);
   await p.locator('[name=password]').fill(pw);
   await p.locator('form button').click();
 }
 await run('ADM-03',director,'Criar perfil de leitura, associar permissões e abrir Produtos como usuário.',async()=>{
   profile=good(await post(director,'/api/admin/profiles',{name}));
   const changed=good(await api(director,'PUT','/api/admin/profiles/'+profile.id+'/permissions',{permission_ids:[catalogRead,stockRead],version:profile.version}));
   profile.version=changed.version;
   good(await post(director,'/api/admin/users',{login:readerLogin,password:temp,profile_id:profile.id,active:true}));
   reader=await pageFor(null,390);
   await loginAs(reader,readerLogin,temp);
   await open(reader,'/products');
   assert.ok(reader.url().endsWith('/products'));
   bad(await post(reader,'/api/catalog/items',{}),null,403);
   await reader.locator('nav a[href="/products"]').first().waitFor({state:'attached'});
   return 'Perfil '+name+' abre Produtos e API recusa gravação com 403.';
 });
 await run('CAT-06',reader,'Perfil somente leitura abre Produtos e procura + Novo produto.',async()=>{
   if(!reader)return require('./real-common.cjs').skip('Depende do ADM-03');
   const newButton=reader.locator('#productNew');
   assert.equal(await newButton.isVisible(),false,'Botão + Novo produto visível para quem só tem leitura.');
   return 'Ação de criação oculta.';
 });
 await run('ADM-04',reader,'Remover leitura do catálogo enquanto o usuário tem a página aberta.',async()=>{
   assert.ok(reader&&profile,'Pré-condição de perfil personalizado');
   good(await api(director,'PUT','/api/admin/profiles/'+profile.id+'/permissions',{permission_ids:[stockRead],version:profile.version}));
   const r=await api(reader,'GET','/api/catalog/products');
   bad(r,null,403);return r.status+' '+JSON.stringify(r.body);
 });
 const getReader=async()=> (await get(director,'/api/admin/users')).find(x=>x.login===readerLogin);
 await run('ADM-02',director,'Redefinir senha de usuário de teste; abrir login novo.',async()=>{
   const row=await getReader(), changed=temp+'Nova';
   good(await api(director,'PATCH','/api/admin/users/'+row.id+'/password',{password:changed,version:row.version}));
   const newContext=await pageFor(null);
   await loginAs(newContext,readerLogin,changed);
   assert.match(newContext.url(),/change-password$/);
   return 'Login novo exigiu troca obrigatória.';
 });
 await run('ADM-01',director,'Editar o login do usuário temporário e desativar; tentar autenticar.',async()=>{
   const row=await getReader(), edited=readerLogin+'-editado';
   good(await api(director,'PATCH','/api/admin/users/'+row.id,{login:edited,profile_id:profile.id,active:false,version:row.version}));
   const users=await get(director,'/api/admin/users');
   assert.ok(users.some(u=>u.id===row.id&&u.login===edited&&u.active===false));
   const fresh=await pageFor(null);
   await loginAs(fresh,edited,temp+'Nova');
   assert.match(fresh.url(),/login$/);
   return await fresh.getByRole('alert').innerText();
 });
});
