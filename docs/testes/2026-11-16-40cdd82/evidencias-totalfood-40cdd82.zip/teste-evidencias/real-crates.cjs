const {execFileSync}=require('node:child_process');
const fs=require('node:fs');
const {assert,base,out,op,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip,append}=require('./real-common.cjs');
const run=rows('real-crates');
main(async()=>{
 const {a,b,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'), e=await pageFor('e',390);
 await open(d,'/admin');
 let printer, printer2, fresh=[];
 const jobs=async()=> (await get(e,'/api/print/jobs')).jobs;
 const getCrate=id=>get(e,'/api/crates/'+id);
 const weigh=(id,weight)=>post(e,'/api/crates/'+id+'/weigh',{...op(),weight:String(weight),notes:'Retorno do laboratório'});
 const find=(list,id)=>list.find(x=>x.crate_id===id);
 function curl(route,token,data){
   const flags=['-sS','-i','--max-time','15','-X','POST','-H','Content-Type: application/json','-H','Authorization: Bearer '+token];
   if(data)flags.push('--data-binary',JSON.stringify(data));
   const raw=execFileSync('curl',[...flags,base+route],{encoding:'utf8'});
   const end=raw.indexOf('\r\n\r\n'), header=raw.slice(0,end), response=raw.slice(end+4);
   const headers=Object.fromEntries(header.split('\r\n').slice(1).map(line=>{const [name,...parts]=line.split(':');return [name.toLowerCase(),parts.join(':').trim()]}));
   let body=response;try{body=JSON.parse(response)}catch{}
   const result={status:Number(header.split(' ')[1]),headers,body};
   append('print-http',{route,status:result.status,body:typeof body==='string'?body: Object.fromEntries(Object.entries(body).filter(([k])=>!k.includes('token'))),job:headers['x-print-job-id']});
   return result;
 }
 await run('ADM-07',d,'Cadastrar uma impressora na UI e recarregar a administração.',async()=>{
   await d.locator('#adminPrinterName').fill('Impressora Lab VR');
   const rr=d.waitForResponse(r=>r.url().endsWith('/api/print/devices')&&r.request().method()==='POST');
   await d.locator('#adminPrinterForm button[type=submit]').click();
   const response=await rr;
   assert.equal(response.status(),201);
   printer=await response.json();
   assert.ok(printer.token);
   const printed=await d.locator('#adminPrinterToken').textContent();
   assert.ok(printed.includes(printer.token),'Token ausente no retorno visual');
   await d.reload();
   assert.ok(!(await d.locator('#adminPrinterToken').textContent()).includes(printer.token));
   const listed=await get(d,'/api/print/devices');
   assert.doesNotMatch(JSON.stringify(listed),new RegExp(printer.token));
   return 'HTTP 201; token exibido uma vez e ausente na listagem/reabertura.';
 });
 await open(e,'/crates');
 await run('CX-01',e,'Receber pelo formulário de Caixas móvel pesos 19,3; 18,9; 22 kg com fornecedor e documento.',async()=>{
   await e.locator('#crateSearch').fill(p.crate.name);
   await e.locator('#crateProductLookup button').first().click();
   await e.locator('#crateWarehouse').selectOption(String(a));
   await e.locator('#crateCount').fill('3');
   await e.locator('#crateDocument').fill('LAB-CX-01');
   await e.locator('#crateSupplier').fill('Fornecedor Lab');
   await e.locator('#crateCost').fill('5,20');
   for(const [i,q] of ['19,300','18,900','22,000'].entries())await e.locator('#crateWeights input').nth(i).fill(q);
   const rr=e.waitForResponse(r=>r.url().endsWith('/api/crates/receive')&&r.request().method()==='POST');
   await e.locator('#crateReceiveSubmit').click();
   const response=await rr, data=await response.json();
   assert.equal(response.status(),200,JSON.stringify(data));
   fresh=data.crates;
   assert.equal(fresh.length,3);
   const states=await jobs();
   for(const c of fresh)assert.equal(find(states,c.id)?.status,'PENDING');
   assert.equal(await e.evaluate(()=>document.documentElement.scrollWidth),390);
   await e.screenshot({path:out+'/capturas/CX-01-390.png'});
   return fresh.map(x=>x.code+' '+x.weight).join(' | ')+' e três etiquetas PENDING.';
 });
 if(!fresh.length){
   const fallback=await post(e,'/api/crates/receive',{...op(),sku_id:p.crate.sku,warehouse_id:a,unit_cost:'5.20',document_number:'LAB-CX-API',weights:['19.3','18.9','22']});
   fresh=good(fallback).crates;
 }
 save('crate-fixture',{ids:fresh.map(x=>x.id),codes:fresh.map(x=>x.code)});
 await run('CX-02',e,'Filtrar Caixas ativas no VR e tocar na linha da primeira caixa.',async()=>{
   await e.locator('#crateActiveWarehouse').selectOption(String(a));
   const row=e.locator('#crateActiveList').getByText(fresh[0].code,{exact:false}).first();
   await row.waitFor();
   await row.click();
   await e.locator('#crateCurrent').getByText(fresh[0].code,{exact:false}).first().waitFor();
   const summary=await e.locator('#crateActiveSummary').innerText();
   assert.match(summary,/60[,.]2/);
   return summary;
 });
 await run('CX-07',e,'Abrir link de etiqueta, usando o código real da primeira caixa.',async()=>{
   await open(e,'/crates?crate='+fresh[0].code);
   await e.locator('#crateCurrent').getByText(fresh[0].code,{exact:false}).first().waitFor();
   return await e.locator('#crateCurrent').innerText();
 });
 await run('MOV-09',e,'Tentar saída genérica de 1 kg do melão controlado por caixa.',async()=>{
   const r=await post(e,'/api/movements/exit/batch',{...op(),warehouse_id:a,lines:[{sku_id:p.crate.sku,quantity:'1'}]});
   return r.status+' '+JSON.stringify(bad(r,/caixa/i));
 });
 if(!printer)printer=good(await post(d,'/api/print/devices',{name:'Impressora Lab reserva'}));
 let claim;
 await run('CX-08',e,'Simular impressora via curl, reivindicando ZPL e token.',async()=>{
   claim=curl('/api/print/jobs/claim?format=zpl',printer.token,{});
   assert.equal(claim.status,200);
   assert.match(claim.body,/\^XA/);
   assert.ok(claim.headers['x-print-claim']&&claim.headers['x-print-job-id']);
   return 'HTTP 200, ZPL no corpo, X-Print-Claim e X-Print-Job-ID presentes.';
 });
 await run('CX-13',e,'Inspecionar ZPL de Melão Japonês.',async()=>{
   if(!claim)skip('Depende do CX-08.');
   const lines=claim.body.split('\n').filter(l=>/Melao|Japon|CI28/i.test(l));
   assert.ok(lines.length);
   return lines.join(' | ')+' (renderização física da Zebra fora desta etapa).';
 });
 await run('CX-09',e,'Confirmar o trabalho via curl com X-Print-Claim retornado.',async()=>{
   if(!claim?.headers['x-print-claim'])skip('Depende do CX-08.');
   const id=+claim.headers['x-print-job-id'];
   const r=curl('/api/print/jobs/'+id+'/ack',printer.token,{claim_token:claim.headers['x-print-claim']});
   assert.equal(r.status,200);assert.match(JSON.stringify(r.body),/SENT/i);
   const state=(await jobs()).find(x=>x.id===id);
   assert.ok(!state||state.status==='SENT');
   return 'Trabalho '+id+' '+JSON.stringify(r.body)+'.';
 });
 await run('CX-03',e,'Repesar uma caixa de 18,9 kg para 17,3 kg com etiqueta pendente.',async()=>{
   const c=fresh[1], old=find(await jobs(),c.id);
   const current=good(await weigh(c.id,17.3));
   assert.equal(number(current.weight),17.3);assert.equal(current.revision,c.revision+1);
   const list=(await jobs()).filter(x=>x.crate_id===c.id);
   assert.ok(list.some(x=>x.revision===current.revision&&x.status==='PENDING'));
   assert.ok(!list.some(x=>x.id===old.id&&x.status==='PENDING'));
   return 'Pendente da revisão '+c.revision+' substituído; peso '+current.weight+'; revisão '+current.revision+'.';
 });
 await run('CX-04',e,'Tentar repesar a mesma caixa para 23 kg.',async()=>{
   const before=await getCrate(fresh[1].id);
   const r=await weigh(before.id,23);bad(r,/aumento|maior/i);
   assert.deepEqual(await getCrate(before.id),before);
   return r.status+' '+JSON.stringify(r.body);
 });
 await run('CX-05',e,'Zerar a segunda caixa e verificar fila e lista ativa.',async()=>{
   const c=fresh[1], before=(await jobs()).filter(x=>x.crate_id===c.id).map(x=>x.id);
   const result=good(await weigh(c.id,0));assert.equal(number(result.weight),0);
   assert.match(result.status,/EMPTY/i);
   const list=await jobs(), rows=list.filter(x=>x.crate_id===c.id);
   assert.ok(rows.every(x=>before.includes(x.id)&&x.status!=='PENDING'));
   const active=await get(e,'/api/crates?warehouse_id='+a);
   assert.ok(!JSON.stringify(active).includes(c.code));
   assert.match(JSON.stringify(rows),/Caixa vazia/i);
   return c.code+' EMPTY e fila cancelada com motivo Caixa vazia.';
 });
 await run('CX-06',e,'Transferir a última caixa de VR para Câmara Fria.',async()=>{
   const old=fresh.at(-1);
   good(await post(e,'/api/crates/'+old.id+'/transfer',{...op(),to_warehouse_id:b}));
   const moved=await getCrate(old.id);
   assert.equal(moved.code,old.code);assert.equal(moved.warehouse_id,b);
   assert.equal(number(moved.weight),number(old.weight));
   return moved.code+' agora no depósito '+b+' com '+moved.weight+' kg.';
 });
 await run('CX-12',e,'Tentar reivindicar trabalho com token inválido e, depois, revogado.',async()=>{
   const badToken=curl('/api/print/jobs/claim','invalid-test-token',{});
   assert.equal(badToken.status,401);
   const temp=good(await post(d,'/api/print/devices',{name:'Impressora Lab revogada'}));
   good(await post(d,'/api/print/devices/'+temp.id+'/revoke',{}));
   const revoked=curl('/api/print/jobs/claim',temp.token,{});
   assert.equal(revoked.status,401);assert.ok(!revoked.body.zpl);
   return '401 ambos, sem conteúdo da etiqueta.';
 });
 await run('CX-14',e,'Criar segunda impressora nomeada para a Câmara Fria e inspecionar capacidade de configurar depósito.',async()=>{
   printer2=good(await post(d,'/api/print/devices',{name:'Impressora Lab Câmara Fria'}));
   const result=await get(d,'/api/print/devices');
   assert.ok(result.devices.some(x=>x.id===printer.id)&&result.devices.some(x=>x.id===printer2.id));
   assert.equal(await d.locator('#adminPrinterForm select').count(),0);
   assert.ok(result.devices.every(x=>!('warehouse_id' in x)));
   return 'Pareamento e listagem sem vínculo de depósito; confirma a limitação 2.4.';
 });
 const extra=good(await post(e,'/api/crates/receive',{...op(),sku_id:p.crate.sku,warehouse_id:a,unit_cost:'5.20',document_number:'LAB-CX-FILA',weights:['8','9','10','11']}));
 await run('CX-11',e,'Reivindicar duas etiquetas e reportar fail e uncertain via curl.',async()=>{
   const statuses=[];
   for(const action of ['fail','uncertain']){
     const j=curl('/api/print/jobs/claim',printer.token,{});
     assert.equal(j.status,200);assert.ok(j.body.claim_token);
     const r=curl('/api/print/jobs/'+j.body.id+'/'+action,printer.token,{claim_token:j.body.claim_token,error:'Simulação '+action});
     assert.equal(r.status,200);statuses.push(r.body.status);
     assert.match(JSON.stringify((await jobs()).find(x=>x.id===j.body.id)),new RegExp('Simulação '+action));
   }
   assert.deepEqual(statuses,['FAILED','UNCERTAIN']);return statuses.join(' e ');
 });
 const expired=curl('/api/print/jobs/claim',printer.token,{});
 await run('CX-10',e,'Reservar uma etiqueta e deixar vencer em tempo real por 5 min e 5 s.',async()=>{
   if(expired.status!==200||!expired.body.id)skip('A fila não devolveu novo trabalho para aguardar.');
   console.log('CX-10 iniciando espera em tempo real',expired.body.id);
   await new Promise(resolve=>setTimeout(resolve,305000));
   const job=(await jobs()).find(x=>x.id===expired.body.id);
   assert.equal(job.status,'UNCERTAIN');
   await e.reload();
   const r=await post(e,'/api/print/jobs/'+job.id+'/retry',{});
   assert.equal(good(r).status,'PENDING');
   return 'Trabalho '+job.id+' expirado em UNCERTAIN e reenviado para PENDING.';
 });
});
