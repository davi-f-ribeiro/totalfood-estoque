const fs=require('node:fs');
const {assert,out,op,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-stock-reports');
main(async()=>{
 const {a,b,c,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'), m=await pageFor('d',390);
 const inv=fs.existsSync(out+'/inventory-end.json')?JSON.parse(fs.readFileSync(out+'/inventory-end.json')):{};
 const perf=[];
 const navigate=async(p,route,locator)=>{
   const start=performance.now();
   const http=await open(p,route);
   await p.locator(locator).first().waitFor();
   await p.waitForLoadState('networkidle');
   perf.push({url:route,width:p.viewportSize().width,HTTP:http.status(),ms:Math.round(performance.now()-start)});
 };
 const card=(p,product)=>p.locator('#stockList .stock-card').filter({hasText:product.name}).first();
 await navigate(d,'/stock','#stockList');
 await navigate(m,'/stock','#stockList');
 await run('EST-01',d,'Abrir Estoque no desktop e inspecionar os quatro cabeçalhos e alinhamento.',async()=>{
   await card(d,p.kg).waitFor();
   const content=await d.locator('main').innerText();
   for(const h of ['Item','Estoque','Mínimo','Situação'])assert.match(content,new RegExp(h));
   const css=await card(d,p.kg).evaluate(el=>[...el.querySelectorAll('*')].map(e=>({cls:e.className,text:e.textContent?.trim(),align:getComputedStyle(e).textAlign})).filter(x=>x.text&&/\d[,.]?\d*\s*(kg|un)/i.test(x.text)));
   save('stock-column-css',css);assert.ok(css.some(x=>x.align==='right'));
   await d.screenshot({path:out+'/capturas/EST-01-1366.png'});return 'Quatro cabeçalhos e coluna numérica alinhada à direita.';
 });
 const view=async(w)=> get(d,'/api/stock'+(w?'?warehouse_id='+w:''));
 const selectWarehouse=async(p,id)=>{
   const r=p.waitForResponse(x=>new URL(x.url()).pathname==='/api/stock');
   await p.locator('#warehouse').selectOption(String(id));await r;
 };
 await selectWarehouse(d,a);
 await run('EST-02',d,'Conferir estoque abaixo do mínimo, normal e item sem mínimo no VR.',async()=>{
   const all=await view(a), data=all.filter(x=>x.below_minimum);
   assert.ok(data.length>=2);
   for(const row of data.slice(0,2)){
     const item=d.locator('.stock-card').filter({hasText:row.name});
     const msg=item.getByText(/^Faltam /).first();
     await msg.waitFor();
     assert.equal(await msg.evaluate(x=>getComputedStyle(x).color),'rgb(180, 35, 24)');
   }
   const noMin=all.find(x=>!number(x.minimum));
   assert.ok(noMin);assert.match(await card(d,noMin).innerText(),/sem mínimo/i);
   const normal=all.find(x=>number(x.minimum)&&!x.below_minimum);
   if(!normal)skip('Duas faltas e item sem mínimo verificados; nenhum item normal no VR para comparar.');
   assert.doesNotMatch(await card(d,normal).innerText(),/Faltam|Normal/i);
   return data.map(x=>x.name+': falta '+x.shortage).join(' | ');
 });
 await run('EST-03',d,'Comparar cada falta exibida com o campo shortage para o mesmo depósito.',async()=>{
   const all=(await view(a)).filter(x=>x.below_minimum);
   assert.ok(all.length);
   for(const row of all){
     const msg=await card(d,row).getByText(/^Faltam /).first().innerText();
     const displayed=msg.match(/Faltam\s+([0-9,.]+)/i);
     assert.ok(displayed);
     assert.equal(number(displayed[1]),number(row.shortage));
   }
   return all.length+' faltas conferidas contra o servidor.';
 });
 await run('EST-04',d,'Expandir item Arroz, a marca e as embalagens.',async()=>{
   await card(d,p.kg).click();
   await d.locator('#stockDetail summary').first().click();
   const detail=d.locator('#stockDetail');
   await detail.getByText('Dar saída',{exact:false}).first().waitFor();
   await detail.getByText('Dar entrada',{exact:false}).first().waitFor();
   return (await detail.innerText()).slice(0,300);
 });
 await run('EST-05',d,'Abrir Melão no VR e conferir caixas ativas.',async()=>{
   await card(d,p.crate).click();
   const detail=d.locator('#stockDetail');
   await detail.getByText('Caixas ativas',{exact:true}).waitFor();
   const first=await detail.locator('.stock-crate-row').first().innerText();
   assert.match(first,/CX-\d+/);
   assert.match(first,/kg/i);
   assert.match(first,/VR/i);
   assert.match(first,/\d{2}\/\d{2}\/\d{4}/);
   return first;
 });
 await run('EST-06',d,'Filtrar abaixo do mínimo, buscar Pote e trocar VR para Câmara Fria.',async()=>{
   await d.locator('#stockBelowMinimum').check();
   await d.locator('#stockSearch').fill(p.un.name);
   const aCount=await d.locator('.stock-card:visible').count();assert.equal(aCount,1);
   await selectWarehouse(d,b);
   await card(d,p.un).waitFor();
   assert.equal(await d.locator('.stock-card:visible').count(),1);
   const s=(await view(b)).find(x=>x.item_id===p.un.item);
   assert.ok(s.below_minimum);
   assert.match(await card(d,p.un).innerText(),new RegExp(String(number(s.quantity))));
   return 'Busca e filtro preservados na mudança, falta do depósito '+b+': '+s.shortage+'.';
 });
 await run('EST-07',d,'Abrir Início e comparar lista de faltas com posição de estoque.',async()=>{
   await navigate(d,'/home','#homeLow');
   const result=d.locator('#homeLow');
   await result.getByText(p.un.name,{exact:false}).first().waitFor();
   const page=await d.locator('main').innerText();
   assert.match(page,/Faltam/i);assert.match(page,/Estoque/i);
   const unit=(await view()).find(x=>x.item_id===p.un.item);
   assert.ok(unit.below_minimum);
   return 'Atalhos e faltas visíveis; ver divergência se Estoque Geral estiver acima do mínimo.';
 });
 await run('EST-08',m,'Inspecionar as linhas do estoque no celular.',async()=>{
   const item=card(m,p.kg);await item.waitFor();
   const style=await item.evaluate(x=>{const s=getComputedStyle(x);return {border:s.borderTopWidth,radius:s.borderRadius,shadow:s.boxShadow,width:x.offsetWidth}});
   assert.equal(style.radius,'0px');assert.equal(style.shadow,'none');assert.ok(style.width>=330);
   assert.equal(await m.evaluate(()=>document.documentElement.scrollWidth),390);
   await m.screenshot({path:out+'/capturas/EST-08-390.png'});
   return 'Largura '+style.width+' px, cantos retos, sem sombra e sem rolagem horizontal.';
 });
 await navigate(d,'/material-requests','#materialList');
 await navigate(d,'/reports','#reportForm');
 await navigate(m,'/material-requests','#materialList');
 await navigate(m,'/reports','#reportForm');
 save('performance',perf);
 await run('TRV-08',d,'Medir abertura com os dados gerados, nas duas larguras.',async()=>{
   assert.equal(perf.length,6);
   const slow=perf.filter(x=>x.ms>2000);
   return 'Medições: '+perf.map(x=>x.url+' '+x.width+' px '+x.ms+' ms').join(' | ')+(slow.length?' | '+slow.length+' acima de 2 s.':'');
 });
 const start='2026-11-16T00:00:00-03:00', end='2026-11-17T00:00:00-03:00';
 const reports=(kind,from=start,to=end,w=a)=>get(d,'/api/reports/movements?'+new URLSearchParams({type:kind,start:from,end:to,warehouse_id:String(w)}));
 await run('REL-01',d,'Consultar ENTRADA no VR em 16/11/2026 e cruzar com MOV-01.',async()=>{
   const all=await reports('ENTRADA');
   const rows=all.filter(x=>x.document_number==='LAB-MOV-01');
   assert.equal(rows.length,2);
   const found=rows.find(x=>x.item===p.kg.name);
   assert.equal(number(found.quantity),350);assert.equal(number(found.unit_cost),4.2);
   assert.ok(rows.every(x=>x.warehouse_id===a&&x.type==='ENTRADA'));
   save('mov-report-entry',rows);
   return 'Duas linhas no VR para LAB-MOV-01. Arroz 350 kg a 4,20 (custo registrado).';
 });
 await run('REL-02',d,'Comparar posição no VR com Estoque e procurar o legado sem marca.',async()=>{
   const data=await get(d,'/api/reports/balance?'+new URLSearchParams({before:end,warehouse_id:String(a)}));
   const stock=await view(a);
   for(const x of stock){
     const total=data.filter(r=>r.item===x.name).reduce((s,r)=>s+number(r.quantity),0);
     assert.equal(Math.round(total*1000),Math.round(number(x.quantity)*1000),x.name);
   }
   await d.screenshot({path:out+'/capturas/REL-02-1366.png'});
   const unbranded=data.filter(x=>x.brand==='Sem marca');
   if(!unbranded.length)skip('Posição confere por item; o cadastro sem marca foi recusado em CAT-04 e não há linha Sem marca na massa movimentada.');
   return 'Quantidades conferidas; '+unbranded.length+' linhas Sem marca.';
 });
 await run('REL-05',d,'Cruzar movimentos de entrada, pesagem, entrega e ajuste com a API de relatórios.',async()=>{
   const outs=await reports('SAIDA');
   const req=outs.filter(r=>/^REQ-/.test(r.document_number));
   assert.ok(req.length>0);
   const unique=new Set(req.map(x=>x.movement_id+'|'+x.barcode+'|'+x.quantity));
   assert.equal(unique.size,req.length);
   const adjustments=await reports('AJUSTE',start,end,c).catch(()=>[]);
   save('rel-special',{outs,adjustments});
   if(!inv.movId)skip('Entrega REQ-n conferida; ajuste de inventário sem ID verificado.');
   assert.ok(adjustments.some(x=>x.movement_id===inv.movId),'Movimento de ajuste '+inv.movId+' ausente no tipo AJUSTE.');
   return req.length+' linhas REQ-n e ajuste '+inv.movId+'. Veja rel-special.json.';
 });
 await run('REL-03',d,'Selecionar período Hoje na interface Relatórios.',async()=>{
   await open(d,'/reports');
   const button=d.locator('[data-period=today]');
   await button.click();
   assert.equal(await button.evaluate(e=>getComputedStyle(e).backgroundColor),'rgb(0, 0, 0)');
   return 'Hoje selecionado com fundo preto.';
 });
 await run('REL-04',d,'Consultar um período vazio e outro com 26 anos.',async()=>{
   const old=await reports('ENTRADA','2000-01-01T00:00:00Z','2000-01-02T00:00:00Z');
   assert.deepEqual(old,[]);
   const t=Date.now(),long=await reports('ENTRADA','2000-01-01T00:00:00Z',end),ms=Date.now()-t;
   return 'Sem dados: []. Período de 26 anos: '+long.length+' linhas em '+ms+' ms no ambiente local.';
 });
});
