const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,number,rows,main,save,append,skip}=require('./real-common.cjs');
const run=rows('real-cross');
const date='2026-11-16',start=date+'T00:00:00-03:00',end='2026-11-17T00:00:00-03:00';
const sql=q=>JSON.parse(execFileSync('docker',['compose','exec','-T','db','psql','-U','estoque','-d','estoque','-At','-v','ON_ERROR_STOP=1','-c',q],{encoding:'utf8'}).trim());
const jsonify=q=>sql("SELECT COALESCE(json_agg(q),'[]'::json) FROM ("+q+") q");
main(async()=>{
 const {a,b,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'),e=await pageFor('e'), k=await pageFor('c');
 const newWarehouse=async name=>{
   const id=good(await post(d,'/api/admin/warehouses',{name:name+' '+stamp})).id;
   good(await post(d,'/api/admin/warehouses/'+id+'/activate',{}));return id;
 };
 const movement=(who,w,type,items,doc)=>post(who,'/api/movements/'+type+'/batch',{...op(),warehouse_id:w,document_number:doc,lines:items.map(([x,q,cost])=>({sku_id:x.sku,quantity:String(q),unit_cost:cost??''}))});
 const mReport=(type,w)=>api(d,'GET','/api/reports/movements?'+new URLSearchParams({type,start,end,warehouse_id:String(w)}));
 let day;
 await run('TRV-10',d,'Executar dia em novo depósito: entrada, caixas, pedido, reserva, entrega, divergência, encerramento, retorno, contagem, ajuste e conciliação.',async()=>{
   const wh=await newWarehouse('Dia completo');
   const entry=good(await movement(e,wh,'entry',[[p.kg,30,'4.20'],[p.un,40,'2.50']],'LAB-DIA-ENTRADA'));
   const batch=good(await post(e,'/api/crates/receive',{...op(),sku_id:p.crate.sku,warehouse_id:wh,unit_cost:'4.20',document_number:'LAB-DIA-CX',weights:['6','10','4']}));
   const id=good(await post(k,'/api/material-requests',{...op(),unit_name:'Dia de estoque '+stamp,delivery_date:date,production_date:date,service:'almoco',lines:[{item_id:p.crate.item,quantity:'17'}]})).id;
   const mr='/api/material-requests/'+id, detail=await get(k,mr);
   const rid=good(await post(e,mr+'/reserve',{...op(),line_id:detail.lines[0].id,sku_id:p.crate.sku,warehouse_id:wh,quantity:'16'})).id;
   const delivery=good(await post(e,mr+'/deliver',{...op(),reservation_id:rid,quantity:'16',crate_ids:batch.crates.slice(0,2).map(x=>x.id)}));
   good(await post(k,mr+'/deliveries/'+delivery.id+'/receive',{...op(),received_quantity:'15.5',reason:'Meio quilo faltante na conferência'}));
   good(await post(k,mr+'/close',{...op(),notes:'Cozinha aceitou a diferença da entrega'}));
   const weighing=good(await post(e,'/api/crates/'+batch.crates[2].id+'/weigh',{...op(),weight:'3.2',notes:'Retorno do almoço'}));
   const idInv=good(await post(d,'/api/inventory-validations/total',{...op(),warehouse_id:wh})).id;
   const inv='/api/inventory-validations/'+idInv;
   const quantity={[p.kg.sku]:30,[p.un.sku]:41,[p.crate.sku]:3.2};
   const count=await get(d,inv+'/counting');
   for(const row of count.lines)good(await api(d,'PUT',inv+'/lines/'+row.sku_id+'/count',{physical_quantity:String(quantity[row.sku_id]),expected_version:row.version}));
   const review=await get(d,inv+'/review');
   const row=review.lines.find(x=>x.sku_id===p.un.sku);
   good(await api(d,'PUT',inv+'/lines/'+row.sku_id+'/recount',{physical_quantity:'41',expected_version:row.version}));
   good(await post(d,inv+'/complete',{completion_note:'Uma unidade a mais confirmada'}));
   good(await post(d,inv+'/lines/'+p.un.sku+'/adjust',op()));
   const history=await get(d,inv+'/history');
   const adjustment=history.lines.find(x=>x.sku_id===p.un.sku).adjustment_movement_id;
   const movements=jsonify("SELECT m.id,m.movement_type,m.document_number,ml.sku_id,ml.direction,ml.quantity,ml.unit_cost FROM movements m JOIN movement_lines ml ON ml.movement_id=m.id WHERE ml.warehouse_id="+wh+" ORDER BY m.id,ml.id");
   const stock=await get(d,'/api/stock?warehouse_id='+wh);
   const physical=Object.fromEntries(stock.map(x=>[x.name,number(x.quantity)]));
   assert.deepEqual(physical,{[p.kg.name]:30,[p.un.name]:41,[p.crate.name]:3.2});
   for(const product of Object.values(p)){
     const calc=movements.filter(x=>x.sku_id===product.sku).reduce((sum,x)=>sum+(x.direction==='IN'?1:-1)*number(x.quantity),0);
     assert.equal(Math.round(calc*1000),Math.round(physical[product.name]*1000),product.name);
   }
   const ret=movements.find(x=>x.direction==='OUT'&&x.id!==delivery.movement_id);
   day={wh,request:id,inventory:idInv,adjustment,delivery,returnMovement:ret?.id,entry,batch,physical,movements};
   save('day-flow',day);
   const ins=good(await mReport('ENTRADA',wh)),outs=good(await mReport('SAIDA',wh)),changes=await mReport('AJUSTE',wh);
   save('day-flow-reports',{ins,outs,changes});
   assert.ok(outs.some(r=>r.movement_id===delivery.movement_id&&r.document_number==='REQ-'+id));
   assert.ok(outs.some(r=>r.movement_id===ret.id));
   const allReports=[...ins,...outs,...(Array.isArray(changes.body)?changes.body:[])];
   assert.ok(allReports.some(r=>r.movement_id===adjustment),'Estoque conferido por ledger, mas ajuste '+adjustment+' ausente de Entradas/Saídas e filtro AJUSTE retorna HTTP '+changes.status+' '+JSON.stringify(changes.body));
   return 'Todas as linhas do dia conciliadas no relatório.';
 });
 await run('REL-05',d,'Comparar os três movimentos especiais do depósito do dia com Relatórios.',async()=>{
   if(!day)skip('O fluxo do dia não chegou à conciliação.');
   await open(d,'/reports');
   const r=JSON.parse(fs.readFileSync(out+'/day-flow-reports.json'));
   assert.equal(r.outs.filter(x=>x.movement_id===day.delivery.movement_id).length,2,'Entrega de duas caixas traz duas linhas');
   assert.equal(r.outs.filter(x=>x.movement_id===day.returnMovement).length,1);
   assert.equal(r.changes.status,200,'Filtro AJUSTE retorna '+r.changes.status+' '+JSON.stringify(r.changes.body));
   return 'Pesagem, entrega e ajuste únicos por movimento.';
 });
 await run('TRV-02',e,'Conferir concorrência já testada em saídas/entregas e enviar duas repesagens concorrentes à mesma caixa.',async()=>{
   const [box]=good(await post(e,'/api/crates/receive',{...op(),sku_id:p.crate.sku,warehouse_id:a,unit_cost:'3',document_number:'LAB-CX-RACE',weights:['5']})).crates;
   const r=await Promise.all(['2','3'].map(weight=>post(e,'/api/crates/'+box.id+'/weigh',{...op(),weight})));
   assert.ok(r.some(x=>x.status===200));assert.ok(r.every(x=>[200,409].includes(x.status)));
   const current=await get(e,'/api/crates/'+box.id);
   assert.equal(number(current.weight),2);
   const lot=jsonify("SELECT l.id,l.initial_quantity-COALESCE(SUM(x.quantity),0) AS remaining FROM stock_lots l LEFT JOIN stock_lot_allocations x ON x.stock_lot_id=l.id WHERE l.id="+box.lot_id+" GROUP BY l.id");
   assert.equal(number(lot[0].remaining),2);
   const prior=JSON.parse(fs.readFileSync(out+'/real-mov-retry.json')).find(x=>x.id==='MOV-10');
   const req=JSON.parse(fs.readFileSync(out+'/real-requests.json')).find(x=>x.id==='REQ-34');
   assert.equal(prior.estado,'passou');assert.equal(req.estado,'passou');
   return 'Pesagens HTTP '+r.map(x=>x.status).join('/')+', peso e lote 2 kg; MOV-10 e REQ-34 verificados.';
 });
 await run('TRV-03',d,'Reconciliar todos os depósitos: ledger por SKU, estoque agregado, lotes com caixas e reservas ativas.',async()=>{
   const balances=jsonify("SELECT ml.warehouse_id,ml.sku_id,ml.item_id,SUM(CASE WHEN ml.direction='IN' THEN ml.quantity ELSE -ml.quantity END) AS saldo FROM movement_lines ml GROUP BY 1,2,3");
   const reserved=jsonify("SELECT r.warehouse_id,r.sku_id,SUM(r.remaining_quantity) AS reservado FROM material_request_reservations r WHERE r.status='ATIVA' GROUP BY 1,2");
   const q="SELECT l.id,l.initial_quantity-COALESCE((SELECT sum(a.quantity) FROM stock_lot_allocations a WHERE a.stock_lot_id=l.id),0) AS restante,COALESCE((SELECT sum(c.current_weight) FROM stock_crates c WHERE c.stock_lot_id=l.id AND c.status='ACTIVE'),0) AS caixas FROM stock_lots l WHERE l.id IN (SELECT stock_lot_id FROM stock_crates UNION SELECT origin_lot_id FROM stock_crates)";
   const lots=jsonify(q);
   assert.ok(balances.every(r=>number(r.saldo)>=0));
   for(const x of reserved)assert.ok(number(x.reservado)<=number(balances.find(b=>b.sku_id===x.sku_id&&b.warehouse_id===x.warehouse_id)?.saldo||0),JSON.stringify(x));
   assert.ok(lots.every(x=>number(x.restante)===number(x.caixas)),JSON.stringify(lots.filter(x=>number(x.restante)!==number(x.caixas))));
   const within=await get(d,'/api/warehouses'), warehouses=[];
   for(const w of within){
     const expected=new Map();
     for(const line of balances.filter(x=>x.warehouse_id===w.id))expected.set(line.item_id,(expected.get(line.item_id)||0)+number(line.saldo));
     const screen=await get(d,'/api/stock?warehouse_id='+w.id);
     for(const [item,n] of expected)assert.equal(Math.round(number(screen.find(x=>x.item_id===item)?.quantity||0)*1000),Math.round(n*1000));
     warehouses.push({id:w.id,name:w.name,items:expected.size});
   }
   save('integrity',{balances,reserved,lots,warehouses});
   return balances.length+' pares SKU/depósito, '+lots.length+' lotes, '+reserved.length+' reservas agregadas; estoques visíveis conciliados.';
 });
 await run('TRV-06',d,'Inspecionar cabeçalhos, atributos de cookie e logs da aplicação.',async()=>{
   const response=await open(d,'/stock');
   const all=await response.allHeaders();
   const headers=Object.fromEntries(Object.entries(all).filter(([k])=>['content-security-policy','x-content-type-options','x-frame-options','referrer-policy','cache-control','permissions-policy','cross-origin-opener-policy'].includes(k)));
   assert.match(headers['content-security-policy'],/default-src 'self'/);
   assert.equal(headers['x-content-type-options'],'nosniff');
   const cookie=(await d.context().cookies()).find(c=>c.name==='estoque_session');
   assert.ok(cookie.httpOnly&&cookie.sameSite==='Strict');
   const file=execFileSync('docker',['compose','logs','app'],{encoding:'utf8'});
   assert.ok(![process.env.TF_TEST_BOOTSTRAP,process.env.TF_TEST_TEMP,process.env.TF_TEST_PASSWORD,cookie.value].some(value=>value&&file.includes(value)));
   save('security-headers',{headers,cookie:{name:cookie.name,httpOnly:cookie.httpOnly,sameSite:cookie.sameSite,secure:cookie.secure}});
   return 'CSP self, nosniff, HttpOnly e SameSite=Strict; credenciais de teste e cookie da sessão ausentes nos logs revisados.';
 });
 await run('TRV-04',d,'Conferir respostas de servidor registradas e log do app.',async()=>{
   const errors=fs.existsSync(out+'/browser-errors.jsonl')?fs.readFileSync(out+'/browser-errors.jsonl','utf8').split('\n').filter(Boolean).map(JSON.parse):[];
   const net=fs.readFileSync(out+'/http.jsonl','utf8').split('\n').filter(Boolean).map(JSON.parse).filter(x=>x.status>=500);
   save('server-errors',{errors,net});
   assert.deepEqual(net,[]);
   return 'Nenhum 5xx na trilha HTTP.';
 });
 await run('TRV-09',d,'Comparar migrações registradas no banco antes e depois de desligar bootstrap/recriar app.',async()=>{
   const files=fs.readdirSync('migrations').filter(x=>/^\d{3}_.+\.sql$/.test(x)).sort();
   const list=jsonify('SELECT version FROM schema_migrations ORDER BY version').map(x=>x.version);
   assert.deepEqual(list,files.map(x=>x.replace('.sql','')));
   assert.equal(list.length,43);
   assert.equal(fs.readFileSync(out+'/migrations-before.txt','utf8'),fs.readFileSync(out+'/migrations-after.txt','utf8'));
   return '43 migrações 001–042; registros e timestamps idênticos após recriar o app.';
 });
});
