const h=require('./real-common.cjs');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,arr,number,rows,main,save}=h;
const run=rows('real-mov-catalog');
main(async()=>{
 const d=await pageFor('d'), e=await pageFor('e');
 const started=Date.now(), wh=await get(d,'/api/warehouses'), options=await get(d,'/api/catalog/options');
 const category=options.categories.find(x=>x.name==='Alimentos').id;
 const a=wh.find(x=>x.id===1).id,b=wh.find(x=>x.id===2).id;
 const warehouseName='Lab depósito '+stamp;
 const newWh=good(await post(d,'/api/admin/warehouses',{name:warehouseName}));
 const c=newWh.id;
 const p={};let setupWrites=1;
 for(const [key,name,unit,minimum,barcode] of [
   ['kg','Arroz Lab '+stamp,'KG','500','709'+stamp+'1'],
   ['un','Pote Lab '+stamp,'UN','500','709'+stamp+'2'],
   ['crate','Melão Japonês Lab '+stamp,'KG','0','709'+stamp+'3']]){
   const item={...op(),name,category_id:category,unit_code:unit,minimum_stock:minimum,active:true};
   const created=good(await post(d,'/api/catalog/items',item));
   p[key]={item:created.id,name,unit,barcode};
   setupWrites++;
 }
 const brandName='Marca Lab '+stamp;
 const brandCreated=good(await post(d,'/api/catalog/brands',{...op(),name:brandName,active:true}));
 const brand=brandCreated.id;
 setupWrites++;
 for(const [key,product] of Object.entries(p)){
   if(key==='crate'){
     await run('CAT-04',d,'Criar SKU do Melão com brand_id 0 e validar o rótulo Sem marca.',async()=>{
       await open(d,'/products');
       const r=await post(d,'/api/catalog/skus',{...op(),item_id:product.item,brand_id:0,barcode:product.barcode,content_quantity:'1',active:true});
       product.sku=good(r).id;
       return 'SKU sem marca criado.';
     });
   }
   if(product.sku)continue;
   const sku=good(await post(d,'/api/catalog/skus',{...op(),item_id:product.item,brand_id:brand,barcode:product.barcode,content_quantity:'1',active:true}));
   product.sku=sku.id;
   setupWrites++;
 }
 save('fixture',{a,b,c,brand,brandName,warehouseName,p,setupWrites,fixtureMs:Date.now()-started});
 await run('ADM-05',d,'Criar depósito auxiliar e cadastrar o mesmo nome em caixa alta com espaços.',async()=>{
   const res=await post(d,'/api/admin/warehouses',{name:'  '+warehouseName.toUpperCase()+'  '});
   return JSON.stringify(bad(res,/nome|existe|cadastrado/i));
 });
 const stock=async(warehouse,product)=>{
   const data=await get(d,'/api/stock?warehouse_id='+warehouse);
   return arr(data,'items').find(r=>r.item_id===product.item);
 };
 const qty=async(w,p)=>number((await stock(w,p))?.quantity||'0');
 const line=(product,quantity,unit_cost='')=>({sku_id:product.sku,quantity:String(quantity),unit_cost});
 const batch=(page,type,data)=>post(page,'/api/movements/'+type+'/batch',data);
 const entry={...op(),warehouse_id:a,document_number:'LAB-MOV-01',supplier_name:'Fornecedor Lab',lines:[line(p.kg,350,'4.20'),line(p.un,420,'2.50')]};
 await run('MOV-01',e,'Lote real de 350 kg e 420 un no depósito VR com preço e documento.',async()=>{
   const before=[await qty(a,p.kg),await qty(a,p.un)];
   const result=good(await batch(e,'entry',entry));
   assert.deepEqual([await qty(a,p.kg),await qty(a,p.un)],before.map((n,i)=>n+[350,420][i]));
   return 'IDs '+JSON.stringify(result.movement_ids)+' e quantidades conferidas pela API. Custo no relatório e formulário de entrada requerem conferência independente.';
 });
 await run('MOV-02',e,'Enviar lote com linhas válidas nas pontas e SKU inexistente no meio.',async()=>{
   const before=[await qty(a,p.kg),await qty(a,p.un)];
   const r=await batch(e,'entry',{...op(),warehouse_id:a,lines:[line(p.kg,1,'4'),{sku_id:99999999,quantity:'1',unit_cost:'3'},line(p.un,2,'2')]});
   bad(r);
   assert.deepEqual([await qty(a,p.kg),await qty(a,p.un)],before);
   const msg=JSON.stringify(r.body);assert.match(msg,/linha|99999999|item 2/i);
   return r.status+' '+msg+'; estoque preservado.';
 });
 await run('MOV-03',e,'Enviar saída em lote com 1000 unidades quando há menos no estoque.',async()=>{
   const before=await qty(a,p.un);
   const r=await batch(e,'exit',{...op(),warehouse_id:a,lines:[line(p.un,1000)]});
   bad(r);assert.equal(await qty(a,p.un),before);
   return r.status+' '+JSON.stringify(r.body)+'; saldo '+before;
 });
 await run('MOV-06',e,'Transferir 20 unidades de VR para Câmara Fria e conferir os dois depósitos.',async()=>{
   const before=[await qty(a,p.un),await qty(b,p.un)];
   good(await batch(e,'transfer',{...op(),warehouse_from_id:a,warehouse_to_id:b,lines:[line(p.un,20)]}));
   const after=[await qty(a,p.un),await qty(b,p.un)];
   assert.deepEqual(after,[before[0]-20,before[1]+20]);return before+' → '+after;
 });
 await run('MOV-07',e,'Reenviar o mesmo corpo e operation_id de MOV-01 e depois mudar a quantidade.',async()=>{
   const before=await qty(a,p.kg), replay=good(await batch(e,'entry',entry));
   const conflict=await batch(e,'entry',{...entry,lines:[line(p.kg,1,'4.20')]});
   bad(conflict);assert.equal(await qty(a,p.kg),before);
   return 'Repetido: '+JSON.stringify(replay.movement_ids)+'. Corpo diferente: '+conflict.status+'.';
 });
 await run('MOV-10',e,'Dois usuários registram saídas concorrentes de 15 un do depósito com 20 un.',async()=>{
   const e2=await pageFor('g');
   const before=await qty(b,p.un);
   const responses=await Promise.all([e,e2].map(page=>batch(page,'exit',{...op(),warehouse_id:b,lines:[line(p.un,15)]})));
   assert.equal(responses.filter(x=>x.status<300).length,1,JSON.stringify(responses));
   assert.equal(await qty(b,p.un),before-15);
   return 'HTTP '+responses.map(r=>r.status).join(' / ')+'; restante '+await qty(b,p.un);
 });
 await run('ADM-06',d,'Desativar o depósito VR depois das entradas.',async()=>{
   const r=await post(d,'/api/admin/warehouses/'+a+'/deactivate',{});
   return r.status+' '+JSON.stringify(bad(r,/estoque|saldo/i));
 });
 await run('CAT-01',d,'Buscar os três itens, a marca de teste e os SKUs por código de barras.',async()=>{
   for(const product of Object.values(p)){
     const all=await get(d,'/api/products/lookup?q='+product.barcode);
     assert.ok(arr(all,'items').some(x=>x.sku_id===product.sku),JSON.stringify(all));
   }
   await open(d,'/products');
   const lookup=p.kg;
   await d.locator('#productSearch').fill(lookup.barcode);
   await d.locator('#productList').getByText(lookup.name,{exact:false}).first().waitFor();
   return 'Três códigos encontrados na API e item KG visível em Produtos; cadastros por API autenticada.';
 });
 await run('CAT-02',d,'Tentar criar SKU com código de barras já registrado.',async()=>{
   const r=await post(d,'/api/catalog/skus',{...op(),item_id:p.un.item,brand_id:brand,barcode:p.kg.barcode,content_quantity:'2',active:true});
   return r.status+' '+JSON.stringify(bad(r,/código de barras|barcode/i));
 });
});
