const fs=require('node:fs');
const {assert,out,op,stamp,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-inventory-retry');
main(async()=>{
 const d=await pageFor('d'), k=await pageFor('c'), d2=await pageFor('d');
 await open(d,'/inventory');
 const {a,b,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const warehouseName='Inventário Lab '+stamp;
 const c=good(await post(d,'/api/admin/warehouses',{name:warehouseName})).id;
 good(await post(d,'/api/admin/warehouses/'+c+'/activate',{}));
 const base='/api/inventory-validations';
 const create=w=>post(d,base+'/total',{...op(),warehouse_id:w});
 const blind=()=>post(d,base+'/blind',op());
 const info=(i,s='')=>get(d,base+'/'+i+(s?'/'+s:''));
 const adjust=(who,i,x,operation=op())=>post(who,base+'/'+i+'/lines/'+x.sku+'/adjust',operation);
 const count=(who,i,x,q,v,re=false)=>api(who,'PUT',base+'/'+i+'/lines/'+(x.sku||x.sku_id)+'/'+(re?'recount':'count'),{physical_quantity:String(q),expected_version:v});
 const cancel=(i)=>post(d,base+'/'+i+'/cancel',{cancellation_reason:'Cancelamento laboratorial'});
 const complete=(i,n='')=>post(d,base+'/'+i+'/complete',{completion_note:n});
 const st=()=>get(d,'/api/stock?warehouse_id='+c);
 const norm=x=>JSON.stringify(x);
 const qty=async x=>number((await st()).find(r=>r.item_id===x.item)?.quantity||0);
 const mov=(type,x,q)=>post(d,'/api/movements/'+type+'/batch',{...op(),warehouse_id:c,document_number:'LAB-INV-'+type,lines:[{sku_id:x.sku,quantity:String(q),unit_cost:type==='entry'?'3.20':''}]});
 await run('INV-02',d,'Abrir contagem total no depósito de laboratório ainda vazio.',async()=>{
   const r=await create(c);return r.status+' '+norm(bad(r,/não tem produtos/i));
 });
 for(const [x,q] of [[p.kg,20],[p.un,10]])good(await mov('entry',x,q));
 good(await post(d,'/api/crates/receive',{...op(),sku_id:p.crate.sku,warehouse_id:c,unit_cost:'5.00',document_number:'LAB-INV-CX',weights:['3','7']}));
 let id, lines, review, movId;
 await run('INV-01',d,'Abrir contagem total após abastecer dois produtos comuns e um controlado por caixa.',async()=>{
   const r=good(await create(c));id=r.id;
   const countView=await info(id,'counting');lines=countView.lines;
   assert.ok(countView.snapshot_at);
   assert.deepEqual(lines.map(l=>l.sku_id).sort((a,b)=>a-b),Object.values(p).map(x=>x.sku).sort((a,b)=>a-b));
   return '#'+id+' snapshot em '+countView.snapshot_at+', '+lines.length+' SKUs.';
 });
 if(!id)throw Error('Contagem de teste não disponível');
 const ln=x=>lines.find(y=>y.sku_id===x.sku);
 await run('INV-05',d,'Para a mesma linha, enviar -1, texto e número com quatro decimais.',async()=>{
   const r=await Promise.all(['-1','abc','1.1234'].map(q=>count(d,id,p.kg,q,ln(p.kg).version)));
   return r.map(x=>x.status+' '+norm(bad(x,/Quantidade contada inválida/i))).join(' | ');
 });
 await run('INV-06',d,'Localizar pelo código de barras do SKU presente na contagem.',async()=>{
   const data=await info(id,'lookup?barcode='+p.kg.barcode);
   assert.equal(data.in_inventory,true);assert.equal(data.sku_id,p.kg.sku);
   return norm(data);
 });
 await open(d2,'/inventory');
 await run('INV-08',d,'Duas sessões enviam a mesma versão da linha de Arroz em sequência.',async()=>{
   const first=good(await count(d,id,p.kg,20,ln(p.kg).version));
   const second=await count(d2,id,p.kg,21,ln(p.kg).version);
   assert.equal(number(first.line.physical_quantity),20);
   return second.status+' '+norm(bad(second,/Outra pessoa alterou/i));
 });
 await run('INV-07',d,'Fechar e reabrir a tela e consultar a contagem que estava em curso.',async()=>{
   await open(d,'/home');await open(d,'/inventory');
   const now=await info(id,'counting'),kg=now.lines.find(l=>l.sku_id===p.kg.sku);
   assert.equal(number(kg?.physical_quantity),20);
   return 'Primeira contagem preservada ao retornar.';
 });
 let during;
 await run('INV-04',d,'Completar três linhas com 20 kg, 13 un e zero kg, respectivamente.',async()=>{
   const r=good(await count(d,id,p.un,13,ln(p.un).version));
   assert.equal(number(r.line.physical_quantity),13);
   const zero=good(await count(d,id,p.crate,0,ln(p.crate).version));
   assert.equal(number(zero.line.physical_quantity),0);
   assert.equal(zero.status,'REVIEW');
   return 'Quantidade igual, divergente e zero aceitos; última linha muda para REVIEW.';
 });
 await run('INV-09',d,'Abrir revisão em /inventory e comparar estados de linha na resposta.',async()=>{
   review=await info(id,'review');
   assert.equal(review.status,'REVIEW');
   assert.ok(review.lines.some(l=>number(l.difference)===0)&&review.lines.some(l=>number(l.difference)!==0));
   await open(d,'/inventory');
   await d.locator('#inventoryId').fill(String(id));
   await d.locator('#inventoryOpenForm button[type=submit]').click();
   await d.getByText(/Divergente|Divergência/i).first().waitFor();
   await d.screenshot({path:out+'/capturas/INV-09-1366.png'});
   const txt=await d.locator('main').innerText();
   assert.match(txt,/Diverg/i);
   return 'Revisão mostra divergência por texto; API registra estados distintos.';
 });
 if(!review)review=await info(id,'review');
 const rln=x=>review.lines.find(y=>y.sku_id===x.sku);
 await run('INV-10',d,'Recontar o item divergente e repetir; tentar também o item sem divergência.',async()=>{
   const one=good(await count(d,id,p.un,12,rln(p.un).version,true));
   const dup=await count(d,id,p.un,13,one.line.version,true);
   const same=await count(d,id,p.kg,20,rln(p.kg).version,true);
   return [bad(dup,/já foi recontado/i),bad(same,/Só itens com divergência/i)].map(norm).join(' | ');
 });
 const crateRecount=good(await count(d,id,p.crate,0,rln(p.crate).version,true));
 const before=await st();
 await run('INV-11',d,'Concluir com divergência sem observação, depois com observação.',async()=>{
   const missing=await complete(id);bad(missing,/observação/i);
   const ended=good(await complete(id,'Divergências conferidas no laboratório'));
   return missing.status+' '+norm(missing.body)+' → '+norm(ended);
 });
 await run('INV-12',d,'Comparar posição antes e depois de concluir.',async()=>{
   assert.deepEqual(await st(),before);return 'Estoque integralmente preservado.';
 });
 await run('INV-17',k,'Cozinha tenta aplicar o ajuste de sobra.',async()=>{
   await open(k,'/material-requests');
   const r=await adjust(k,id,p.un);return r.status+' '+norm(bad(r,null,403));
 });
 let adj;
 await run('INV-13',d,'Aplicar sobra de duas unidades com custo e consultar o histórico.',async()=>{
   const previous=await qty(p.un);
   adj=good(await adjust(d,id,p.un));
   assert.equal(await qty(p.un),previous+2);
   const history=await info(id,'history');
   const row=history.lines.find(l=>l.sku_id===p.un.sku);
   assert.ok(row.adjustment_movement_id);
   movId=row.adjustment_movement_id;
   return 'Ajuste de +2 un no movimento '+movId+'; histórico com ID do movimento.';
 });
 await run('INV-14',d,'Repetir o ajuste com nova operação e dois envios simultâneos.',async()=>{
   const before=await qty(p.un);
   const denied=await Promise.all([adjust(d,id,p.un),adjust(d2,id,p.un)]);
   denied.forEach(r=>bad(r,/já foi ajustada/i));
   assert.equal(await qty(p.un),before);
   return denied.map(x=>x.status+' '+norm(x.body)).join(' | ');
 });
 await run('INV-21',d,'Contar produto com duas caixas e verificar tentativa de ajuste por peso total.',async()=>{
   assert.equal(lines.filter(x=>x.sku_id===p.crate.sku).length,1);
   assert.equal(number(rln(p.crate).reference_quantity),10);
   const before=await qty(p.crate);
   const r=await adjust(d,id,p.crate);
   save('crate-adjust-result',r);
   const active=await get(d,'/api/crates?warehouse_id='+c);
   const sum=active.filter(x=>x.sku_id===p.crate.sku).reduce((s,x)=>s+number(x.weight),0);
   const after=await qty(p.crate);
   assert.equal(after,sum,'Estoque '+after+' kg, caixas '+sum+' kg, resposta '+r.status+' '+norm(r.body));
   return 'Uma linha de 10 kg. Ajuste: '+r.status+' '+norm(r.body)+'; estoque '+before+' → '+after+', caixas '+sum+'.';
 });
 await run('INV-19',d,'Salvar contagem em validação concluída e em validação cancelada.',async()=>{
   const r=await count(d,id,p.kg,20,rln(p.kg).version);
   const canceled=good(await create(c)).id;
   const v=(await info(canceled,'counting')).lines.find(l=>l.sku_id===p.kg.sku).version;
   good(await cancel(canceled));
   const other=await count(d,canceled,p.kg,20,v);
   return [r,other].map(x=>x.status+' '+norm(bad(x,/não aceita mais alterações/i))).join(' | ');
 });
 let mismatchId;
 await run('INV-20',d,'Abrir nova contagem, fazer uma entrada de 2 kg e comparar a referência.',async()=>{
   mismatchId=good(await create(c)).id;
   const counting=await info(mismatchId,'counting');
   const snapshot=await qty(p.kg);
   const extra=await mov('entry',p.kg,2);good(extra);
   for(const line of counting.lines){
     const product=Object.values(p).find(prod=>prod.sku===line.sku_id);
     const q=product.sku===p.kg.sku?snapshot:await qty(product);
     good(await count(d,mismatchId,product,q,line.version));
   }
   const match=(await info(mismatchId,'review')).lines.find(x=>x.sku_id===p.kg.sku);
   assert.equal(number(match.reference_quantity),snapshot);
   assert.equal(await qty(p.kg),snapshot+2);
   return 'Entrada aceita; revisão '+match.reference_quantity+' kg, atual '+await qty(p.kg)+' kg. Aviso visual requer conferência.';
 });
 await run('INV-18',d,'Cancelar antes da revisão, durante revisão e após concluir.',async()=>{
   const other=good(await create(c)).id;
   good(await cancel(other));const a=await info(other,'history');
   if(!mismatchId)skip('Depende da contagem em revisão de INV-20.');
   good(await cancel(mismatchId));const b=await info(mismatchId,'history');
   const r=await cancel(id);bad(r);
   assert.ok(a.cancellation_reason&&b.cancellation_reason);
   return a.status+' / '+b.status+' / HTTP '+r.status;
 });
 await run('INV-03',d,'Abrir contagem cega e inspecionar corpo de criação e contagem.',async()=>{
   const b=good(await blind()), view=await info(b.id,'counting');
   assert.ok(view.lines.length&&view.warehouse_id);
   assert.doesNotMatch(norm({b,view}),/reference_quantity|system_quantity|snapshot_quantity|current_stock/);
   await open(d,'/inventory');
   await d.screenshot({path:out+'/capturas/INV-03-1366.png'});
   good(await cancel(b.id));
   return 'Depósito escolhido '+view.warehouse_id+', linhas '+view.lines.length+', sem campo de saldo na API observada.';
 });
 await run('INV-22',d,'Filtrar lista por tipo, status e datas e testar status inválido.',async()=>{
   const r=await api(d,'GET',base+'?type=TOTAL&status=COMPLETED');
   good(r);
   const invalid=await api(d,'GET',base+'?status=NAO_EXISTE');
   return 'Válido: '+r.status+'; inválido '+invalid.status+' '+norm(bad(invalid,/inválid|filtro/i));
 });
 save('inventory-end',{id,movId,c});
});
