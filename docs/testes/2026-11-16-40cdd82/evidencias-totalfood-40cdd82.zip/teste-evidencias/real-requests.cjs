const fs=require('node:fs');
const {assert,out,op,pageFor,open,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-requests');
main(async()=>{
 const {a,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const e=await pageFor('e'), c=await pageFor('c'), c2=await pageFor('c2'), d=await pageFor('d');
 const mobile=await pageFor('e',390);
 const base='/api/material-requests', day=new Date().toISOString().slice(0,10);
 const current=[], evidence=x=>JSON.stringify(x);
 const newReq=async(items)=>{
   const result=good(await post(c,base,{...op(),unit_name:'Cozinha ensaio local',delivery_date:day,production_date:day,service:'almoco',notes:'Rodada funcional',lines:items.map(([x,q])=>({item_id:x.item,quantity:String(q)}))}));
   current.push(result.id);save('request-ids',current);return result.id;
 };
 const detail=(id,who=c)=>get(who,base+'/'+id);
 const action=(who,id,route,data={})=>post(who,base+'/'+id+'/'+route,data);
 const reserveRaw=async(id,x,q)=>{
   const line=(await detail(id)).lines.find(l=>l.item_id===x.item);
   return action(e,id,'reserve',{...op(),line_id:line.id,sku_id:x.sku,warehouse_id:a,quantity:String(q)});
 };
 const reserve=async(...args)=>good(await reserveRaw(...args)).id;
 const delivery=(id,rid,q,crate_ids)=>action(e,id,'deliver',{...op(),reservation_id:rid,quantity:String(q),crate_ids});
 const receive=(who,id,did,q,reason='')=>action(who,id,'deliveries/'+did+'/receive',{...op(),received_quantity:String(q),reason});
 const state=async(id,expected)=>assert.equal((await detail(id)).status,expected);
 const stock=()=>get(d,'/api/stock?warehouse_id='+a);
 const qty=async(x)=>number((await stock()).find(l=>l.item_id===x.item)?.quantity||0);
 const exit=(x,q)=>post(e,'/api/movements/exit/batch',{...op(),warehouse_id:a,lines:[{sku_id:x.sku,quantity:String(q)}]});
 const addEntry=(x,q)=>post(e,'/api/movements/entry/batch',{...op(),warehouse_id:a,document_number:'LAB-REQ-CARGA',lines:[{sku_id:x.sku,quantity:String(q),unit_cost:'4.20'}]});
 if(await qty(p.kg)<650)good(await addEntry(p.kg,520));
 if(await qty(p.un)<250)good(await addEntry(p.un,500));
 let id,rid,did,stockBefore;
 await run('REQ-01',c,'Cozinha cria pedido com 10 kg e 4 un e abre o detalhe.',async()=>{
   id=await newReq([[p.kg,10],[p.un,4]]);const r=await detail(id);assert.equal(r.lines.length,2);assert.equal(r.status,'PENDENTE');
   await open(c,'/material-requests');
   await c.screenshot({path:out+'/capturas/REQ-01-1366.png'});
   return '#'+id+' PENDENTE, com duas linhas (API autenticada).';
 });
 if(!id)throw Error('Dependência REQ-01 indisponível');
 await run('REQ-02',e,'Separar 6 kg e tentar uma saída comum maior que o livre.',async()=>{
   stockBefore=await qty(p.kg);rid=await reserve(id,p.kg,6);await state(id,'EM_SEPARACAO');
   const r=await exit(p.kg,stockBefore-1);bad(r);
   assert.equal(await qty(p.kg),stockBefore);
   return 'ID da reserva '+rid+'; saída comum recusada HTTP '+r.status+'; estoque físico preservado.';
 });
 await run('REQ-03',e,'Liberar a primeira reserva e verificar restante e estado.',async()=>{
   if(!rid)skip('Depende de REQ-02.');
   good(await action(e,id,'reservations/'+rid+'/release',{}));
   const row=(await detail(id)).reservations.find(r=>r.id===rid);assert.equal(number(row.remaining),0);
   await state(id,'PENDENTE');return 'Reserva sem quantidade restante; pedido voltou a PENDENTE.';
 });
 await run('REQ-04',e,'Separar e entregar 6 kg, medindo saída no estoque.',async()=>{
   rid=await reserve(id,p.kg,6);const before=await qty(p.kg);
   const result=good(await delivery(id,rid,6));did=result.id;
   await state(id,'ENTREGA_PARCIAL');assert.equal(await qty(p.kg),before-6);
   return 'Entrega '+did+'; movimento '+result.movement_id+'; saída de 6 kg.';
 });
 if(!did)throw Error('Dependência REQ-04 indisponível');
 await run('REQ-05',e,'Abrir pedido e conferir texto, marca, apresentação e depósito da entrega.',async()=>{
   await open(e,'/material-requests');
   const node=e.getByText('Cozinha ensaio local',{exact:false}).first();
   await node.click();
   const text=await e.locator('main').innerText();
   assert.match(text,new RegExp(p.kg.name+'.{0,10}6(?:[,.]0+)?\\s*kg','i'));
   assert.match(text,/VR/);
   await e.screenshot({path:out+'/capturas/REQ-05-1366.png'});return 'Material e peso no título; depósito VR no detalhe.';
 });
 await run('REQ-09',c2,'Outra Cozinha tenta confirmar a primeira entrega.',async()=>{
   const r=await receive(c2,id,did,6);return r.status+' '+evidence(bad(r,null,403));
 });
 await run('REQ-10',e,'Estoquista tenta confirmar a entrega que separou.',async()=>{
   const r=await receive(e,id,did,6);return r.status+' '+evidence(bad(r,null,403));
 });
 await run('REQ-06',c,'Solicitante confirma os 6 kg recebidos integralmente.',async()=>{
   good(await receive(c,id,did,6));
   const got=(await detail(id)).deliveries.find(x=>x.id===did);
   assert.equal(got.received,true);assert.equal(number(got.received_quantity),6);
   return 'Entrega conferida em 6 kg.';
 });
 await run('REQ-07',c,'Entregar e confirmar os 4 kg e as 4 unidades restantes.',async()=>{
   for(const [x,q] of [[p.kg,4],[p.un,4]]){
     const r=await reserve(id,x,q), del=good(await delivery(id,r,q));
     good(await receive(c,id,del.id,q));
   }
   await state(id,'RECEBIDA');return '#'+id+' RECEBIDA.';
 });
 await run('REQ-08',c,'Cancelar um pedido novo e tentar cancelar o pedido que já teve entrega.',async()=>{
   const fresh=await newReq([[p.un,1]]);
   good(await action(c,fresh,'cancel',{}));await state(fresh,'CANCELADA');
   const r=await action(c,id,'cancel',{});return 'Novo: CANCELADA. Com entrega: '+r.status+' '+evidence(bad(r));
 });
 const big=await newReq([[p.kg,200]]);
 const bigRes=await reserve(big,p.kg,200);
 const bigD=good(await delivery(big,bigRes,200)).id;
 const reqActions=await detail(big);
 const initialStock=await stock();
 await run('REQ-11',c,'Entregue 200 kg, confirmar 180 sem motivo.',async()=>{
   const r=await receive(c,big,bigD,180);return r.status+' '+evidence(bad(r,/motivo/i));
 });
 await run('REQ-12',c,'Entregue 200 kg, confirmar 201 com motivo.',async()=>{
   const r=await receive(c,big,bigD,201,'Vale de teste');return r.status+' '+evidence(bad(r,/maior|entregue|superior/i));
 });
 const rawRecv={...op(),received_quantity:'180',reason:'Conferência experimental, 20 kg pendentes'};
 const recUrl='deliveries/'+bigD+'/receive', confUrl='deliveries/'+bigD+'/reconcile';
 await run('REQ-13',c,'Confirmar 180 de 200 kg com motivo e consultar o restante.',async()=>{
   good(await action(c,big,recUrl,rawRecv));
   const r=await detail(big);assert.equal(r.status,'RECEBIDA_COM_DIVERGENCIA');assert.equal(number(r.deliveries[0].pending_divergence),20);
   return 'RECEBIDA_COM_DIVERGENCIA e 20 kg pendentes (API).';
 });
 await run('REQ-14',c,'Repetir operação exata e tentar informar 170 kg.',async()=>{
   const before=await detail(big);
   good(await action(c,big,recUrl,rawRecv));assert.deepEqual(await detail(big),before);
   const r=await action(c,big,recUrl,{...rawRecv,received_quantity:'170'});
   return 'Replay sem alteração; corpo diferente '+r.status+' '+evidence(bad(r));
 });
 await run('REQ-16',c,'Tentar confirmar 21 kg quando faltam 20.',async()=>{
   const r=await action(c,big,confUrl,{...op(),quantity:'21',notes:'Excesso'});
   return r.status+' '+evidence(bad(r,/diferença|falt|maior|pendente/i));
 });
 await run('REQ-15',c,'Confirmar 5 e depois 15 kg do restante, em duas ações.',async()=>{
   good(await action(c,big,confUrl,{...op(),quantity:'5',notes:'Primeira parcela'}));
   assert.equal(number((await detail(big)).deliveries[0].pending_divergence),15);
   good(await action(c,big,confUrl,{...op(),quantity:'15',notes:'Segunda parcela'}));
   const r=await detail(big);assert.equal(r.status,'RECEBIDA');assert.equal(number(r.deliveries[0].pending_divergence),0);
   assert.ok(r.deliveries[0].receipts.length>=3);
   return r.status+'; '+r.deliveries[0].receipts.length+' registros de recebimento.';
 });
 await run('REQ-17',d,'Comparar estoque e IDs de movimento da entrega antes e depois de conferir/conciliar.',async()=>{
   assert.deepEqual(await stock(),initialStock);
   assert.deepEqual((await detail(big)).deliveries.map(x=>x.movement_id),reqActions.deliveries.map(x=>x.movement_id));
   return 'Estoque e movimento associado à entrega preservados.';
 });
 await run('REQ-18',c,'Entregar 2 unidades e confirmar recebimento zero com motivo.',async()=>{
   const z=await newReq([[p.un,2]]);const rd=good(await delivery(z,await reserve(z,p.un,2),2)).id;
   good(await receive(c,z,rd,0,'Nada chegou no balcão'));
   const actual=(await detail(z)).deliveries[0];assert.equal(number(actual.pending_divergence),2);
   return 'Zero aceito, 2 unidades em divergência.';
 });
 const kg=await newReq([[p.kg,106]]);let weightR;
 await run('REQ-19',e,'Pedir 106 kg, separar 110 kg e tentar separar mais 20 kg.',async()=>{
   weightR=await reserve(kg,p.kg,110);
   const r=await reserveRaw(kg,p.kg,20);return '110 kg aceitos; mais 20: '+r.status+' '+evidence(bad(r));
 });
 await run('REQ-20',e,'Entregar 108,7 kg de item comum em KG.',async()=>{
   if(!weightR)skip('Depende da separação de REQ-19.');
   good(await delivery(kg,weightR,108.7));await state(kg,'ENTREGUE');
   return '108,7 kg aceitos e pedido ENTREGUE.';
 });
 await run('REQ-21',e,'Pedir 106 unidades e tentar separar 110.',async()=>{
   const un=await newReq([[p.un,106]]);const r=await reserveRaw(un,p.un,110);
   return r.status+' '+evidence(bad(r));
 });
 const closeID=await newReq([[p.kg,106]]), emptyID=await newReq([[p.kg,3]]);
 const closeR=await reserve(closeID,p.kg,106), closeD=good(await delivery(closeID,closeR,104.3)).id;
 const closeRequest=(who,id)=>action(who,id,'close',{...op(),notes:'Peso real aceito no laboratório'});
 await run('REQ-23',c,'Tentar encerrar sem entrega e com entrega ainda sem conferência.',async()=>{
   const rs=await Promise.all([closeRequest(c,emptyID),closeRequest(c,closeID)]);
   return rs.map(r=>r.status+' '+evidence(bad(r,/entreg|confirm|confer/i))).join(' | ');
 });
 await run('REQ-22',c,'Conferir 104,3 de 106 kg e procurar ação de encerramento no detalhe.',async()=>{
   good(await receive(c,closeID,closeD,104.3));await state(closeID,'ENTREGA_PARCIAL');
   await open(c,'/material-requests');
   await c.getByText('Cozinha ensaio local',{exact:false}).first().click();
   await c.getByRole('button',{name:'Aceitar e encerrar',exact:false}).first().waitFor();
   return 'ENTREGA_PARCIAL e botão Aceitar e encerrar.';
 });
 await run('REQ-24',e,'Estoquista tenta fechar o pedido da Cozinha.',async()=>{
   const r=await closeRequest(e,closeID);return r.status+' '+evidence(bad(r,null,403));
 });
 await run('REQ-25',c,'Cozinha encerra com observação e confere reserva e histórico.',async()=>{
   good(await closeRequest(c,closeID));const r=await detail(closeID);
   assert.equal(r.status,'RECEBIDA');assert.ok(r.reservations.every(x=>number(x.remaining)===0));
   assert.match(evidence(r.events),/ENCERRADA/);
   return 'RECEBIDA, reservas liberadas e evento ENCERRADA.';
 });
 await run('REQ-26',e,'Tentar entregar outra vez após o encerramento.',async()=>{
   const r=await delivery(closeID,closeR,1);return r.status+' '+evidence(bad(r));
 });
 const receiveCrates=async weights=>good(await post(e,'/api/crates/receive',{...op(),sku_id:p.crate.sku,warehouse_id:a,unit_cost:'5.00',document_number:'LAB-REQ-CX',weights:weights.map(String)})).crates;
 const weights=[19.3,18.9,22,21.8,20.9,8.9];
 const boxes=await receiveCrates(weights), boxId=await newReq([[p.crate,106]]), boxRes=await reserve(boxId,p.crate,102.9);
 const ids=boxes.slice(0,5).map(b=>b.id);
 const boxSnapshot=async()=>({req:await detail(boxId),stock:await qty(p.crate),boxes:await Promise.all(ids.map(b=>get(e,'/api/crates/'+b)))});
 const startBox=await boxSnapshot();
 await run('REQ-27',e,'Tentar entregar 102,9 kg sem indicar caixas.',async()=>{
   const r=await delivery(boxId,boxRes,102.9);return r.status+' '+evidence(bad(r,/caixa/i))+'; comportamento do botão Enviar de novo requer UI.';
 });
 await run('REQ-32',e,'Enviar cinco caixas na API com quantidade menor que a soma.',async()=>{
   const r=await delivery(boxId,boxRes,102,ids);return r.status+' '+evidence(bad(r,/caixa|peso|soma/i));
 });
 await run('REQ-35',e,'Comparar reserva, caixas e estoque depois das recusas.',async()=>{
   assert.deepEqual(await boxSnapshot(),startBox);return 'Estado integral preservado em REQ-27 e REQ-32.';
 });
 let boxDelivery;
 await run('REQ-29',e,'Entregar as CINCO caixas identificadas com soma de 102,9 kg.',async()=>{
   boxDelivery=good(await delivery(boxId,boxRes,102.9,ids));
   const r=await boxSnapshot();assert.equal(r.req.deliveries.length,1);assert.equal(r.req.deliveries[0].crates.length,5);
   assert.ok(r.boxes.every(x=>number(x.weight)===0));
   assert.equal(Math.round((startBox.stock-r.stock)*10),1029);
   return 'Movimento '+boxDelivery.movement_id+'; entrega única, cinco caixas vazias e peso baixado.';
 });
 await run('REQ-33',e,'Tentar incluir uma caixa já vazia em outra entrega.',async()=>{
   const testId=await newReq([[p.crate,5]]), rid=await reserve(testId,p.crate,5);
   const r=await delivery(testId,rid,5,[ids[0]]);return r.status+' '+evidence(bad(r,/caixa|ativa|peso/i));
 });
 const [partial]=await receiveCrates([12]), partId=await newReq([[p.crate,10]]), partR=await reserve(partId,p.crate,10);
 await run('REQ-31',e,'Entregar 7 kg marcando apenas a caixa de 12 kg.',async()=>{
   good(await delivery(partId,partR,7,[partial.id]));
   const r=await get(e,'/api/crates/'+partial.id);assert.equal(number(r.weight),5);assert.equal(r.revision,partial.revision+1);
   const jobs=(await get(e,'/api/print/jobs')).jobs;assert.ok(jobs.some(j=>j.crate_id===r.id&&j.revision===r.revision&&j.status==='PENDING'));
   return r.code+' ativa com 5 kg e nova etiqueta.';
 });
 const reweighed=await receiveCrates([7,8]), reweighId=await newReq([[p.crate,15]]), rewR=await reserve(reweighId,p.crate,15);
 await run('REQ-30',e,'Repesar 7 kg para 6 kg após reserva e reenviar soma antiga e nova.',async()=>{
   const w=await post(e,'/api/crates/'+reweighed[0].id+'/weigh',{...op(),weight:'6'});
   good(w);
   const boxIDs=reweighed.map(x=>x.id), old=await delivery(reweighId,rewR,15,boxIDs);
   bad(old);
   const fresh=good(await delivery(reweighId,rewR,14,boxIDs));
   return '15 kg: HTTP '+old.status+'; 14 kg: entrega '+fresh.id+'.';
 });
 const [shared]=await receiveCrates([12]), raceId=await newReq([[p.crate,12]]), raceR=await reserve(raceId,p.crate,12);
 await run('REQ-34',e,'Enviar simultaneamente duas entregas novas com a mesma caixa.',async()=>{
   const results=await Promise.all([delivery(raceId,raceR,12,[shared.id]),delivery(raceId,raceR,12,[shared.id])]);
   assert.equal(results.filter(x=>x.status<300).length,1,evidence(results));
   assert.equal(number((await get(e,'/api/crates/'+shared.id)).weight),0);
   assert.equal((await detail(raceId)).deliveries.length,1);
   return 'HTTP '+results.map(r=>r.status).join(' / ')+'; uma saída e caixa vazia.';
 });
 await open(mobile,'/material-requests');
 await mobile.screenshot({path:out+'/capturas/REQ-390-com-dados.png'});
 save('req-end',{current,boxId,big,closeID,boxDelivery});
});
