const {chromium}=require('playwright');
const fs=require('node:fs');
const assert=require('node:assert/strict');
const base='http://127.0.0.1:5656';
const out='teste-evidencias';
const rows=[];
const viewports=[{width:390,height:844},{width:1366,height:900}];
async function post(page, route, data, method='POST', csrf=true){
  const token=csrf ? await page.locator('meta[name=csrf-token]').getAttribute('content') : null;
  const r=await page.request.fetch(base+route,{method,data,headers:token?{'X-CSRF-Token':token}:{}});
  const raw=await r.text();
  let body=raw;
  try{body=JSON.parse(raw)}catch{}
  return {status:r.status(),body};
}
async function signIn(page,user,pass){
  await page.goto(base+'/login');
  await page.locator('[name=login]').fill(user);
  await page.locator('[name=password]').fill(pass);
  await page.locator('form button').click();
}
async function change(page, previous, next){
  await page.locator('#forcedCurrent').fill(previous);
  await page.locator('#forcedNew').fill(next);
  await page.locator('#forcedConfirm').fill(next);
  const r=page.waitForResponse(x=>x.url().endsWith('/api/me/password'));
  await page.locator('#forcedPasswordForm button').click();
  assert.equal((await r).status(),200);
  await page.waitForURL(u=>!u.pathname.endsWith('/change-password'));
}
async function main(){
  for(const key of ['TF_TEST_BOOTSTRAP','TF_TEST_PASSWORD','TF_TEST_TEMP']) assert.ok(process.env[key],key);
  const b=await chromium.launch({executablePath:process.env.CHROME_BIN||'/usr/bin/google-chrome',args:['--no-sandbox']});
  const pass=process.env.TF_TEST_PASSWORD, bootstrap=process.env.TF_TEST_BOOTSTRAP;
  try{
    const p=await b.newPage({viewport:viewports[0]});
    p.setDefaultTimeout(8000);
    const run=async(id,fn)=>{
      try{rows.push({id,estado:'passou',obs:await fn()})}
      catch(e){rows.push({id,estado:'falhou',obs:e.message});await p.screenshot({path:out+'/'+id+'.png'}).catch(()=>{})}
      fs.writeFileSync(out+'/real-access.json',JSON.stringify(rows,null,2));
    };
    await run('ACE-03',async()=>{await p.goto(base+'/stock');assert.match(p.url(),/\/login$/);return 'Sem sessão, /stock redirecionou a /login.'});
    await run('ACE-01',async()=>{
      await signIn(p,'diretor','senha-incorreta-test');
      const msg=await p.getByRole('alert').innerText();
      assert.match(msg,/incorret/);
      await signIn(p,'diretor',bootstrap);
      assert.match(p.url(),/change-password$/);
      return msg+' Senha inicial levou à troca obrigatória.';
    });
    await run('ACE-02',async()=>{
      await p.goto(base+'/stock');
      assert.match(p.url(),/change-password$/);
      await p.screenshot({path:out+'/ACE-02.png'});
      await change(p,bootstrap,pass);
      await p.goto(base+'/home');
      assert.match(p.url(),/home$/);
      return 'Troca exigida ao abrir /stock. Após salvar, /home disponível.';
    });
    await p.goto(base+'/admin');
    if(!p.url().endsWith('/admin')) throw Error('Sessão de Diretor indisponível: '+p.url());
    const roles=[['t-gerente','Gerente'],['t-estoquista','Estoquista'],['t-cozinha','Cozinha'],['t-cozinha2','Cozinha']];
    const users=await p.request.get(base+'/api/admin/users');
    const existing=JSON.stringify(await users.json());
    const created=[];
    for(const [login,role] of roles){
      if(existing.includes('"'+login+'"')) continue;
      const sel=p.locator('#adminUserProfile');
      await sel.selectOption({label:role});
      await p.locator('#adminUserLogin').fill(login);
      await p.locator('#adminUserPassword').fill(process.env.TF_TEST_TEMP);
      const res=p.waitForResponse(r=>r.url().endsWith('/api/admin/users')&&r.request().method()==='POST');
      await p.locator('#adminUserForm button[type=submit]').click();
      const r=await res;
      assert.ok(r.ok(),await r.text());
      created.push(login);
    }
    const cookies=(await p.context().cookies()).map(({name,httpOnly,sameSite,secure})=>({name,httpOnly,sameSite,secure}));
    console.log(JSON.stringify({created,cookies}));
    fs.writeFileSync(out+'/setup.json',JSON.stringify({created,cookies},null,2));
  } finally {await b.close()}
}
main().catch(err=>{console.error(err);process.exitCode=1});
