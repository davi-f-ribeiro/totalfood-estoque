const fs=require('node:fs');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-inventory-catalog-extra');
main(async()=>{
 const {a,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'), m=await pageFor('d',390);
 const mkWarehouse=async name=>{
   const wh=good(await post(d,'/api/admin/warehouses',{name:name+' '+stamp})).id;
   good(await post(d,'/api/admin/warehouses/'+wh+'/activate',{}));return wh;
 };
 const mov=(w,type,sku,qty,cost)=>post(d,'/api/movements/'+type+'/batch',{...op(),warehouse_id:w,document_number:'LAB-INVENTARIO-EXTRA',lines:[{sku_id:sku,quantity:String(qty),unit_cost:cost}]});
 const root='/api/inventory-validations';
 const newCount=async w=>good(await post(d,root+'/total',{...op(),warehouse_id:w})).id;
 async function completeCount(w,sku,qty){
   const id=await newCount(w), link=root+'/'+id;
   const open=await get(d,link+'/counting');
   for(const row of open.lines)good(await api(d,'PUT',link+'/lines/'+row.sku_id+'/count',{physical_quantity:String(qty),expected_version:row.version}));
   const review=await get(d,link+'/review');
   const line=review.lines.find(l=>l.sku_id===sku);
   good(await api(d,'PUT',link+'/lines/'+sku+'/recount',{physical_quantity:String(qty),expected_version:line.version}));
   good(await post(d,link+'/complete',{completion_note:'Contagem confirmada no laboratório.'}));
   return link+'/lines/'+sku+'/adjust';
 }
 await run('INV-15',d,'Abrir contagem com 10 un, contar e recontar 2, concluir, depois dar saída de 5 e tentar reduzir 8.',async()=>{
   const w=await mkWarehouse('Redução acima do estoque');
   good(await mov(w,'entry',p.un.sku,10,'2'));
   const adjust=await completeCount(w,p.un.sku,2);
   good(await mov(w,'exit',p.un.sku,5));
   const r=await post(d,adjust,op());return r.status+' '+JSON.stringify(bad(r,/estoque atual é menor/i));
 });
 await run('INV-16',d,'Criar posição zero custo, contar sobra, zerar saldo e aplicar ajuste.',async()=>{
   const w=await mkWarehouse('Contagem sem preço');
   const entry=await mov(w,'entry',p.un.sku,10,'0');
   if(entry.status>=400)skip('A API de entrada recusou massa sem custo: '+entry.status+' '+JSON.stringify(entry.body)+'. O teste de domínio em Go cobre a fixture de custo zero.');
   const adjust=await completeCount(w,p.un.sku,12);
   good(await mov(w,'exit',p.un.sku,10));
   const r=await post(d,adjust,op());return r.status+' '+JSON.stringify(bad(r,/Não há custo válido/i));
 });
 await run('INV-23',m,'Montar dez SKUs comuns no depósito e registrar dez linhas na interface móvel.',async()=>{
   const w=await mkWarehouse('Contar dez linhas');
   const data=await get(d,'/api/catalog/products?q=');
   const products=Array.isArray(data)?data:data.items;
   const skus=[...new Set(products.filter(x=>x.active&&x.id).map(x=>x.id))].slice(0,10);
   assert.equal(skus.length,10);
   good(await post(d,'/api/movements/entry/batch',{...op(),warehouse_id:w,document_number:'LAB-10-LINHAS',lines:skus.map(sku=>({sku_id:sku,quantity:'1',unit_cost:'3'}))}));
   const id=await newCount(w);
   await open(m,'/inventory');
   await m.locator('#inventoryId').fill(String(id));
   await m.locator('#inventoryOpenForm button[type=submit]').click();
   const box=m.locator('#inventoryLines');
   let actions=0;
   for(let i=0;i<10;i++){
     const row=box.locator('article.inventory-line').first();
     const input=row.locator('input');
     await input.fill('1');actions++;
     const response=m.waitForResponse(r=>r.url().endsWith('/count')&&r.request().method()==='PUT');
     await row.getByRole('button',{name:/Salvar/i}).first().click();actions++;
     const r=await response;assert.equal(r.status(),200,await r.text());
     await m.waitForLoadState('networkidle');
   }
   const audit=await get(d,root+'/'+id+'/review');
   assert.equal(audit.lines.length,10);
   await m.screenshot({path:out+'/capturas/INV-23-390.png'});
   return 'Dez linhas gravadas, '+actions+' ações de campo/salvar, além da digitação e de rolar. Chrome emulado sem teclado virtual do sistema operacional.';
 });
 const cat='/api/catalog', opt=(await get(d,cat+'/options')).categories[0].id;
 const br=(name)=>post(d,cat+'/brands',{...op(),name,active:true});
 const it=(name)=>post(d,cat+'/items',{...op(),name,category_id:opt,unit_code:'UN',minimum_stock:'0',active:true});
 await run('CAT-03',d,'Criar item/marca/SKU, lançar entrada, renomear e desativar com histórico.',async()=>{
   const name='Item arquivamento '+stamp, brandName='Marca arquivamento '+stamp, barcode='729'+stamp+'1';
   const i=good(await it(name)), b=good(await br(brandName));
   const sku=good(await post(d,cat+'/skus',{...op(),item_id:i.id,brand_id:b.id,name:'SKU '+stamp,barcode,content_quantity:'1',active:true}));
   good(await mov(a,'entry',sku.id,2,'2'));
   const s=good(await api(d,'PATCH',cat+'/skus/'+sku.id,{version:sku.version,item_id:i.id,brand_id:b.id,barcode,name:'SKU editado '+stamp,content_quantity:'1',active:false}));
   const item=await api(d,'PATCH',cat+'/items/'+i.id,{version:i.version,name:name+' editado',category_id:opt,unit_code:'UN',minimum_stock:'0',active:false});
   const brand=await api(d,'PATCH',cat+'/brands/'+b.id,{version:b.version,name:brandName+' editada',active:false});
   const look=await get(d,'/api/products/lookup?q='+barcode);
   assert.ok(!look.some(x=>x.sku_id===sku.id));
   const qs=new URLSearchParams({type:'ENTRADA',start:'2026-11-16T00:00:00-03:00',end:'2026-11-17T00:00:00-03:00',warehouse_id:String(a)});
   const report=await get(d,'/api/reports/movements?'+qs);
   assert.ok(report.some(r=>r.barcode===barcode));
   assert.ok(item.status<300&&brand.status<300,'Item e marca: '+JSON.stringify({item,brand}));
   return 'SKU saiu da busca, movimento de entrada permaneceu e item/marca retornaram 200.';
 });
 await run('CAT-05',m,'Abrir abas e formulário. Popular itens e marcas além da primeira página e rolar a lista.',async()=>{
   for(let i=1;i<=43;i++){
     await it('Paginação item '+stamp+' '+String(i).padStart(2,'0')).then(good);
     await br('Paginação marca '+stamp+' '+String(i).padStart(2,'0')).then(good);
   }
   await open(m,'/catalog');
   const results=[];
   for(const [tab,list,newButton,endpoint,dialog] of [
     ['#masterTabItems','#masterItemList','#masterNewItem','/api/catalog/items','#masterItemDialog'],
     ['#masterTabBrands','#masterBrandList','#masterNewBrand','/api/catalog/brands','#masterBrandDialog']
   ]){
     await m.locator(tab).click();
     await m.locator(list+' button').first().waitFor();
     const before=await m.locator(list+' button').count();
     const more=m.waitForResponse(r=>new URL(r.url()).pathname===endpoint&&new URL(r.url()).searchParams.has('cursor'),{timeout:8000});
     await m.evaluate(()=>window.scrollTo(0,document.body.scrollHeight));
     await m.locator(list).evaluate(e=>e.lastElementChild?.scrollIntoView());
     await more;
     const end=await m.locator(list+' button').count();
     assert.ok(end>before);
     await m.locator(newButton).click();
     const box=await m.locator(dialog).boundingBox();
     assert.ok(Math.abs(box.y+box.height-844)<5,'Folha não alinhada na base: '+JSON.stringify(box));
     await m.screenshot({path:out+'/capturas/CAT-05-'+tab.slice(10)+'.png'});
     await m.keyboard.press('Escape');
     results.push(before+' → '+end);
   }
   return 'Itens e marcas paginaram ('+results.join(', ')+'); formulários à base do viewport.';
 });
});
