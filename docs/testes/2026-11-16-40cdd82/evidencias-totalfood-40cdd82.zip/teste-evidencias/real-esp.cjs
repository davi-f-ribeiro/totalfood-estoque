const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,out,pageFor,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-esp');
main(async()=>{
  const source=fs.readFileSync('firmware/etiqueta_zd220/web_pages.h','utf8');
  const parts=Object.fromEntries([...source.matchAll(/static const char (\w+)\[\] = R"(HTML|JS)\(([\s\S]*?)\)\2";/g)].map(x=>[x[1],x[3]]));
  const css=fs.readFileSync('cmd/server/static/app.css','utf8');
  const vars=x=>Object.fromEntries([...x.matchAll(/(--[a-z-]+)\s*:\s*([^;{}]+)/g)].map(y=>[y[1],y[2].trim().toLowerCase()]));
  const espVars=vars(parts.HEAD_B.match(/:root\s*\{([\s\S]+?)\}/)[1]), webVars=vars(css.match(/:root\s*\{([\s\S]+?)\}/)[1]);
  const norm=x=>x?.replace(/^#([a-f0-9])([a-f0-9])([a-f0-9])$/,'#$1$1$2$2$3$3');
  const p=await pageFor(null);
  await run('ESP-01',p,'Comparar valores normalizados do :root do firmware com app.css.',async()=>{
    assert.deepEqual(Object.entries(espVars).filter(([k,v])=>norm(v)!==norm(webVars[k])),[]);
    return Object.keys(espVars).length+' variáveis declaradas no firmware com o mesmo valor.';
  });
  const findings=[];
  for(const [key,title] of [['INDEX','Imprimir'],['QUEUE','Fila TotalFood'],['CONFIG','Configurações'],['TEMPLATE','Modelo da etiqueta'],['UPDATE','Atualizar sistema']]){
    const html=parts.HEAD_A+title+parts.HEAD_B+parts['PAGE_'+key+'_A']+parts.COMMON_JS+parts['PAGE_'+key+'_B'];
    const file=out+'/esp-'+key.toLowerCase()+'.html';
    fs.writeFileSync(file,html);
    for(const width of [390,1366]){
      await p.setViewportSize({width,height:width===390?844:900});
      await p.goto('file://'+process.cwd()+'/'+file);
      const checks=await p.evaluate(()=>{
        const visible=e=>e.getClientRects().length&&getComputedStyle(e).visibility==='visible';
        return [...document.body.querySelectorAll('*')].filter(visible).flatMap(e=>{
          const s=getComputedStyle(e), issues=[];
          const own=[...e.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
          if(s.boxShadow!=='none')issues.push('sombra');
          if(s.borderRadius.split(' ').some(x=>parseFloat(x)>4))issues.push('raio '+s.borderRadius);
          if(s.color==='rgb(128, 187, 4)'||(own&&s.backgroundColor==='rgb(128, 187, 4)'&&s.color!=='rgb(0, 0, 0)'))issues.push('verde');
          if(own&&parseFloat(s.fontSize)<14)issues.push('texto '+s.fontSize);
          if((e.classList.contains('panel')||e.classList.contains('operation-feedback'))&&s.backgroundColor!=='rgba(0, 0, 0, 0)')issues.push('moldura/aviso fundo '+s.backgroundColor);
          return issues.length?[{tag:e.tagName,cls:e.className,text:own.slice(0,75),issues}]:[];
        });
      });
      await p.screenshot({path:out+'/capturas/esp-'+key.toLowerCase()+'-'+width+'.png'});
      findings.push({page:key,width,checks});
    }
  }
  save('esp-layout',findings);
  await run('ESP-02',p,'Abrir cinco páginas montadas no Chrome nas duas larguras, inspecionar LAY-02–07.',async()=>{
    assert.deepEqual(findings.filter(x=>x.checks.length),[]);
    return '10 capturas; sem achados nos elementos visíveis da montagem estática.';
  });
  await run('ESP-03',p,'Verificar FW_VERSION e o artefato do workflow firmware-ci no SHA testado.',async()=>{
    const ino=fs.readFileSync('firmware/etiqueta_zd220/etiqueta_zd220.ino','utf8');
    const ci=fs.readFileSync('.github/workflows/firmware-ci.yml','utf8');
    assert.match(ino,/#define FW_VERSION\s+"1\.7\.0"/);
    assert.match(ci,/FW_VERSION/);assert.match(ci,/upload-artifact/);
    let runs;
    try{runs=JSON.parse(execFileSync('gh',['run','list','-R','davi-f-ribeiro/totalfood-estoque','-w','firmware-ci.yml','-c',execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),'--json','databaseId,status,conclusion,url'],{encoding:'utf8',timeout:20000,stdio:['ignore','pipe','ignore']}))}catch{skip('FW_VERSION é 1.7.0 e workflow extrai a versão. Execução de firmware-ci e artefato no SHA não puderam ser comprovados.')}
    save('esp-workflow',runs);
    const pass=runs.find(x=>x.conclusion==='success');
    if(!pass)skip('FW_VERSION 1.7.0 e receita de artefato confirmados; CI bem-sucedido no SHA não encontrado.');
    return 'FW_VERSION 1.7.0, workflow verde '+pass.url;
  });
  await run('ESP-04',p,'Executar os testes Python de firmware.',async()=>{
    const output=execFileSync('python3',['-m','unittest','discover','-s','firmware/tests','-p','test_*.py','-v'],{stdio:['ignore','pipe','pipe'],encoding:'utf8'});
    return 'Saída 0 (14 testes registrados no firmware.log).';
  });
});
