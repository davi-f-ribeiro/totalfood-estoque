const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,base,out,op,stamp,pageFor,open,get,post,good,number,rows,main,save}=require('./real-common.cjs');
const run=rows('real-print-retry');
main(async()=>{
 const d=await pageFor('d'),e=await pageFor('e',390);
 e.on('dialog',x=>x.accept());
 await open(e,'/crates');
 const {a,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const token=good(await post(d,'/api/print/devices',{name:'Fila Lab '+stamp})).token;
 const report=[];
 function curl(url,payload){
   const res=execFileSync('curl',['-sS','-X','POST','-w','\n%{http_code}','-H','Authorization: Bearer '+token,'-H','Content-Type: application/json','--data-binary',JSON.stringify(payload),base+url],{encoding:'utf8'});
   const i=res.lastIndexOf('\n');
   return {status:+res.slice(i+1),body:JSON.parse(res.slice(0,i))};
 }
 const list=async()=> (await get(e,'/api/print/jobs')).jobs;
 const receipts=[];
 await run('CX-11',e,'Simular fail e uncertain da impressora e comparar as duas mensagens com Caixas.',async()=>{
   for(const action of ['fail','uncertain']){
     const j=good(curl('/api/print/jobs/claim',{}));
     const outcome=good(curl('/api/print/jobs/'+j.id+'/'+action,{claim_token:j.claim_token,error:'Simulação '+action+' da impressora'}));
     const visible=(await list()).find(x=>j.id===x.id);
     assert.equal(outcome.status,action==='fail'?'FAILED':'UNCERTAIN');
     assert.equal(visible.status,outcome.status);
     receipts.push({id:j.id,status:outcome.status,visible});
   }
   await e.locator('#crateQueueRefresh').click();
   const queue=e.locator('#cratePrintJobs');
   await queue.getByText(/Confirmação incerta/i).first().waitFor();
   const msg=await queue.innerText();
   const sql=execFileSync('docker',['compose','exec','-T','db','psql','-U','estoque','-d','estoque','-At','-c','SELECT id,status,last_error FROM print_jobs WHERE id IN ('+receipts.map(x=>x.id).join(',')+') ORDER BY id'],{encoding:'utf8'});
   save('print-state-diagnostics',{results:receipts,sql,message:msg});
   await e.screenshot({path:out+'/capturas/CX-11-fila.png'});
   assert.match(msg,/Simulação (?:fail|uncertain) da impressora/,'FAILED e UNCERTAIN confirmados. A UI descarta os motivos que estão em print_jobs.last_error.');
   return 'Estados e motivos na tela.';
 });
 await run('CX-05',e,'Confirmar no banco e na fila a etiqueta cancelada ao zerar CX-000002.',async()=>{
   const old=JSON.parse(fs.readFileSync(out+'/crate-fixture.json')), cid=old.ids[1];
   const db=execFileSync('docker',['compose','exec','-T','db','psql','-U','estoque','-d','estoque','-At','-c','SELECT status,last_error FROM print_jobs WHERE crate_id='+cid+' ORDER BY revision DESC LIMIT 1'],{encoding:'utf8'}).trim();
   const job=(await list()).find(x=>x.crate_id===cid);
   const crate=await get(e,'/api/crates/'+cid);
   const queue=await e.locator('#cratePrintJobs').innerText();
   assert.equal(crate.status,'EMPTY');assert.equal(job.status,'CANCELLED');assert.match(db,/Caixa vazia/i);
   save('print-empty-diagnostics',{job,db,crate,queue});
   assert.match(queue,/Caixa vazia/i,'Banco: '+db+'. A fila apresenta Substituída e não exibe o motivo Caixa vazia.');
   return 'Caixa vazia e causa exibida.';
 });
 await run('CX-10',e,'Retestar a oferta de reenvio na tela após validar expiração de 5 minutos.',async()=>{
   const prior=JSON.parse(fs.readFileSync(out+'/real-crates.json')).find(x=>x.id==='CX-10');
   assert.equal(prior.estado,'passou');
   await e.locator('#crateQueueRefresh').click();
   const row=e.locator('#cratePrintJobs .crate-job').filter({hasText:'Confirmação incerta'}).first();
   const btn=row.getByRole('button',{name:'Reenviar'});
   const reply=e.waitForResponse(r=>r.url().endsWith('/retry')&&r.request().method()==='POST');
   await btn.click();
   assert.equal((await reply).status(),200);
   return prior.obs+' Reenvio por botão confirmado HTTP 200.';
 });
});
