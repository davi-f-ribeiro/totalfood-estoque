const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,out,op,stamp,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-replay');
main(async()=>{
 const {a,b,brand,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'),e=await pageFor('e'),k=await pageFor('c'),g=await pageFor('g');
 const data=[];
 const json=x=>JSON.stringify(x);
 async function replay(label,who,path,payload,changed){
   const first=await post(who,path,payload);
   if(first.status>=300){data.push({label,stage:'setup',first});save('replay-detail',data);return null}
   const same=await post(who,path,payload);
   const diff=await post(who,path,{...payload,...changed});
   const references=['id','movement_id','movement_ids','warehouse_id','lot_id','revision'];
   const keys=references.filter(x=>first.body?.[x]!==undefined&&same.body?.[x]!==undefined);
   const preserved=keys.every(x=>json(first.body[x])===json(same.body[x]));
   const result={label,path,first,same,diff,preserved,ok: same.status<300&&preserved&&diff.status>=400&&diff.status<500};
   data.push(result);
   save('replay-detail',data);
   return first.body;
 }
 const wh=good(await post(d,'/api/admin/warehouses',{name:'Replay Lab '+stamp})).id;
 good(await post(d,'/api/admin/warehouses/'+wh+'/activate',{}));
 const category=(await get(d,'/api/catalog/options')).categories[0].id;
 const catalog='/api/catalog';
 const item=await replay('Criação de item',d,catalog+'/items',{...op(),name:'Replay item '+stamp,category_id:category,unit_code:'UN',minimum_stock:'0',active:true},{name:'Replay item alterado '+stamp});
 const br=await replay('Criação de marca',d,catalog+'/brands',{...op(),name:'Replay marca '+stamp,active:true},{name:'Replay marca editada '+stamp});
 const sku=await replay('Criação de SKU',d,catalog+'/skus',{...op(),item_id:item.id,brand_id:br.id,name:'Replay SKU',barcode:'739'+stamp+'7',content_quantity:'1',active:true},{barcode:'739'+stamp+'8'});
 const movement=(kind,body,change)=>replay('Movimentação '+kind,e,'/api/movements/'+kind,body,change);
 const line=q=>({sku_id:sku.id,quantity:String(q),unit_cost:'2.25'});
 for(const type of ['entry','exit','transfer']){
   const p={...op(),sku_id:sku.id,warehouse_id:wh,warehouse_from_id:wh,warehouse_to_id:b,quantity:type==='entry'?'20':'1',unit_cost:'2.25'};
   await movement(type,p,{quantity:'2'});
   const q={...op(),warehouse_id:wh,warehouse_from_id:wh,warehouse_to_id:b,document_number:'LAB-IDEMPOTENCIA',lines:[line(type==='entry'?20:1)]};
   await movement(type+'/batch',q,{lines:[line(2)]});
 }
 const xs={...op(),sku_id:p.crate.sku,warehouse_id:wh,unit_cost:'4',document_number:'LAB-REPLAY-CX',weights:['8','9','10']};
 const receipt=await replay('Recebimento de caixas',e,'/api/crates/receive',xs,{weights:['8','9','11']});
 if(receipt?.crates?.length){
   const [weigh,transfer]=receipt.crates;
   await replay('Pesagem',e,'/api/crates/'+weigh.id+'/weigh',{...op(),weight:'7'},{weight:'6'});
   await replay('Transferência de caixa',e,'/api/crates/'+transfer.id+'/transfer',{...op(),to_warehouse_id:a},{to_warehouse_id:b});
 }
 const root='/api/material-requests', day='2026-11-16';
 const req=await replay('Criação de requisição',k,root,{...op(),unit_name:'Replay cozinha '+stamp,delivery_date:day,production_date:day,service:'almoco',lines:[{item_id:item.id,quantity:'10'}]},{notes:'corpo alterado'});
 if(req?.id){
   const base=root+'/'+req.id, detail=await get(k,base);
   const rid=await replay('Separação',e,base+'/reserve',{...op(),line_id:detail.lines[0].id,sku_id:sku.id,warehouse_id:wh,quantity:'8'},{quantity:'7'});
   const delivered=rid&&await replay('Entrega',e,base+'/deliver',{...op(),reservation_id:rid.id,quantity:'8'},{quantity:'7'});
   if(delivered){
     const link=base+'/deliveries/'+delivered.id;
     await replay('Conferência',k,link+'/receive',{...op(),received_quantity:'6',reason:'Recebimento parcial'},{received_quantity:'5'});
     await replay('Conciliação',k,link+'/reconcile',{...op(),quantity:'1',notes:'Recebimento restante'},{notes:'corpo divergente'});
     await replay('Encerramento',k,base+'/close',{...op(),notes:'Diferença aceita'},{notes:'corpo diferente depois de fechar'});
   }
 }
 const v=await replay('Contagem total',d,'/api/inventory-validations/total',{...op(),warehouse_id:wh},{warehouse_id:a});
 if(v){
   await open(g,'/inventory');
   await run('INV-08',d,'Diretor e Gerente tentam salvar a mesma versão de linha da mesma contagem.',async()=>{
     const link='/api/inventory-validations/'+v.id+'/counting';
     const dg=await get(d,link), gg=await get(g,link);
     const di=dg.lines.find(x=>x.sku_id===sku.id),gi=gg.lines.find(x=>x.sku_id===sku.id);
     assert.equal(di.version,gi.version);
     const path='/api/inventory-validations/'+v.id+'/lines/'+sku.id+'/count';
     good(await api(d,'PUT',path,{physical_quantity:'20',expected_version:di.version}));
     const second=await api(g,'PUT',path,{physical_quantity:'21',expected_version:gi.version});
     return second.status+' '+json(bad(second,/Outra pessoa alterou/i,409));
   });
   good(await post(d,'/api/inventory-validations/'+v.id+'/cancel',{cancellation_reason:'Fim da simulação de replay'}));
 }
 const bin={...op()};
 const blind1=await post(d,'/api/inventory-validations/blind',bin);
 const blind2=await post(d,'/api/inventory-validations/blind',bin);
 data.push({label:'Contagem cega',first:blind1,same:blind2,ok:blind1.status<300&&blind2.status<300&&blind1.body.id===blind2.body.id});
 if(blind1.status<300) good(await post(d,'/api/inventory-validations/'+blind1.body.id+'/cancel',{cancellation_reason:'Fim da simulação de replay cego'}));
 save('replay-detail',data);
 await run('TRV-01',d,'Reenviar payload idêntico e alterado para as rotas registradas, com sessão real.',async()=>{
   const failures=data.filter(r=>!r.ok).map(x=>x.label+' ('+x.first?.status+'/'+x.same?.status+'/'+x.diff?.status+')');
   assert.deepEqual(failures,[],'Rotas com replay divergente ou aceite indevido: '+failures.join(', '));
   return data.length+' rotas conferidas. Ajuste verificado por INV-14; importação de NF excluída.';
 });
 await run('INV-16',d,'Criar SKU isolado com único custo zero, zerar saldo depois de contar sobra e aplicar ajuste.',async()=>{
   const zeroItem=good(await post(d,catalog+'/items',{...op(),name:'Custo zero isolado '+stamp,category_id:category,unit_code:'UN',minimum_stock:'0',active:true}));
   const zeroSku=good(await post(d,catalog+'/skus',{...op(),item_id:zeroItem.id,brand_id:br.id,name:'SKU exclusivo de custo zero',barcode:'739'+stamp+'9',content_quantity:'1',active:true}));
   const zid=good(await post(d,'/api/admin/warehouses',{name:'Custo zero isolado '+stamp})).id;
   good(await post(d,'/api/admin/warehouses/'+zid+'/activate',{}));
   const move=(type,cost)=>post(d,'/api/movements/'+type+'/batch',{...op(),warehouse_id:zid,lines:[{sku_id:zeroSku.id,quantity:'10',unit_cost:cost}]});
   good(await move('entry','0'));
   const base='/api/inventory-validations/'+good(await post(d,'/api/inventory-validations/total',{...op(),warehouse_id:zid})).id;
   const cv=(await get(d,base+'/counting')).lines[0];
   good(await api(d,'PUT',base+'/lines/'+zeroSku.id+'/count',{physical_quantity:'12',expected_version:cv.version}));
   const rv=(await get(d,base+'/review')).lines[0];
   good(await api(d,'PUT',base+'/lines/'+zeroSku.id+'/recount',{physical_quantity:'12',expected_version:rv.version}));
   good(await post(d,base+'/complete',{completion_note:'Sobra sem custo para cenário de auditoria'}));
   good(await move('exit',''));
   const r=await post(d,base+'/lines/'+zeroSku.id+'/adjust',op());
   return r.status+' '+json(bad(r,/Não há custo válido/i));
 });
});
