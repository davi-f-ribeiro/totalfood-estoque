const fs=require('node:fs');
const {assert,base,out,pageFor,open,rows,main,save}=require('./real-common.cjs');
const run=rows('real-full-axe');
main(async()=>{
 const src=fs.readFileSync('/tmp/tf-axe/node_modules/axe-core/axe.min.js','utf8');
 const checks=[];
 const routes=['/login','/home','/stock','/entry','/exit','/transfer','/crates','/material-requests','/catalog','/products','/inventory','/reports','/admin'];
 for(const width of [390,1366]){
   const d=await pageFor('d',width), guest=await pageFor(null,width);
   for(const path of routes){
     const page=path==='/login'?guest:d;
     await open(page,path);
     await page.waitForLoadState('networkidle');
     await page.evaluate(src);
     const r=await page.evaluate(async()=>{
       const out=await window.axe.run({runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa']}});
       return {violations:out.violations.map(v=>({id:v.id,impact:v.impact,description:v.description,nodes:v.nodes.map(x=>({target:x.target,summary:x.failureSummary}))})), contrastNeedsReview:out.incomplete.filter(x=>x.id==='color-contrast').map(x=>x.nodes.map(n=>n.target))};
     });
     checks.push({path,width,...r});
     if(r.violations.length)await page.screenshot({path:out+'/capturas/axe-'+width+'-'+path.slice(1)+'.png'});
     save('axe-full',checks);
   }
 }
 const d=await pageFor('d');
 await run('LAY-09',d,'Executar axe-core nas 26 aberturas com WCAG 2.0/2.1 A e AA, incluindo contraste.',async()=>{
   assert.equal(checks.length,26);
   const failures=checks.flatMap(r=>r.violations.filter(x=>x.id==='color-contrast').map(x=>({path:r.path,width:r.width,violations:x.nodes.length})));
   assert.deepEqual(failures,[]);
   const other={};
   for(const x of checks)for(const v of x.violations)other[v.id]=(other[v.id]||0)+v.nodes.length;
   save('axe-summary',other);
   return 'Nenhuma violação automática de color-contrast. Regras adicionais em axe-full.json, incluindo '+(Object.keys(other).join(', ')||'nenhuma violação')+'.';
 });
 const matrix=[];
 for(const who of ['d','g','e','c']){
   const p=await pageFor(who,390);
   for(const path of [...routes.slice(1),'/fiscal']){
     const r=await open(p,path);
     if(!p.url().endsWith(path)){matrix.push({who,path,url:p.url(),status:r.status(),menu:false});continue}
     const links=p.locator('nav a[href="'+path+'"], [role=navigation] a[href="'+path+'"]');
     matrix.push({who,path,url:p.url(),status:r.status(),menu:await links.count()>0});
   }
   await p.close();
 }
 save('permissions-390-configured',matrix);
});
