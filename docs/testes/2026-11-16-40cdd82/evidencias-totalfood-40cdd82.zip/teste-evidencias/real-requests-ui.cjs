const fs=require('node:fs');
const {assert,base,out,op,stamp,pageFor,open,get,post,good,number,rows,main,save}=require('./real-common.cjs');
const run=rows('real-requests-ui');
main(async()=>{
 const {a,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const e=await pageFor('e',390), c=await pageFor('c',390), d=await pageFor('d');
 for(const p of [e,c])p.on('dialog',x=>x.accept());
 const route='/api/material-requests', date='2026-11-16';
 const view=(page,id)=>get(page,route+'/'+id);
 const label='Fluxo mobile Lab '+stamp;
 async function openReq(page,id){
   await open(page,'/material-requests');
   await page.locator('#materialList button').filter({hasText:new RegExp('^#'+id+' ·')}).first().click();
   await page.locator('#materialDetailContent').locator('.material-facts').waitFor();
 }
 const stock=async()=> (await get(d,'/api/stock?warehouse_id='+a)).find(x=>x.item_id===p.crate.item);
 const historyJSON=out+'/req-end.json';
 const old=JSON.parse(fs.readFileSync(historyJSON));
 await run('REQ-05',e,'Abrir a primeira requisição e ler o bloco da entrega de 6 kg.',async()=>{
   const id=old.current[0];
   await openReq(e,id);
   const delivery=e.locator('#materialDetailContent .material-delivery').first();
   const text=await delivery.locator('strong').innerText();
   assert.match(text,new RegExp(p.kg.name+', 6 KG','i'));
   assert.match(await delivery.innerText(),/VR/);
   await e.screenshot({path:out+'/capturas/REQ-05-entrega.png'});
   return text+'; '+(await delivery.locator('p').first().innerText());
 });
 await run('REQ-01',c,'Criar requisição na tela da Cozinha com Pote e Arroz.',async()=>{
   await open(c,'/material-requests');
   await c.locator('#materialUnit').fill(label+' dois materiais');
   for(const product of [p.kg,p.un]){
     await c.locator('#materialSearch').fill(product.name);
     await c.locator('#materialMatches button').filter({hasText:product.name}).first().click();
   }
   const quantities=c.locator('#materialDraft input');
   for(let i=0;i<await quantities.count();i++)await quantities.nth(i).fill('2');
   const response=c.waitForResponse(r=>r.url().endsWith(route)&&r.request().method()==='POST');
   await c.locator('#materialCreateSubmit').click();
   const r=await response,data=await r.json();
   save('req-ui-create-http',{status:r.status(),body:data});
   assert.equal(r.status(),201,JSON.stringify(data));
   const req=await view(c,data.id);
   assert.equal(req.status,'PENDENTE');assert.equal(req.lines.length,2);
   return '#'+req.id+' com dois materiais, HTTP 201 e PENDENTE.';
 });
 const received=good(await post(e,'/api/crates/receive',{...op(),sku_id:p.crate.sku,warehouse_id:a,unit_cost:'5.20',document_number:'LAB-DIA-CAIXAS',weights:['19.3','18.9','22','21.8','20.9','8.9']}));
 const request=good(await post(c,route,{...op(),unit_name:label,delivery_date:date,production_date:date,service:'almoco',lines:[{item_id:p.crate.item,quantity:'106'}]}));
 const id=request.id;
 const line=(await view(c,id)).lines[0];
 const baseline=await stock();
 await openReq(e,id);
 let res;
 await run('REQ-02',e,'Separar 102,9 kg na tela móvel do Estoquista, selecionando o depósito VR.',async()=>{
   const lineBox=e.locator('[data-note-key="line:'+line.id+'"]');
   await lineBox.getByRole('button',{name:'Separar material'}).click();
   await lineBox.locator('select').selectOption(p.crate.sku+':'+a);
   await lineBox.locator('input').fill('102,9');
   const response=e.waitForResponse(r=>r.url().endsWith(route+'/'+id+'/reserve')&&r.request().method()==='POST');
   await lineBox.getByRole('button',{name:'Confirmar separação'}).click();
   const r=await response,data=await r.json();
   save('req-ui-reserve-http',{status:r.status(),body:data});
   assert.equal(r.status(),201,JSON.stringify(data));
   res=data.id;
   const note=lineBox.locator('[data-detail-note]');
   await note.waitFor();
   assert.match(await note.innerText(),/102,9 KG.*separados/i);
   return '#'+id+', reserva '+res+', aviso na linha.';
 });
 if(!res){
   res=good(await post(e,route+'/'+id+'/reserve',{...op(),line_id:line.id,sku_id:p.crate.sku,warehouse_id:a,quantity:'102.9'})).id;
   await openReq(e,id);
 }
 const card=e.locator('[data-note-key="res:'+res+'"]');
 const ids=received.crates.slice(0,5).map(x=>x.id);
 await card.locator('input[type=checkbox]').first().waitFor();
 await run('REQ-27',e,'Clicar Confirmar entrega sem selecionar caixa.',async()=>{
   const before=await view(c,id);
   await card.getByRole('button',{name:'Confirmar entrega'}).click();
   const note=card.locator('[data-detail-note]');
   await note.waitFor();
   assert.match(await note.innerText(),/controlado por caixas/i);
   assert.equal(await note.getByRole('button',{name:'Enviar de novo'}).count(),0);
   assert.deepEqual(await view(c,id),before);
   await e.screenshot({path:out+'/capturas/REQ-27-390.png'});
   return await note.innerText();
 });
 await run('REQ-28',e,'Selecionar as cinco caixas do lote de teste por seus identificadores.',async()=>{
   for(const cid of ids)await card.locator('input[type=checkbox][value="'+cid+'"]').check();
   const input=card.locator('input:not([type=checkbox])');
   assert.equal(await input.inputValue(),'102.9');
   assert.equal(await input.evaluate(el=>el.readOnly),true);
   return 'Quantidade 102,9, somente leitura.';
 });
 let delivery;
 await run('REQ-29',e,'Confirmar a entrega das cinco caixas pela tela e conferir a linha de saída.',async()=>{
   const rr=e.waitForResponse(r=>r.url().endsWith(route+'/'+id+'/deliver')&&r.request().method()==='POST');
   await card.getByRole('button',{name:'Confirmar entrega'}).click();
   const r=await rr, data=await r.json();
   save('req-ui-delivery-http',{status:r.status(),body:data});
   assert.equal(r.status(),201,JSON.stringify(data));
   delivery=data;
   const d=e.locator('[data-note-key="delivery:'+data.id+'"]');
   await d.waitFor();
   const txt=await d.innerText();
   for(const box of received.crates.slice(0,5))assert.match(txt,new RegExp(box.code));
   const req=await view(c,id);assert.equal(req.deliveries.length,1);assert.equal(req.deliveries[0].crates.length,5);
   const active=await get(e,'/api/crates?warehouse_id='+a);
   assert.ok(!active.some(b=>ids.includes(b.id)));
   assert.equal(Math.round((number(baseline.quantity)-number((await stock()).quantity))*10),1029);
   return 'Uma entrega, movimento '+data.movement_id+', 5 caixas zeradas e listadas no detalhe.';
 });
 if(!delivery)throw Error('Recebimento móvel depende da entrega anterior.');
 await run('REQ-36',c,'No celular 390 px, abrir a entrega feita pelo Estoquista e informar 101 kg e motivo.',async()=>{
   await openReq(c,id);
   const box=c.locator('[data-note-key="delivery:'+delivery.id+'"]');
   const q=box.locator('input').first(), why=box.locator('input').nth(1);
   await q.fill('101');await why.fill('Diferença aceita no laboratório');
   const rr=c.waitForResponse(r=>r.url().endsWith('/deliveries/'+delivery.id+'/receive'));
   await box.getByRole('button',{name:'Confirmar recebimento',exact:true}).click();
   const r=await rr,data=await r.json();save('req-ui-receive-http',{status:r.status(),body:data});
   assert.equal(r.status(),200,JSON.stringify(data));
   await box.getByText(/Faltam 1,9 KG para receber/i).waitFor();
   assert.equal(await e.evaluate(()=>document.documentElement.scrollWidth),390);
   assert.equal(await c.evaluate(()=>document.documentElement.scrollWidth),390);
   await e.screenshot({path:out+'/capturas/REQ-36-estoquista-390.png'});
   await c.screenshot({path:out+'/capturas/REQ-36-cozinha-390.png'});
   return 'Entrega e recebimento parcial a 390 px, sem rolagem lateral; ficaram 1,9 kg pendentes.';
 });
 await run('REQ-22',c,'Novo pedido de 106 kg, entrega de 104,3 kg e conferência integral; abrir opção Aceitar e encerrar.',async()=>{
   const newId=good(await post(c,route,{...op(),unit_name:label+' diferença do pedido',delivery_date:date,production_date:date,service:'almoco',lines:[{item_id:p.kg.item,quantity:'106'}]})).id;
   const l=(await view(c,newId)).lines[0];
   const r=good(await post(e,route+'/'+newId+'/reserve',{...op(),line_id:l.id,sku_id:p.kg.sku,warehouse_id:a,quantity:'106'})).id;
   const dl=good(await post(e,route+'/'+newId+'/deliver',{...op(),reservation_id:r,quantity:'104.3'})).id;
   good(await post(c,route+'/'+newId+'/deliveries/'+dl+'/receive',{...op(),received_quantity:'104.3'}));
   const req=await view(c,newId);assert.equal(req.status,'ENTREGA_PARCIAL');
   await openReq(c,newId);
   await c.getByRole('button',{name:'Aceitar e encerrar',exact:true}).waitFor();
   return 'ENTREGA_PARCIAL e botão visível para quem solicitou.';
 });
 let closed;
 await run('REQ-25',c,'Aceitar diferença da requisição de caixas e registrar observação na UI móvel.',async()=>{
   await openReq(c,id);
   const header=c.locator('[data-note-key=request]');
   await header.locator('input').fill('Diferença conferida no local');
   const rr=c.waitForResponse(r=>r.url().endsWith(route+'/'+id+'/close'));
   await header.getByRole('button',{name:'Aceitar e encerrar',exact:true}).click();
   const r=await rr, response=await r.json();
   assert.equal(r.status(),200,JSON.stringify(response));
   closed=await view(c,id);
   assert.equal(closed.status,'RECEBIDA');assert.ok(closed.events.some(x=>x.action==='ENCERRADA'));
   assert.ok(closed.reservations.every(x=>number(x.remaining)===0));
   return 'Pedido RECEBIDA com ENCERRADA no histórico, reserva liberada.';
 });
 const returned=good(await post(e,'/api/crates/'+received.crates[5].id+'/weigh',{...op(),weight:'8.1',notes:'Retorno final do fluxo de um dia'}));
 save('scenario-day',{id,delivery,afterReceiving:await stock(),received,returned,closed:closed?.status});
});
