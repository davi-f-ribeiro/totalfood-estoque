# Evidências — TotalFood Estoque

O relatório usa links relativos. Extraia o ZIP e abra `relatorio-teste-totalfood.md`.

- `real-*.cjs` reúne os roteiros Playwright com API real. `real-common.cjs` é o utilitário compartilhado. Defina `NODE_PATH`, `CHROME_BIN`, `TF_TEST_BOOTSTRAP`, `TF_TEST_PASSWORD` e `TF_TEST_TEMP` no ambiente do laboratório. Use somente `http://127.0.0.1:5656`. Os roteiros escrevem dados de teste.
- `real-access.cjs` cria as quatro contas pela Administração. Os registros `profiles-before.txt`, `permissions-matrix.json`, `real-mov-catalog.log` e os logs de baseline preservam o acesso antes das concessões. A fixture do catálogo, com marca fictícia para o Melão, está em `fixture.json`.
- Após desligar o bootstrap e registrar a matriz inicial, `real-admin.cjs` aplica as permissões usadas no restante da rodada. Execute `real-mov-retry.cjs` antes dos roteiros que consomem o estoque. Use `real-inventory-retry.cjs` para o percurso com recontagem de todas as divergências. `real-validation-final.cjs` monta a fixture legada de SKU sem marca para REL-02.
- `http.jsonl`, `print-http.jsonl`, `browser-errors.jsonl` e `app.log` registram rede e servidor. `real-*.json` registra os casos. O relatório dá o resultado consolidado quando houve repetição para corrigir a fixture ou o seletor de um roteiro.
- `repeats-db-early.log` conserva o timeout padrão. O resultado da repetição com prazo maior está em `repeats-db-35m.log`.
- `capturas/` contém as evidências em 390×844 e 1366×900, inclusive a fila, a tela restaurada após sair, o ajuste de caixa e telas preenchidas. `esp-*.html` são páginas montadas do firmware.
