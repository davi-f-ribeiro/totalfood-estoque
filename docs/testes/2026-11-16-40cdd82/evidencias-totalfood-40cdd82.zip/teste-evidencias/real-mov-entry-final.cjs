const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-mov-entry-final');
main(async()=>{
 const {a,b,brandName,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'), e=await pageFor('e',390), desktop=await pageFor('e');
 const stock=async(product,w=a)=>number((await get(d,'/api/stock?warehouse_id='+w)).find(r=>r.item_id===product.item)?.quantity||0);
 const rStatus=(page,id)=>page.locator(id).innerText();
 const inViewport=(page,sel)=>page.locator(sel).first().evaluate(e=>{const r=e.getBoundingClientRect();return r.top>=-1&&r.bottom<=innerHeight+1});
 const addBatch=async(page,product)=>{
   await page.locator('#batchSearch').fill(product.barcode);
   await page.locator('#batchSearch').press('Enter');
   await page.locator('#batchTable').getByText(product.name,{exact:false}).first().waitFor();
 };
 await run('MOV-01',desktop,'Entrada desktop pela interface de lote, duas linhas com preço e documento.',async()=>{
   const before=[await stock(p.kg),await stock(p.un)];
   await open(desktop,'/entry');
   await desktop.locator('#batchWarehouse').selectOption(String(a));
   for(const x of [p.kg,p.un])await addBatch(desktop,x);
   const batch=desktop.locator('#batchTable');
   for(const [i,q,cost] of [[0,'5','4,20'],[1,'6','2,50']]){
     await batch.locator('.batch-qty').nth(i).fill(q);
     await batch.locator('input').filter({visible:true}).count();
     const inputs=batch.getByRole('textbox',{name:/Preço da embalagem/});
     await inputs.nth(i).fill(cost);
   }
   await desktop.locator('#batchDocument').fill('LAB-ENTRADA-UI');
   const response=desktop.waitForResponse(r=>r.url().endsWith('/api/movements/entry/batch')&&r.request().method()==='POST');
   await desktop.locator('#batchSubmit').click();
   const r=await response,data=await r.json();
   save('entry-form-http',{status:r.status(),data});
   assert.equal(r.status(),200,JSON.stringify(data));
   await desktop.locator('#batchStatus').waitFor();
   assert.deepEqual([await stock(p.kg),await stock(p.un)],[before[0]+5,before[1]+6]);
   return 'Duas linhas persistidas, '+await rStatus(desktop,'#batchStatus')+' Feedback no viewport: '+await inViewport(desktop,'#batchStatus')+'.';
 });
});
