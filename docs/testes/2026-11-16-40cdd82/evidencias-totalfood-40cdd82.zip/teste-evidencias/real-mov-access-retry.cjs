const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,number,rows,main,save,skip}=require('./real-common.cjs');
const run=rows('real-mov-access-retry');
main(async()=>{
 const {a,b,brandName,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'), e=await pageFor('e',390), desktop=await pageFor('e');
 const stock=async(product,w=a)=>number((await get(d,'/api/stock?warehouse_id='+w)).find(r=>r.item_id===product.item)?.quantity||0);
 const rStatus=(page,id)=>page.locator(id).innerText();
 const inViewport=(page,sel)=>page.locator(sel).first().evaluate(e=>{const r=e.getBoundingClientRect();return r.top>=-1&&r.bottom<=innerHeight+1});
 const addBatch=async(page,product)=>{
   await page.locator('#batchSearch').fill(product.name);
   await page.locator('#batchLookup button').filter({hasText:product.name}).first().click();
 };
 await run('MOV-01',desktop,'Entrada desktop pela interface de lote, duas linhas com preço e documento.',async()=>{
   const before=[await stock(p.kg),await stock(p.un)];
   await open(desktop,'/entry');
   await desktop.locator('#batchWarehouse').selectOption(String(a));
   for(const x of [p.kg,p.un])await addBatch(desktop,x);
   const batch=desktop.locator('#batchTable');
   for(const [i,q,cost] of [[0,'5','4,20'],[1,'6','2,50']]){
     await batch.locator('.batch-qty').nth(i).fill(q);
     await batch.locator('input').filter({visible:true}).count();
     const inputs=batch.getByRole('textbox',{name:/Preço da embalagem/});
     await inputs.nth(i).fill(cost);
   }
   await desktop.locator('#batchDocument').fill('LAB-ENTRADA-UI');
   const response=desktop.waitForResponse(r=>r.url().endsWith('/api/movements/entry/batch')&&r.request().method()==='POST');
   await desktop.locator('#batchSubmit').click();
   const r=await response,data=await r.json();
   save('entry-form-http',{status:r.status(),data});
   assert.equal(r.status(),200,JSON.stringify(data));
   await desktop.locator('#batchStatus').waitFor();
   assert.deepEqual([await stock(p.kg),await stock(p.un)],[before[0]+5,before[1]+6]);
   return 'Duas linhas persistidas, '+await rStatus(desktop,'#batchStatus')+' Feedback no viewport: '+await inViewport(desktop,'#batchStatus')+'.';
 });
 await e.addInitScript(()=>{
   window.testCodes=[];
   Object.defineProperty(navigator.mediaDevices,'getUserMedia',{value:async()=>{
     const canvas=document.createElement('canvas');canvas.width=320;canvas.height=240;
     const context=canvas.getContext('2d');
     let frame=0;setInterval(()=>{context.fillStyle=(frame++%2)?'#fff':'#000';context.fillRect(0,0,320,240)},50);
     return canvas.captureStream(10);
   },configurable:true});
   window.BarcodeDetector=class {
     static async getSupportedFormats(){return ['ean_13','ean_8','code_128','upc_a','upc_e','qr_code']}
     async detect(){const rawValue=window.testCodes.shift();return rawValue?[{rawValue}]:[]}
   };
 });
 await run('MOV-04',e,'Abrir Saída móvel, simular duas leituras de câmera do mesmo EAN e acionar + e −.',async()=>{
   await open(e,'/exit');
   await e.locator('#batchWarehouse').selectOption(String(a));
   for(let i=0;i<2;i++){
     await e.evaluate(code=>window.testCodes.push(code),p.un.barcode);
     await e.locator('#batchScan').click();
     await e.locator('#scanner').waitFor({state:'hidden'});
   }
   const row=e.locator('.batch-row').first(), qty=row.locator('.batch-qty');
   assert.equal(await qty.inputValue(),'2');
   await row.getByRole('button',{name:/Aumentar/i}).click();assert.equal(await qty.inputValue(),'3');
   await row.getByRole('button',{name:/Diminuir/i}).click();assert.equal(await qty.inputValue(),'2');
   assert.ok(await inViewport(e,'#batchSubmit'));
   assert.equal(await e.evaluate(()=>document.documentElement.scrollWidth),390);
   await e.screenshot({path:out+'/capturas/MOV-04-390.png'});
   return 'Simulador de câmera: 1 → 2; controles 2 → 3 → 2; confirmar visível e sem overflow.';
 });
 await run('MOV-08',e,'Persistir saída real no servidor e abortar a resposta antes de chegar à tela; usar Conferir.',async()=>{
   if(await e.locator('.batch-row').count()===0){
     await open(e,'/exit');
     await e.locator('#batchWarehouse').selectOption(String(a));
     await addBatch(e,p.un);
   }
   const amount=number(await e.locator('.batch-qty').first().inputValue());
   const before=await stock(p.un);
   let status,calls=0;
   await e.route('**/api/movements/exit/batch',async route=>{
     calls++;
     const real=await route.fetch({maxRetries:0});status=real.status();
     await route.abort('failed');
   });
   await e.locator('#batchSubmit').click();
   await e.locator('#batchPending').waitFor();
   assert.ok(await e.locator('#batchScan').isDisabled());
   assert.equal(status,200);assert.equal(await stock(p.un),before-amount);
   await e.screenshot({path:out+'/capturas/MOV-08-390.png'});
   await e.locator('#batchCheck').click();
   await e.locator('#batchPending').waitFor({state:'hidden'});
   await e.unroute('**/api/movements/exit/batch');
   assert.equal(calls,1);assert.equal(await stock(p.un),before-amount);
   return 'O servidor salvou antes de perder resposta. Lote travado, Conferir encontrou a operação e o estoque caiu só uma vez.';
 });
 await run('MOV-05',e,'Percorrer três passos de Entrada e Transferência em 390 px.',async()=>{
   for(const route of ['/entry','/transfer']){
     await open(e,route);
     const form=e.locator('#movementForm');
     assert.equal(await e.locator('.movement').getAttribute('data-mode'),'wizard');
     await e.locator('#productSearch').fill(p.un.name);
     await e.locator('#lookup button').filter({hasText:p.un.name}).first().click();
     const first=form.locator('[data-step-next]:visible').first();
     if(await first.count())await first.click();
     await e.locator('#warehouse').selectOption(String(a));
     if(route==='/transfer')await e.locator('#warehouseTo').selectOption(String(b));
     await e.locator('#quantity').fill('1');
     if(route==='/entry')await e.locator('#unitCost').fill('2,50');
     await form.locator('[data-step-next]:visible').first().click();
     assert.equal(await form.getAttribute('data-step'),'3');
     assert.equal(await form.locator('.movement-step.is-current').count(),1);
     assert.equal(await e.evaluate(()=>document.documentElement.scrollWidth),390);
     await e.screenshot({path:out+'/capturas/MOV-05-'+route.slice(1)+'.png'});
   }
   return 'Entrada e Transferência em três passos, um produto e revisão visível.';
 });
 const session=await pageFor('d');
 async function productForm(page,code){
   await open(page,'/products');
   await page.locator('#productNew').click();
   await page.locator('#productParentSearch').fill(p.un.name);
   await page.locator('#productParentLookup button').filter({hasText:p.un.name}).first().click();
   await page.locator('#productBrandSearch').fill(brandName);
   await page.locator('#productBrandLookup button').filter({hasText:brandName}).first().click();
   await page.locator('#productContent').fill('2');
   await page.locator('#productBarcode').fill(code);
 }
 const context=session.context(), second=await context.newPage();
 await run('ACE-05',session,'Preparar produto na aba A; abrir Início na B; voltar à A e salvar.',async()=>{
   await productForm(session,'719'+stamp+'5');
   await open(second,'/home');
   const p=session.waitForResponse(r=>r.url().endsWith('/api/catalog/skus')&&r.request().method()==='POST');
   await session.locator('#productForm button[type=submit]').click();
   const r=await p;
   save('two-tab-create',{status:r.status(),body:await r.json()});
   assert.equal(r.status(),201);
   await session.locator('#productDialog').waitFor({state:'hidden'});
   return 'Produto salvo após abrir outra aba (HTTP 201).';
 });
 await run('ACE-06',session,'Preparar produto em A e sair da conta em B antes de salvar em A.',async()=>{
   await productForm(session,'719'+stamp+'6');
   await open(second,'/home');
   await second.locator('#logout').evaluate(el=>el.click());
   await second.waitForURL('**/login');
   const submit=session.waitForResponse(r=>r.url().endsWith('/api/catalog/skus')&&r.request().method()==='POST');
   await session.locator('#productForm button[type=submit]').click();
   const r=await submit;
   save('two-tab-logged-out',{status:r.status(),body:await r.json()});
   await session.locator('#productFormStatus').waitFor();
   const text=await session.locator('#productFormStatus').innerText();
   assert.match(text,/entre|login|sessão/i);assert.doesNotMatch(text,/permissão/i);
   return r.status()+' '+text;
 });
 await run('ACE-07',second,'Voltar com o histórico após sair em outra aba.',async()=>{
   await second.goBack();await second.waitForURL('**/login');
   assert.equal(await second.locator('nav').count(),0);
   return 'Histórico devolveu a tela de login.';
 });
 await run('ACE-09',d,'Criar usuário descartável, alterar a senha pela conta e tentar entrar com as duas senhas.',async()=>{
   await open(d,'/admin');
   const profile=(await get(d,'/api/admin/profile-options')).find(x=>x.name==='Cozinha');
   const name='t-senha-'+stamp;
   const old=process.env.TF_TEST_TEMP, next=old+'Troca';
   good(await post(d,'/api/admin/users',{login:name,password:old,profile_id:profile.id,active:true}));
   async function enter(page,pw){
     await open(page,'/login');await page.locator('[name=login]').fill(name);
     await page.locator('[name=password]').fill(pw);await page.locator('form button').click();
   }
   const member=await pageFor(null);
   await enter(member,old);
   await member.locator('#changePasswordOpen').evaluate(button=>button.click());
   const change=member.locator('#changePasswordForm');
   for(const [i,value] of [old,next,next].entries())await change.locator('input').nth(i).evaluate((e,v)=>{e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))},value);
   const response=member.waitForResponse(r=>r.url().endsWith('/api/me/password'));
   await change.locator('button').evaluate(button=>button.click());
   assert.equal((await response).status(),200);
   const fresh=await pageFor(null);
   await enter(fresh,old);assert.ok(fresh.url().endsWith('/login'));await fresh.getByRole('alert').waitFor();
   await enter(fresh,next);assert.ok(!fresh.url().endsWith('/login'));
   return 'Troca HTTP 200; senha anterior recusada e nova aceita.';
 });
 await run('TRV-07',d,'Abrir sessão e reiniciar apenas o app; reabrir Estoque na mesma sessão.',async()=>{
   const started=await stock(p.un);
   execFileSync('docker',['compose','restart','app'],{stdio:['ignore','pipe','pipe'],timeout:40000});
   let up=false;
   for(let i=0;i<24;i++){
     const r=await d.request.get(base+'/health',{timeout:3000}).catch(()=>null);
     if(r?.ok()){up=true;break}await new Promise(resolve=>setTimeout(resolve,500));
   }
   assert.ok(up);
   await open(d,'/stock');assert.match(d.url(),/\/stock$/);assert.equal(await stock(p.un),started);
   return 'Sessão e saldo '+started+' un preservados após restart.';
 });
});
