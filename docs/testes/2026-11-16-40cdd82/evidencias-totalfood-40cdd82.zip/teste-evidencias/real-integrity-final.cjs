const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const {assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,number,rows,main,save,append,skip}=require('./real-common.cjs');
const run=rows('real-integrity-final');
const date='2026-11-16',start=date+'T00:00:00-03:00',end='2026-11-17T00:00:00-03:00';
const sql=q=>JSON.parse(execFileSync('docker',['compose','exec','-T','db','psql','-U','estoque','-d','estoque','-At','-v','ON_ERROR_STOP=1','-c',q],{encoding:'utf8'}).trim());
const jsonify=q=>sql("SELECT COALESCE(json_agg(q),'[]'::json) FROM ("+q+") q");
main(async()=>{
 const {a,b,p}=JSON.parse(fs.readFileSync(out+'/fixture.json'));
 const d=await pageFor('d'),e=await pageFor('e'), k=await pageFor('c');
 await run('TRV-03',d,'Reconciliar todos os depósitos: ledger por SKU, estoque agregado, lotes com caixas e reservas ativas.',async()=>{
   const balances=jsonify("SELECT ml.warehouse_id,ml.sku_id,ml.item_id,SUM(CASE WHEN ml.direction='IN' THEN ml.quantity ELSE -ml.quantity END) AS saldo FROM movement_lines ml GROUP BY 1,2,3");
   const reserved=jsonify("SELECT r.warehouse_id,r.sku_id,SUM(r.remaining_quantity) AS reservado FROM material_request_reservations r WHERE r.status='ATIVA' GROUP BY 1,2");
   const q="SELECT l.id,l.initial_quantity-COALESCE((SELECT sum(a.quantity) FROM stock_lot_allocations a WHERE a.stock_lot_id=l.id),0) AS restante,COALESCE((SELECT sum(c.current_weight) FROM stock_crates c WHERE c.stock_lot_id=l.id AND c.status='ACTIVE'),0) AS caixas FROM stock_lots l WHERE l.id IN (SELECT stock_lot_id FROM stock_crates UNION SELECT origin_lot_id FROM stock_crates)";
   const lots=jsonify(q);
   assert.ok(balances.every(r=>number(r.saldo)>=0));
   for(const x of reserved)assert.ok(number(x.reservado)<=number(balances.find(b=>b.sku_id===x.sku_id&&b.warehouse_id===x.warehouse_id)?.saldo||0),JSON.stringify(x));
   assert.ok(lots.every(x=>number(x.restante)===number(x.caixas)),JSON.stringify(lots.filter(x=>number(x.restante)!==number(x.caixas))));
   const within=await get(d,'/api/warehouses'), warehouses=[];
   for(const w of within){
     const expected=new Map();
     for(const line of balances.filter(x=>x.warehouse_id===w.id))expected.set(line.item_id,(expected.get(line.item_id)||0)+number(line.saldo));
     const screen=await get(d,'/api/stock?warehouse_id='+w.id);
     for(const [item,n] of expected)assert.equal(Math.round(number(screen.find(x=>x.item_id===item)?.quantity||0)*1000),Math.round(n*1000));
     warehouses.push({id:w.id,name:w.name,items:expected.size});
   }
   save('integrity',{balances,reserved,lots,warehouses});
   return balances.length+' pares SKU/depósito, '+lots.length+' lotes, '+reserved.length+' reservas agregadas; estoques visíveis conciliados.';
 });
 await run('TRV-06',d,'Inspecionar cabeçalhos, atributos de cookie e logs da aplicação.',async()=>{
   const response=await open(d,'/stock');
   const all=await response.allHeaders();
   const headers=Object.fromEntries(Object.entries(all).filter(([k])=>['content-security-policy','x-content-type-options','x-frame-options','referrer-policy','cache-control','permissions-policy','cross-origin-opener-policy'].includes(k)));
   assert.match(headers['content-security-policy'],/default-src 'self'/);
   assert.equal(headers['x-content-type-options'],'nosniff');
   const cookie=(await d.context().cookies()).find(c=>c.name==='estoque_session');
   assert.ok(cookie.httpOnly&&cookie.sameSite==='Strict');
   const file=execFileSync('docker',['compose','logs','app'],{encoding:'utf8'});
   assert.ok(![process.env.TF_TEST_BOOTSTRAP,process.env.TF_TEST_TEMP,process.env.TF_TEST_PASSWORD,cookie.value].some(value=>value&&file.includes(value)));
   save('security-headers',{headers,cookie:{name:cookie.name,httpOnly:cookie.httpOnly,sameSite:cookie.sameSite,secure:cookie.secure}});
   return 'CSP self, nosniff, HttpOnly e SameSite=Strict; credenciais de teste e cookie da sessão ausentes nos logs revisados.';
 });
 await run('TRV-04',d,'Conferir respostas de servidor registradas e log do app.',async()=>{
   const errors=fs.existsSync(out+'/browser-errors.jsonl')?fs.readFileSync(out+'/browser-errors.jsonl','utf8').split('\n').filter(Boolean).map(JSON.parse):[];
   const net=fs.readFileSync(out+'/http.jsonl','utf8').split('\n').filter(Boolean).map(JSON.parse).filter(x=>x.status>=500);
   save('server-errors',{errors,net});
   assert.deepEqual([...net,...errors.filter(x=>x.kind==='5xx')],[]);
   return 'Nenhum 5xx na trilha HTTP.';
 });
 await run('TRV-09',d,'Comparar migrações registradas no banco antes e depois de desligar bootstrap/recriar app.',async()=>{
   const files=fs.readdirSync('migrations').filter(x=>/^\d{3}_.+\.sql$/.test(x)).sort();
   const list=jsonify('SELECT version FROM schema_migrations ORDER BY version').map(x=>x.version);
   assert.deepEqual(list,files.map(x=>x.replace('.sql','')));
   assert.equal(list.length,43);
   assert.equal(fs.readFileSync(out+'/migrations-before.txt','utf8'),fs.readFileSync(out+'/migrations-after.txt','utf8'));
   return '43 migrações 001–042; registros e timestamps idênticos após recriar o app.';
 });
 await run('REQ-29',e,'Conferir as linhas do movimento da entrega móvel de cinco caixas.',async()=>{
   const scenario=JSON.parse(fs.readFileSync(out+'/scenario-day.json'));
   const id=scenario.delivery.movement_id;
   const lines=jsonify("SELECT ml.id,ml.quantity,ml.direction,ml.sku_id FROM movement_lines ml WHERE ml.movement_id="+Number(id)+" ORDER BY ml.id");
   assert.equal(lines.length,5);
   assert.ok(lines.every(x=>x.direction==='OUT'&&x.sku_id===p.crate.sku));
   assert.equal(Math.round(lines.reduce((s,l)=>s+number(l.quantity),0)*10),1029);
   save('request-five-movement-lines',lines);
   return 'Uma entrega, movimento '+id+', cinco linhas OUT, soma 102,9 kg e cinco caixas zeradas.';
 });
 await run('REQ-17',d,'Conferir os movimentos vinculados ao pedido de 200 kg após as três confirmações.',async()=>{
   const workflow=JSON.parse(fs.readFileSync(out+'/req-end.json'));
   const id=Number(workflow.big);
   const ledger=jsonify("SELECT id,movement_type,document_number FROM movements WHERE document_number='REQ-"+id+"'");
   assert.equal(ledger.length,1);
   const req=await get(d,'/api/material-requests/'+id);
   assert.equal(req.deliveries?.[0]?.receipts?.length,3);
   const before=JSON.parse(fs.readFileSync(out+'/real-requests.json')).find(x=>x.id==='REQ-17');
   assert.equal(before.estado,'passou');
   save('req-conciliation-ledger',{id,ledger,receipts:req.deliveries[0].receipts});
   return 'Uma saída total para o documento REQ-'+id+', três registros de recebimento e estoque inalterado nas confirmações.';
 });
 await run('MOV-01',d,'Cruzar lote via formulário, estoque e preço médio atual por item e depósito.',async()=>{
   const front=JSON.parse(fs.readFileSync(out+'/real-mov-entry-final.json')).find(r=>r.id==='MOV-01');
   assert.equal(front.estado,'passou');
   const result=await get(d,'/api/reports/balance?'+new URLSearchParams({before:end,warehouse_id:String(a)}));
   const kg=result.find(x=>x.item===p.kg.name);
   const un=result.find(x=>x.item===p.un.name);
   assert.equal(number(kg.avg_cost),4.2);
   assert.equal(number(un.avg_cost),2.5);
   save('entry-avg-cost',{kg,un});
   return 'Duas linhas no formulário e feedback visível. Posição no VR com preço médio por item de 4,20/kg e 2,50/un.';
 });
});
