const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {randomUUID}=require('node:crypto');
const base='http://127.0.0.1:5656';
const out='teste-evidencias';
const roles={d:'diretor',g:'t-gerente',e:'t-estoquista',c:'t-cozinha',c2:'t-cozinha2'};
const op=()=>({operation_id:randomUUID()});
const stamp=Date.now().toString().slice(-9);
const reqLog=out+'/http.jsonl';
let browser;
const pages=[];
function save(name,body){fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(body,null,2))}
function append(name,body){fs.appendFileSync(out+'/'+name+'.jsonl',JSON.stringify(body)+'\n')}
function clean(value){
  return JSON.parse(JSON.stringify(value,(k,v)=>/token|password|authorization/i.test(k)?undefined:v));
}
function writeHTTP(method,route,status,input,body){
  if(/password|login/.test(route)) return;
  fs.appendFileSync(reqLog,JSON.stringify(clean({method,route,status,input,body}))+'\n');
}
async function getBrowser(){
  if(!browser) browser=await chromium.launch({executablePath:process.env.CHROME_BIN||'/usr/bin/google-chrome'});
  return browser;
}
async function pageFor(role,width=1366){
  const b=await getBrowser();
  const context=await b.newContext({viewport:{width,height:width===390?844:900}});
  const p=await context.newPage();
  p.setDefaultTimeout(6500);
  pages.push(p);
  p.on('pageerror',e=>append('browser-errors',{role,width,kind:'pageerror',url:p.url(),text:e.message}));
  p.on('console',e=>{if(e.type()==='error'&&!e.text().startsWith('Failed to load resource'))append('browser-errors',{role,width,kind:'console',url:p.url(),text:e.text()})});
  p.on('response',r=>{if(r.status()>=500)append('browser-errors',{role,width,kind:'5xx',url:r.url(),status:r.status()})});
  if(!role) return p;
  const pw=role==='d'?process.env.TF_TEST_PASSWORD:process.env.TF_TEST_TEMP;
  await open(p,'/login');
  await p.locator('[name=login]').fill(roles[role]);
  await p.locator('[name=password]').fill(pw);
  await p.locator('form button').click();
  if(p.url().endsWith('/change-password')){
    const replacement=pw+'Rodada';
    await p.locator('#forcedCurrent').fill(pw);
    await p.locator('#forcedNew').fill(replacement);
    await p.locator('#forcedConfirm').fill(replacement);
    await p.locator('#forcedPasswordForm button').click();
    await p.waitForURL(u=>!u.pathname.endsWith('/change-password'));
  }
  assert.ok(!p.url().endsWith('/login'),'Sessão recusada para '+roles[role]);
  return p;
}
async function open(p,route){
  const r=await p.goto(base+route);
  return r;
}
async function api(p,method,route,data,extra={}){
  const headers={...extra};
  if(method!=='GET' && !headers.Authorization && headers['X-CSRF-Token']===undefined){
    const meta=p.locator('meta[name=csrf-token]');
    if(await meta.count())headers['X-CSRF-Token']=await meta.getAttribute('content');
  }
  if(headers['X-CSRF-Token']===false)delete headers['X-CSRF-Token'];
  const r=await p.request.fetch(base+route,{method,headers,data,timeout:17000});
  const raw=await r.text();
  let body=raw;try{body=JSON.parse(raw)}catch{}
  if(method!=='GET'||r.status()>=400)writeHTTP(method,route,r.status(),data,body);
  return {status:r.status(),body};
}
function good(r){assert.ok(r.status>=200&&r.status<=299,JSON.stringify(clean(r)));return r.body}
function bad(r,rx,status){
  if(status)assert.equal(r.status,status,JSON.stringify(clean(r)));
  else assert.ok(r.status>=400&&r.status<500,JSON.stringify(clean(r)));
  if(rx)assert.match(JSON.stringify(r.body),rx);
  return r.body;
}
const get=async(p,r)=>good(await api(p,'GET',r));
const post=(p,r,d)=>api(p,'POST',r,d);
const arr=(v,...keys)=>Array.isArray(v)?v:keys.map(k=>v?.[k]).find(Array.isArray)||[];
const number=(x)=>Number(String(x).replace(',','.'));
function rows(name){
  const all=[];
  return async(id,p,steps,f)=>{
    try{const obs=await f();all.push({id,estado:'passou',steps,obs})}
    catch(e){
      const shot='capturas/'+id+'-'+name+'.png';
      if(p&&!p.isClosed())await p.screenshot({path:out+'/'+shot}).catch(()=>{});
      all.push({id,estado:e.skipped?'não executado':'falhou',steps,obs:e.message,evidence:e.skipped?undefined:shot});
    }
    save(name,all);
    console.log(id,all.at(-1).estado,all.at(-1).obs);
  };
}
function skip(msg){throw Object.assign(Error(msg),{skipped:true})}
async function close(){if(browser)await browser.close()}
function main(fn){fn().catch(e=>{console.error(e);process.exitCode=1}).finally(close)}
module.exports={assert,base,out,op,stamp,pageFor,open,api,get,post,good,bad,arr,number,rows,skip,main,save,append,clean};
